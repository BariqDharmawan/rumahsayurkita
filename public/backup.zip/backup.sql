TRUNCATE address_book; TRUNCATE alert_settings; INSERT INTO alert_settings (`alert_id`, `create_customer_email`, `create_customer_notification`, `order_status_email`, `order_status_notification`, `new_product_email`, `new_product_notification`, `forgot_email`, `forgot_notification`, `news_email`, `news_notification`, `contact_us_email`, `contact_us_notification`, `order_email`, `order_notification`); VALUES ('1', '0', '1', '0', '1', '0', '1', '0', '0', '0', '1', '0', '0', '0', '0');


TRUNCATE api_calls_list; INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('1', '0myc2h9so5f812scxvaf8rk9f2r414k7', 'sitesetting', 'mj3gi750fl42y--25tlzqxly5dmzm3cf', '2020-09-07 06:35:46');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('2', 'xt5jc-lsfa2l6j94po24xpe2tfzsmzig', 'getallpages', 'js7fja0xy5gi5dq2edkpk24b6ifr69i9', '2020-09-07 06:35:46');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('3', 'g9n94kz6rieqhzoaetkz-3ib6rjnwdez', 'getallproducts', 'w3bofz-enkmpxo3z1i00pbq-5kvit235', '2020-09-07 06:35:58');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('4', 'p9tmm-7fiauv6skpuz503g2t279akyg3', 'getallproducts', 'sytdqnqdvfq1a230fwlb1naqdg57-13n', '2020-09-07 06:35:58');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('5', 'ihi6ulxvb6mnts0k-du7yng5hc5dybvp', 'getallproducts', 'z1nn52js6srmin2c7bdh7w9w-easfv8i', '2020-09-07 06:35:58');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('6', 'ttsz1ff2y9y4sysyf0bsyq1ftcqobtu2', 'getallproducts', 'x90uydobxd129b9d1w0gngnav1azrnym', '2020-09-07 06:35:58');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('7', '0rqv9329iaclvezl3amekcjdk6dc3vgy', 'registerdevices', '6jfhma2t-uk4h-i9ti7hpqvtq2aerq8c', '2020-09-07 06:35:58');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('8', 'ajnxasmscywel7r4ynokvri6kec-8p8n', 'getbanners', 'xey-vcj4iyn9ehuybsp7rrrz-7qo74fy', '2020-09-07 06:35:58');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('9', 'jn6nv9le1l35yoil6iwh0funj2ysmznd', 'sitesetting', 'jc3cc2cvf8zgd2eqhyugkyzpgcsn90e9', '2020-09-07 06:36:05');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('10', 'fce0gdzsjwagg1hps9al31pl9g-widce', 'getallpages', '8whqg7i1y7riiym2913rv2tkfxqqih4m', '2020-09-07 06:36:05');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('11', '27mjw-vbnmzq95fytob0ajjokg5l6swa', 'getbanners', 'l3q2sl36m5re1v4bxkjpw-b36g2cdqqn', '2020-09-07 06:36:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('12', 'zx1541oe26xgqidjqb4v-3sd7s1ybmg3', 'getallproducts', 'mrcibrw6bvm07rd1-l9qgf7o8wjfl24y', '2020-09-07 06:36:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('13', '0x8bms84m3bcvuw5durpydgyi6bhstn6', 'getallproducts', 'yd2znl4p9cbpkx0u0ozenro8z38kizg0', '2020-09-07 06:36:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('14', '36an3bou-agfk329bq9hhvfqe7q7vc0v', 'getallproducts', 'y98zugcq3w5p6o0a6bi4lqanaqfcwfmv', '2020-09-07 06:36:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('15', '--1scxt9vvklxc07g43g-7ly9sytbxtq', 'allcategories', 'qyz4yj8pg3ovkdxmavjzzaurzx6b3rys', '2020-09-07 06:36:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('16', '15zfwpu-s-64dpupc4igxs6kg582oz3s', 'getallproducts', '-5fl2y67p53faw35nlttrf58-k28pw-p', '2020-09-07 06:36:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('17', 'smqwe26v1ymbt2u-7o5hexu78jg51kmh', 'sitesetting', '031kku67yjsfrpne5o20nauq3g79l24g', '2020-09-07 06:36:39');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('18', 'qntxgu6ziht8lpmdxxn94fxqxk849t11', 'getallpages', 'hizvq-w0q2jzhlafi9kc3kvxcjnvefn0', '2020-09-07 06:36:39');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('19', 'un1hlgwbedzb1nx2oso8rt-kow8qv5r7', 'getallproducts', '4-c5wvf7hgeiwrdjt-y24pmlydga8ee4', '2020-09-07 06:36:40');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('20', 'deu-vac61o8h8clg9dllg12ovwdb94x1', 'getallproducts', 'cw9s732wf2rcmtkfy1pvf5lyij-eodtr', '2020-09-07 06:36:40');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('21', 'rqj1yr1ele2s38c1gq-vttfun88su1le', 'getbanners', '-06yf3l3a06d38ue556s7eyhd8xx1w5j', '2020-09-07 06:36:40');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('22', '7yb602p5cep0eldq9d3r4cg85we3pdep', 'getallproducts', 'lqiiuxp4ycy6y1wylhzn91-hizm21q-1', '2020-09-07 06:36:40');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('23', 'k6dg8tfumfggoz3txfybqvwkxwz8acv1', 'getallproducts', '59b-r-kda4ub9v7lrtcm7j8x3goaptpi', '2020-09-07 06:36:40');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('24', '64ty4cbbmr8wfut9i5esu3se8efby9fq', 'allcategories', 'fss6-pktg5961s5xlhuyz2hh6sap6-85', '2020-09-07 06:36:40');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('25', 'nyw54b5-i0xy2p17ccw40ntmt2i2vbhj', 'sitesetting', '5xjjbnmirjhm8xoci53yo6lutszcqk3c', '2020-09-07 07:15:43');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('26', 'lluoya-zlf7c08w16aob3t3zbnaxheql', 'getallpages', 'nolnuo54upfe60408uvy5cybxofl9vgw', '2020-09-07 07:15:44');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('27', 'd-t9fs8-qz8bpr2x5ro6en7x3puyy1k9', 'sitesetting', 'tzxkkvtw9rsxt4gqujtdxw3d7uwlhzg-', '2020-09-07 07:15:44');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('28', 'f-fljg4wp-boqx6r4vd0a12awr78wmw3', 'getallpages', '3ebnm10e5s1ar4ukxarphwtjt08faagg', '2020-09-07 07:15:44');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('29', 'hcsb23m3eik7eel946dneymcfngidnby', 'getallproducts', 'nh31tb2akxoz6iaxclrzwh379p027gnn', '2020-09-07 07:15:44');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('30', 'iad8re5h7vj1tym6zpw-s4o0er03ogc-', 'getallproducts', 'wzqc2qhsrez3-wro0r2kd094jfi6tz82', '2020-09-07 07:15:44');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('31', 'f8py6wuoaa8xsvgfx4ty28ktjmauacww', 'getallproducts', '54ymltslq2q07u5dn8afw1hlp13uu30c', '2020-09-07 07:15:45');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('32', 'ehhjk8xciuo9jclt-b4n9jpx4o6hzm83', 'getbanners', '-n-gtnesh-ssgyzp6k4jfh2p49z8trda', '2020-09-07 07:15:45');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('33', 'pt054m-wp4tma6ddwqga5g8m96-1pba1', 'getallproducts', 'ju-xaz4xpepmofjewc3w-cd269q6dacm', '2020-09-07 07:15:45');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('34', 'hoi7s5ij2whugjeu0whqwwk3jylp8gf9', 'sitesetting', 'fjnrwy6x96t4t7iqxx1zh0fuin0nprvm', '2020-09-07 07:38:29');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('35', 'mn60rmhu8nu9jp48aimgveen8a3gkl4e', 'getallpages', 'kmfmdqh087vz4yt2z01hnerxyynyt6w9', '2020-09-07 07:38:29');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('36', 'ca5audvedll3l6e8s728a7juek6996tv', 'sitesetting', 'uc8h8nqe43ies0l44ahg641dmq31hry-', '2020-09-07 07:38:30');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('37', 'sz7cwtmwtjssnrj834yrvu19hxhjyxw3', 'getallpages', 'nmsspc7kgmms1opb6l-cy2l9f-wrgqov', '2020-09-07 07:38:30');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('38', '358sw5v28lmh05f2zxr4f6-4zme9g21r', 'getallproducts', '14i9eiix97tgy2j-96cs49pauqh04mwc', '2020-09-07 07:38:34');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('39', 'mw6udplxp2tnvpuk6drtc26qwvw7q5rp', 'registerdevices', 'afrhuqwwpd55supreylliztgps7jatjl', '2020-09-07 07:38:34');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('40', '3vz39kdxki6sfm1v35k2c933r2c7dlx0', 'getallproducts', '2fmzc8nqn7792ern11zvceltt4son-5v', '2020-09-07 07:38:35');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('41', 'xel2vbu1msq2t34sgqqld7gyhnx4aca6', 'getbanners', '84oj26a-h2mj449d1ox-ylnhue937pc5', '2020-09-07 07:38:35');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('42', 'ljjz-o0pfo2luzp92wmsn7om-28gb7a6', 'getallproducts', 'pv95bdvibd5y4ezxfq98m91u7h2a0on-', '2020-09-07 07:38:35');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('43', 'r6agjxm3cjpebvs4kwaguivrj3l52cf5', 'getallproducts', 'etybbfim0sneisy3-b9bvgatxcm7sy-u', '2020-09-07 07:38:35');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('44', 'glo29q7fcjnn0tfmjnzx6cvkyoznz0d9', 'allcategories', 'jj5t6da329q0paig6udwccjwenou9fae', '2020-09-07 07:38:35');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('45', 't6az-2nmrprm3untl4vnfriy2k-u-aob', 'sitesetting', 'w2mv7rce3co4r4d10ww72-e4mzbgtvub', '2020-09-07 07:38:52');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('46', 'wcebphdk3e-poi-10mp0hp01wsp7vqra', 'getallpages', '6ofp0avad50rp20mzk6ho25tjpvodfr1', '2020-09-07 07:38:53');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('47', 'x5k-0sjw1akajz5wpbtezjmhlty2pxnm', 'getallproducts', 'dbydc7-l0vmp4uosabhkljvme3e8zx5l', '2020-09-07 07:38:53');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('48', '5ioetcpu6vn28zkvrcmcs34s3twcmorx', 'getbanners', '-aq8lsgzqvjo4kxgiztbqzjfuk15wk4s', '2020-09-07 07:38:53');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('49', 'pa81bw20hf3s3bw5ensjmwhejxaj2qdi', 'getallproducts', 'whrq7rnbim0bb4sk7pstvlb27szwc78w', '2020-09-07 07:38:53');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('50', 'hj3gbqycae9qwywmmpgvzziaya5v7rrq', 'getallproducts', 'ned47uok1ey7hoolq9mfl0bt2c6hxy8t', '2020-09-07 07:38:53');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('51', 'f0-8ex2qqfyxgv2gesrr9gd-it0w1b0r', 'getallproducts', 'cu8aqrnbe6mvybmvh4t9zpxcdbzfopy4', '2020-09-07 07:38:53');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('52', 'y-zzzgtgj8y36zz1zhowgb3n4whk89uz', 'allcategories', '04vihj1poyltql-3ayk-hn94hbecs4ih', '2020-09-07 07:38:54');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('53', 'tz-hkfz4c3a0hacyifcaas09mwfy8jy5', 'sitesetting', 'omteywbgbdhkt9eh3p54jf3fea59zaat', '2020-09-07 07:38:59');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('54', '7jq6wwv4k2qo5-cfsbo9t34svzgas8hq', 'getallpages', 'fzlldccaanu1dbon0d100d5lkcgdx0rj', '2020-09-07 07:39:00');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('55', 'n94ka965d2p9-jg19j4h5sbyptsfqegk', 'getallproducts', 'rzyt-ysqoo022umohmybbr8556gxi87g', '2020-09-07 07:39:00');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('56', 'bwx9g72zdsgq9qtd0-0pxg8300wmktl9', 'getbanners', 'tvyao6z-ukbuy2hn2ajydcl14m2nwz3o', '2020-09-07 07:39:00');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('57', 'x87-rgziy9e202f2jxdf-n9rbraraqgl', 'getallproducts', 'k0ak1tw3uz1pob-imy82ogf75y27bums', '2020-09-07 07:39:00');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('58', 'um9j1kt2ntyuc4vc5pjd42uz4t5jqjeq', 'getallproducts', 'kp9ileyjtdjg1712ts4mcnaxx3u7wiws', '2020-09-07 07:39:00');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('59', 'u40o812mkk2yplr55stjdd-zu-htl7rj', 'getallproducts', 'y7ao1v1iqhcxva0iwumocvuh613517q8', '2020-09-07 07:39:00');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('60', 'og3x1dqa5tsy4l5xnxmeuhm-w16hvcj4', 'allcategories', 'nsyx9hehhqtmwumhuk4unirowyo58pkb', '2020-09-07 07:39:00');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('61', 'hzb6e4uvhamlg5q-iin0y48-9352ynq2', 'sitesetting', 'gtp35qrkp4d6xd2xxxmy2350v--5w6j6', '2020-09-07 08:12:19');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('62', 't6vu-wlfispza657o-gklhr13vmcbyl9', 'getallpages', '5jzk--udwk-nkg0db6qvfdfxtxhiww7z', '2020-09-07 08:12:19');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('63', 'fkqcycm49-r0ws6bctu09o7kwhmcao-d', 'sitesetting', 'x1hpg6i2rgcux2jxb96wr6n86lzs5jw1', '2020-09-07 08:12:19');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('64', 'uz6e-1zdo8yr11zw1b2pb19184oc70nn', 'getallpages', 'wjkhm0gtbuqkqrun1fzqs0h650fowefp', '2020-09-07 08:12:20');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('65', '4c4c7n0leelmc0-35gzvqjy77cns3yz7', 'getallproducts', 'q0d78w5stg3gb7jkwhea2ld0xicskdxv', '2020-09-07 08:12:26');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('66', 'kqsicxox1atijyi-mdan20vhu4ht7ukm', 'registerdevices', 'lqpbqr6lo8rx3cv1jwm3ubtzcvrrx-77', '2020-09-07 08:12:26');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('67', 'igq59lbh2grp9wfmuhp22ly5u-hx57op', 'getallproducts', '95e3c1-j0k6om2ojvt75pf-zwlleuhew', '2020-09-07 08:12:26');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('68', '4x5nqg3rzy6i4h-ghs80s2z0m0upnh4m', 'getallproducts', 'khqhzfuvywu1gutjxxyeb6lcl74pgj3r', '2020-09-07 08:12:26');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('69', 'fzo-ioelh0jgot8z-t1a16kmaklnivfm', 'getbanners', 'hw3308nwhmmt5rzmtq7ds1zgzphu50er', '2020-09-07 08:12:26');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('70', '6h3qoav-wc2xf274zg7gj7q9qg2vt2nj', 'getallproducts', '09fgims2agzm7auyd2fk18c2q1yd6-4j', '2020-09-07 08:12:26');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('71', '9wmh49-a91-af-qjck55b6c6pgllbqh4', 'allcategories', 'r5x7i63wrg2u4whr22enat5842axyt0g', '2020-09-07 08:12:27');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('72', 'pvf6f8mi72sc4od144lsw76jdvvl-kng', 'sitesetting', 'ki6jhnq80ijg-48ougc5h1n1ovinm8xe', '2020-09-07 01:52:04');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('73', 'o0kpqnpxnmk0pvq9fsez2junr90w9r9u', 'getallpages', 'nltgbywlhh5u8rtf7-ypc0k3bca-c4yd', '2020-09-07 01:52:04');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('74', 'sbfxrw39eat3c2im1-qmf9f3twg7gg9j', 'sitesetting', '-16b3hvraz9ufw5ukiiv9gnknte4wmg6', '2020-09-07 01:52:05');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('75', 'lnx60qx7ktdss9wvu2i-o41yk9qvv052', 'getallpages', 'fbycds6whsch9ab87ff2pp-jvkv8vtat', '2020-09-07 01:52:05');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('76', 'yjafxaq0p68g2mhu08ixs5-91x5uu93-', 'registerdevices', 'ldugsqod-l99dxim3g14171ydham0vxi', '2020-09-07 01:52:10');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('77', 'i4-j68mi2fiau2dp4zd--pjzgmov642h', 'getbanners', '9taw4gsjgms7-icjf08m43vy5dyiw306', '2020-09-07 01:52:10');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('78', 'x3vm9y07h9yqp05usf6f-sxcenbt9sd8', 'allcategories', 'pmv0fite9t3yyb7mlfxwrurngbmcm-yz', '2020-09-07 01:52:10');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('79', 'qc6ruiqnzob2cpfsjvkyo5p0tfw4ol1l', 'getfilters', '89068ruu9m1kmy2pajx4re450jdo3ul0', '2020-09-07 01:52:10');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('80', '46s6ukcgt4pb6tufp8qj1h-u1rtvcsda', 'getallproducts', 'en5e0khz4d8rw-k08bi7vx-ro1w3ucyf', '2020-09-07 01:52:10');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('81', '25inmqa5cpu1kqvivh75ulgcp1kjafy6', 'getfilters', 'v7i72qg0bq9sh85p0r-2rn3839xdfgcv', '2020-09-07 01:52:10');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('82', 'c5hgvp32vz7b69txrqdxymq11t66j-q3', 'getallproducts', 'qe8ph8owquo47hku45ak64v881kj6tnk', '2020-09-07 01:52:10');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('83', 'ccflhh4vczfasipppv2wkxydod0ekzc6', 'sitesetting', '7vqz3-4z958qu8qgjoh6p625e5kbv61n', '2020-09-07 01:52:37');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('84', 'yttvhx5i0-uprm7hkh5ignucglfh8fhe', 'getallpages', 'l7ckvxole5jspe-wbu9mvkd-ly4qmka0', '2020-09-07 01:52:37');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('85', '7m-kwto0b2rjfej25bnsprxcspsmc0rs', 'getbanners', '3irc09y434g5ebo5z3ddmgw0-pojajec', '2020-09-07 01:52:37');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('86', '8i9vt6k51oczzwsohx3q-ad2g-t53o8t', 'allcategories', 'uq9kd6h1h596qk9wh619yew-1d3fglxb', '2020-09-07 01:52:37');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('87', 'jwy65h4szqvq47zastgc8d7ccu2bofwz', 'getallproducts', 'dllhdeplaiger11y2j-ohiflt004hkgb', '2020-09-07 01:52:38');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('88', 'qubwppc03mw9s0vp1f-6n3s3viatc8lv', 'getallproducts', '8onw7jljz4hm7oc8bdfyxpd09-a4wtk8', '2020-09-07 01:52:38');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('89', '4w4hy53lly97jh6ft40fmzd2simlsj5y', 'getfilters', '6gx3zx68i1f--hxryw7tlenihfk35jgc', '2020-09-07 01:52:38');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('90', 'csn5c-s0cu7n20krtiohpw2rp8riuaup', 'getfilters', 'e7wfu7j61pwx3r94gk6t5kr9v2l5-57y', '2020-09-07 01:52:38');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('91', '0gwmwjeoitibi7i2bcs4aowe5wsidajk', 'sitesetting', 'bdrqkd-bre2my2p3axokvqtmq1bv2i5t', '2020-09-07 01:52:38');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('92', '294vdz675w--yaihu078jm7vfuka2gl6', 'sitesetting', 'q78aq8qoghaugt487m--8fmavd4od6g8', '2020-09-07 01:57:01');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('93', 'he88l6yajon0f8u2rz-n3xr-wlur2895', 'getallpages', 'jnasbmrgt7z-3oebrlgofw0qak-9de71', '2020-09-07 01:57:01');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('94', '2ptsk3hr-0jj8--oyllncjk3v1ksyut4', 'registerdevices', '43v1cqhfx06e384ttiy3aumch6hhehuj', '2020-09-07 01:57:05');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('95', '0rfs51htuj795iughgq8h3ri9d5-jr09', 'getbanners', '7i4wkxmkq92t9ltytybtrhgq-xrm6178', '2020-09-07 01:57:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('96', '--1uzh3hvhq7voyulftswweo-1plhc64', 'allcategories', '3s7upknql-ynszbgx7c6bsmvde2l7r0n', '2020-09-07 01:57:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('97', 'eo5lk0pn6yid4wjb3so5psyw4wlbpa3t', 'getallproducts', '8bwjjmo185tssl-0d9vwvw2cvr5gb7pa', '2020-09-07 01:57:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('98', 'o6zi2jaac64r53kxtb4mz63zqujqnkf6', 'getfilters', '2jqklobl9f-15xgnljveqm4yq3fvjyua', '2020-09-07 01:57:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('99', 'bgq15-pcggyzj5kr7qk7ituneol9t-bi', 'getallproducts', 'mm7cw1itkya3693frw7hau6oyoqsc5gy', '2020-09-07 01:57:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('100', '78n8b78yndaqwp87szlllpsoxehm3n53', 'getfilters', 'n0x0zq2vglrsds3fcduzhstip-zuvwfe', '2020-09-07 01:57:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('101', '8w2c3xayjh3w5qlxuelw4crozldlnak7', 'sitesetting', '4dwh41l2g5v2a5p-j52x-ff-dogpyt26', '2020-09-07 02:09:02');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('102', 'zh2hj96rtv19pbt6uqxe3a--13x2cfmu', 'getallpages', 'z77h7kx6blm2jt3fudubdiaefgnn-hh0', '2020-09-07 02:09:03');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('103', '4qd0clm1y8p-0rm-5p91yzvklb1-yner', 'sitesetting', 'kric0kg91ravt1vgwayicobefp16-lhj', '2020-09-07 02:09:03');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('104', 'mii2s2h01r9zd8z10-mtw1an309c2br6', 'getallpages', 'y3pzdliifomaca2ldaio0gc77a-ac66q', '2020-09-07 02:09:03');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('105', '8rj6x2ua8i2k1o-h7k472pu7pb0f0b26', 'registerdevices', 'df7iqqpx4xtryg26my-vsqeml7byja7s', '2020-09-07 02:09:08');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('106', 'uojnqgm193t-bvoxzfi-mwmdo7b6ghka', 'getbanners', 'i-9z87igicl0zhzglaznrg4f-xbha7m1', '2020-09-07 02:09:08');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('107', 'jlh5l-zq0ilf4njb0g1cxaj1xj9ntubg', 'allcategories', '598d7lh5uz4ij884c8j11kojoxgs3s38', '2020-09-07 02:09:08');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('108', 'pm-v9mw-4v7o78qu0klfm62f0pm7w3ha', 'getallproducts', 'wui4bq05ffatcvu85er2aiwna6x0o733', '2020-09-07 02:09:08');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('109', '2krbli500427eb0gcvv3cwbysgw1nyul', 'getfilters', '8dm6ua8ua6g5we3wcdvskomdd7oa5spi', '2020-09-07 02:09:08');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('110', 'c5v00y7rwge0jif1v7k-jqyu-tcfmbwl', 'getallproducts', 'ybc0z1kgz5rochjys8lg72h2jd-e0pas', '2020-09-07 02:09:08');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('111', 'i2o-oorbw2jp15w14xy5j1xu6ugoxr7x', 'getfilters', 'rnz7p195br2uejfvzr8stgzllqlur6ac', '2020-09-07 02:09:08');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('112', '2msuv13qh84wodfsm17smn3yk3apqfoh', 'sitesetting', 'hfozclo656-t9g60jgxj-ny3eiyvcz7q', '2020-09-07 02:09:20');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('113', 'o4tn9lxcp265c3i0p4t0w2u5ykvvxces', 'getallpages', '833ja3px2ndq150apt1t1i2e9g4buiff', '2020-09-07 02:09:20');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('114', '0758ugbmpc7v2q7dkvxojjazibnlw2-e', 'getbanners', '-nceg79o1ucmtw5t8vr9gf66if8yp4pn', '2020-09-07 02:09:21');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('115', '6d61vwbc0ae2drna7fysfx0a8hrl5yup', 'allcategories', 'x6f36bolsids6zjksvnztb7j927s97xq', '2020-09-07 02:09:21');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('116', 'dr9vwaq5cpsbesy4w5fxxwqjy0hchm3-', 'getallproducts', '5esdkm7oclvexmhughqfy6xzea5rq64z', '2020-09-07 02:09:21');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('117', '00mrvfsa11-yjbwqv0ae0zn1mgc96817', 'getfilters', 'mlhtzm2dc31tmsa45j0br-c2lh8tikv2', '2020-09-07 02:09:21');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('118', 'txodnic87chjvdjgfr4a06o3vaxnmin5', 'getfilters', 'h36y2a-upr38irdric57dmg97fjujd8m', '2020-09-07 02:09:21');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('119', 'bjvnb5vybjxldy59zrv531xlxhu2y25m', 'getallproducts', '03zn4fagb4a9-iei25ld5xxbph8yhq24', '2020-09-07 02:09:21');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('120', 'y36guczvcly0nbis27t56j2in3iymzz0', 'sitesetting', 'abvolr5vu0r78870frfkyr4jrh3gix4o', '2020-09-07 02:09:21');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('121', 'fa-22neatadz9wa0xt5my1ak5vro29u4', 'sitesetting', 'c4brc9sh49qwqvjbuzi99o9efgswu8i3', '2020-09-07 02:09:28');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('122', 'sqwxaauzervh21p65iig5q09dawm12ug', 'getallpages', '2wj-wrka-88aahc5z49biqyj2fiep733', '2020-09-07 02:09:28');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('123', 'fincmfa4umg2cwa3ge5ezdhtcbnns169', 'getbanners', 'vmim0b788dyxg63ir13ox4d59uy0gnr1', '2020-09-07 02:09:28');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('124', 'i-kdn1x1psr9ss2mvbagpilz7vl9lb-o', 'allcategories', 'm86cvlpuh1khz4ud1y-gcnxqjwioj555', '2020-09-07 02:09:29');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('125', 'noq5eo-w11d1hjr1c6mogemg47sn-ws1', 'getallproducts', 'x0h4dg0h2eu0jao4bnms329mqo6m0fcw', '2020-09-07 02:09:29');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('126', 'cuc34i7eh1dfftopy-ja8gmemosmcrz7', 'getfilters', 'n1bfm47mr7d3aqf-a2xe90-fcmv8s15q', '2020-09-07 02:09:29');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('127', 'ia0ds4d10m0mkmujrqnc4e99r0ldvjri', 'getfilters', 'ijdt-8ymj0bgx6ugpj5q63y9cm8lnjo6', '2020-09-07 02:09:29');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('128', 'miy89f6hbt0bbzysrsf5wgysnkaocvjq', 'getallproducts', 'dsddgnrrsxx08xdhv7s236xnspprld2m', '2020-09-07 02:09:29');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('129', 'qm0zsy-hqtyknqo9eb11gngkuvnzngsc', 'sitesetting', '0rg9tsi41iol-5-67hr7f7af9ssu552p', '2020-09-07 02:09:29');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('130', '3g7j989rsq4udur8rgntylj92nt0jbsa', 'sitesetting', 'hxlb0a0ubn2tvw6hw380ken5pays2wtw', '2020-09-08 09:41:16');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('131', '3yxlhxg35ow9hdm3whw-h-p-6-wtt5em', 'getallpages', 'vp95x0imujoptvilv8z4b61krm3u3-5s', '2020-09-08 09:41:17');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('132', 'c6-pmuownwmslmxuork20gtv2u5gpduz', 'registerdevices', 'mtr5qy1iw9ux-cz6dbgdrd1qj82hzp0a', '2020-09-08 09:41:23');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('133', 'x5t-yq840r31apcwwq6g52ueyxnm06w8', 'getbanners', 'np6o-nuwuis7hs1wpjh41-eegg60u0uy', '2020-09-08 09:41:23');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('134', 'bnnsr019espms8l1uc9hhd-47hgksbrp', 'allcategories', 'e0p5c3vu0j1u7bay7s1chm2huovbvn8n', '2020-09-08 09:41:24');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('135', 'r8bexgk-b7h-m8j3v7q7u7de133o0baj', 'getallproducts', 'x2z97scqp6yapz6gqo82r7y0eumhiifv', '2020-09-08 09:41:24');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('136', 'va-q4joz76pp9mbzy-8u875fe1kjf7le', 'getallproducts', 'm5kgmhqwath9sd6jqbkieawjgtnly69k', '2020-09-08 09:41:24');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('137', 'jrwqih1oymx3rd9233dy2xgk0p4bqav7', 'getfilters', 'pe-87b2ulum5x5704gdlivc-lsq8c9ny', '2020-09-08 09:41:24');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('138', 'hkoptq605-6oc77feoha6lcfvvx2-8mp', 'getfilters', 'dv13clooe-5a55nw09hfs0ya316ch5-c', '2020-09-08 09:41:24');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('139', '2u0daavfrgpjkjsx-ngl40wgbmsh7q8w', 'sitesetting', '325ojzso1hkgjccy1d1i62uwef11zgzy', '2020-09-08 09:41:32');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('140', '0c079jusihqf-ts7wu2s5vdtgoi7ar1v', 'getallpages', '03q3znvtxyiw4y8bbvukjs2gd9d9x0bk', '2020-09-08 09:41:32');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('141', 'afxjkz4c4-co4u8g-0egrppsy1nap33q', 'sitesetting', '2zgrt0kv0tv-axm9z3ewywp315pofr1d', '2020-09-08 09:41:33');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('142', 'mk52yej-1lzepmigvjuamlvwkoan-aut', 'getallpages', 'guf8852p0x74il-wboewjo7tl2xm5xkj', '2020-09-08 09:41:33');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('143', 'szm0ckmrhrlvnh-69zjusjynr2rhxp5a', 'getbanners', '6shqmi9g4k3gij93jt88t0k90mhkkqir', '2020-09-08 09:41:33');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('144', 'mv17ywjod165g727l6gi65ogwwczdal5', 'allcategories', '1ulym79g53ulapidovs9d850j83g3xp-', '2020-09-08 09:41:33');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('145', '6h8ml4s6mx96k4zy6br8uqzogk4820ik', 'getallproducts', 'tdvhsf2eqc96r4dp71ngqkbv2bj8h156', '2020-09-08 09:41:33');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('146', '9lp3aazh0utlf8y3pw171loamn0q4125', 'getfilters', 'aolny3g5vgvb1mg4ufwkjqi22l1zytk9', '2020-09-08 09:41:33');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('147', '-lw5u3epj-pqnzjdhwsyqqafhyinnrws', 'getallproducts', 'k30huuyzyfjgc7yhz4p6vp24vfrw6q4c', '2020-09-08 09:41:33');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('148', 'vmxs0ah8qnd-17xey-j7d-dr8wr2np3w', 'getfilters', '-n3gqmgervj7cx3pkdv8vokjk07zvo15', '2020-09-08 09:41:33');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('149', '3zb3qjnaqzasi1rmmx2q7o69pi-4mzwv', 'sitesetting', 'd02rqxb4i6s5jcdv3xbeix9tgsaijctp', '2020-09-08 09:41:39');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('150', 'eo11qklw749-zuyhc7hwv33lb953m4wi', 'getallpages', '4j0ciq-uoynzvzzgyyz31ve4optea5xy', '2020-09-08 09:41:40');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('151', 'ebzvz3-kiao0brkh8fut3squ5uaeao1w', 'getbanners', 'vsxzkmzd9lawkad9n8b95p155glv4ory', '2020-09-08 09:41:40');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('152', 'evrg8vo2fvk7vkwuss0caekoy1zg71hl', 'allcategories', 'b0eax6oufv32gr3gh3i8m7by2ku7trcw', '2020-09-08 09:41:40');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('153', '3tvoqtejfalwcupoa1ioojsgfkvq1xum', 'getallproducts', 'rqpbwjcqejbal7ej4j6r-yz8yisc7y0z', '2020-09-08 09:41:41');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('154', '657y6bkkmxsymy9mki91o13jmxzynasj', 'getallproducts', 'a40kxacb87c0uazpu01tft8gxm2wzk2m', '2020-09-08 09:41:41');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('155', 'lwypnp4opfir5q1k31g9-e19twtmpi7g', 'getfilters', 'bovf8p2gu0swbbljsea4xmcbova8w6jw', '2020-09-08 09:41:41');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('156', 'i659sr415n1himf2jazwgn4mk1qfjjcj', 'getfilters', 'pz36leyzm46u7hoveisx18atzv5uxd30', '2020-09-08 09:41:41');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('157', '85k94j6uaobrtijj9qop4mxzyot6ukg2', 'sitesetting', 'mg-3e82cbf3j18rnrl58k82peame3-2w', '2020-09-08 09:41:50');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('158', 'vre1w4xg2sof3oir33a4l9jn7tpbvqxf', 'getallpages', 'fk2uol8xe6qms--i-cutgx28az8b769j', '2020-09-08 09:41:51');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('159', 'hplrt2cftnm53wd955raa93sz7x3xglr', 'sitesetting', '9-d9xhxcciptkxq23p7jczpf-1sogkyj', '2020-09-08 09:41:52');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('160', 'ybcdaacgl4ldu3ip32wgg9eguqslr270', 'getallpages', 'jg0fl7id-vw1d99ku4tgpscf2ycrn53o', '2020-09-08 09:41:52');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('161', '5xgkubtkk3bdwys14nreo7dzapapfl9t', 'getbanners', 'v43hm9s17dcjzie82rrguyhf415i2d2a', '2020-09-08 09:41:53');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('162', 'ydxtcz4vpmryll3kkqu-hm6chs4dfvz5', 'allcategories', '6-o98szik97zi1h-ck48u5z0h9mwgo14', '2020-09-08 09:41:53');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('163', 'c43ojg6zhrrsaloewfi3xjn5ypqrc7dc', 'getallproducts', 'ja7gnd2ol34ork9is3a8uqezkm81hj9i', '2020-09-08 09:41:54');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('164', 'jtiubfiu4fe8fy0uzkarif3mcv4jmu5n', 'getfilters', '97sazjfjjwcruasdjwkzvlehu7u2por-', '2020-09-08 09:41:54');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('165', 'xf63ak2lm3ljn398jy966wj3ox1kzcnz', 'getfilters', 'd9mjr92bt5mz-197pzfl5j1usq5tuuks', '2020-09-08 09:41:54');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('166', 'oexgn71w7i7oiijvmoh7y6wla0vb7ixb', 'getallproducts', 'f7b2umxi-sfgq57bkpj2hvcr0hl3ktyw', '2020-09-08 09:41:54');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('167', 'oqgv590m29oxukl5uyumhvxykyifs6cg', 'sitesetting', 's1irnw6vaim47s6sd570rmjp45srywmm', '2020-09-08 09:43:48');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('168', '9kqpwz103bzca-wkis5i14h85dpy37g0', 'getallpages', 'f2-ltri1k1o1hs0zbyoyzivj76ogkkoe', '2020-09-08 09:43:49');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('169', 'xe9c37j8wu-y3jklhi89cyjw4j3kom1s', 'sitesetting', 'ohv0026mp57s7x4kzgcmu5rdv4ia2p15', '2020-09-08 09:43:49');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('170', 'ppaxqrknm4hab7a7cg5kcp0n4x0iv7ap', 'getallpages', 'bicji4tnoreuq2hope2qi5ho0-0s5jsj', '2020-09-08 09:43:49');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('171', 'i6-b0juya37exvykdip7q5714b-u667i', 'getbanners', 'gi-chpy--fn1da7dzisv3hx05rx2yi0k', '2020-09-08 09:43:49');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('172', '1plig4z-e9637jl8it32lm-lndc00d2r', 'allcategories', 'k2u89ls9su5vy3f0tjsp34aknwjpwhgb', '2020-09-08 09:43:50');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('173', 'j20vs9m07y5j40f3rnn3rf26gl5iq130', 'getallproducts', '138snelmnu7g7sd-611plk8d-xpt9s1n', '2020-09-08 09:43:50');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('174', '5pxyl-ck73v00atplpjh812rc29pevh9', 'getallproducts', '5kai0qma20ometty88h-4n8ogi84xud4', '2020-09-08 09:43:50');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('175', '37r4ooicfr29d9keb5hg2h4x1cvo1dim', 'getfilters', '7jkvsm-p3oomwj0pydgxwswb9jr9n46l', '2020-09-08 09:43:50');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('176', '0w803i5q791po3q4aymff3w5rws4alh1', 'getfilters', 'x0xu4sp9hkwatk5arrt2fbdh60ly4h8p', '2020-09-08 09:43:50');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('177', '9jpxe7kr0stvq1vxg-129dzy9t0ikqbi', 'sitesetting', 'xyobrgfeng0cs7bm4jzck901myi80-h9', '2020-09-08 09:43:58');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('178', '1ss68quv-8pmtcqns63g9bgo2ekj19of', 'getallpages', 're6kl-keh4xicod7e9g0g4hb04lu11xx', '2020-09-08 09:43:58');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('179', 'by6-v0vu-bplqwzl44pa6v2-f-xmwhda', 'getbanners', 'gw3bm905zxrq-lmb281t4i8r0lq-6yn0', '2020-09-08 09:43:59');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('180', '6jw359iqne947y6azd2a6pol-etnaove', 'allcategories', 'q4d0811adrzkej-98ftuefv-vmuerz3w', '2020-09-08 09:43:59');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('181', 'gu775daszvey4be7jsv91wtgw33xofcp', 'getallproducts', 'ae76cklx1iuys6bi9u5om6iza4w4qm2h', '2020-09-08 09:44:00');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('182', 'u2g-dw7d9xdf7jk6gh3ahah2ugkys0as', 'getfilters', 'kq8k1jv4ns9plni4jj1uvmuoe1q92ntk', '2020-09-08 09:44:00');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('183', '3yw6l38ka7-cnbilvxtrvq4620tbqx8b', 'getallproducts', '1ebhv28rqus85ixa9f5a5lhp3sl0m93n', '2020-09-08 09:44:00');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('184', 'nc5xjrhuelofw21so8vacqj66jrpkes5', 'getfilters', 'u4hcq9k3m8pg4wuezt1jr37ejbo2531u', '2020-09-08 09:44:00');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('185', 'oguro5yd654n9nbr8w67z6yjwgcehmyc', 'sitesetting', 'k8dsqjibnlybosf3c1buizge3x1d3fp9', '2020-09-08 09:44:00');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('186', 'd65e4fxvd7r59559fcdd-awxz6-6iz2g', 'sitesetting', '4m16f6jwfr1vpl1ohbehxj3369egggr5', '2020-09-08 09:44:09');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('187', 'oufs5ce5nel6q3rpodtzucm4veajx-tv', 'getallpages', 'nqj6r65mr6wa6w8qdkgujo0-6onahs6w', '2020-09-08 09:44:09');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('188', 'b9jtpaqjpkyepz8-7d358o7cyrvwlj32', 'getbanners', '5mq18p3w4zapf4ynrkucg1jcjkkorx3d', '2020-09-08 09:44:10');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('189', 'mt7dfxru9d54h5znsdlpep9gqlprifgo', 'allcategories', '53j4yc2npbzavt-wlcv4047upzp99ec9', '2020-09-08 09:44:10');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('190', '3mwmt0qjmwrmxqd13kmn1etm9jkbfk7z', 'getallproducts', 'p-jm4fk4so1l5z57973k2nphu7cy9gyd', '2020-09-08 09:44:10');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('191', 'epmv18nd9cjlurs13acdseptdpv-nbc5', 'getfilters', '3-opp85npj9u8cn5qswoytucro7g4gi9', '2020-09-08 09:44:10');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('192', '0leplo2yheky19v8m01gibcqxgc2fs6g', 'getallproducts', '0bk81u8jt4hmb31e62w8ky40gbbq-wxc', '2020-09-08 09:44:10');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('193', 'm4e00unsuv36i-2adctu04w6mh3bwx-9', 'getfilters', 'znw-zd31kqzhw2mpl7c8j84yeixv85v7', '2020-09-08 09:44:10');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('194', 'lrbua1fq23nk8odmzv95g8rgzamqf6ff', 'sitesetting', 'cdg4y1h96d9gm6pwuglc4ntmylsjv3ig', '2020-09-08 09:44:10');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('195', 'u6bjijb6b1epd4u5e8dt8x87ysbt6qb3', 'sitesetting', 'a4eam7gyn3120-0oijta88l6-kjwn065', '2020-09-08 10:05:38');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('196', 'jxqcemo9sbtdzrhdm-kmw-63z6cq4r7m', 'getallpages', 'jkb28y2rz8tr9itkcexypnk9v3dxsx90', '2020-09-08 10:05:38');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('197', '3jub7ec6ehst88jlgkmm9vgtbq4q6pho', 'sitesetting', 'px2d1wpxpnbtg92i6pta9-jl6t20hk7g', '2020-09-08 10:05:39');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('198', '3r6t1cxrdbl-adn3ki1iydfpep7a5gg2', 'getallpages', '2wg3dlad0th8tchiey2owk68ybucqiww', '2020-09-08 10:05:39');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('199', 'ryv0k1x0sv6uhupvxzpydgoocw48xv8z', 'registerdevices', 'vkjh4ooewph7l95-f-isa2r-wssip33s', '2020-09-08 10:05:56');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('200', 'bp2vv9ebxmen9om062rwcmlh69yeqpt0', 'getbanners', 'hclb-98o9gbwjde7evsalpedz6pqovt7', '2020-09-08 10:05:56');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('201', 'mcv0k6yk2exywt5bynyxp8591cw5b5fn', 'allcategories', 'irbcx1-ivatzf8x3y1m7gth-4ff7veou', '2020-09-08 10:05:56');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('202', '4859qgijk3nu628tggyh8tpppwyfem02', 'getallproducts', '56312vl88jc10f6krhnjviktm-2r2jn0', '2020-09-08 10:05:56');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('203', 'iyks2s5wbnl65bm0s7-xazmt6hi3cr-9', 'getallproducts', 'dgdpdtfjabmsx-xphfzrd8jc04n94g97', '2020-09-08 10:05:56');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('204', 'nd31n7qnqrnq4ejhmijnp-8b03uc7kyo', 'getfilters', 'b3nmcjrqcl63iw04qllswdsb2ndq1kvp', '2020-09-08 10:05:57');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('205', 'sv6ihm676qti4rou43ncrovfmz5qd58x', 'getfilters', 'shhiwk10qnnr0oh4-03hd1yeqvx3npng', '2020-09-08 10:05:57');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('206', 'vh15a4btc4irsg5cvaypi9iic6ifcoo-', 'sitesetting', 'k3nkka7j9y16x1conf68zy0nqd9ap453', '2020-09-08 10:09:20');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('207', '6vulav03t7es6kr6m92e6unl0vx-i7dx', 'getallpages', '0hpi1d49iux8aatevlqm94rtjgrsm6pd', '2020-09-08 10:09:20');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('208', '0tjx19cofz2-m3jsjo5btybd8j637ue9', 'sitesetting', '6nmbaw-dnt2zq4dbvje8xcjzlke81q73', '2020-09-08 10:09:21');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('209', 'mk8y2w9rxzz1csov8p9v3rom-pd3thc0', 'getallpages', '-wp928o23rjljhgjhfuv5w0s2hpryhsq', '2020-09-08 10:09:21');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('210', 'ro4v09bvhyubvi6c8uw06x-hwtto7wyq', 'registerdevices', '09agm77h742fd2jl0mahd-wxy4swvsd3', '2020-09-08 10:09:35');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('211', '8b4ny4suwjq8nis25p2tsujtuigpm07z', 'getbanners', 'lueysic8bih6ajb15sfgiq9z--tnp3ao', '2020-09-08 10:09:35');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('212', 'gevxs2c8f52u17wxbgbkx7tagrtn9rq7', 'allcategories', 'ak0siv-r1mbj15wotgsm168wwsgjtbsx', '2020-09-08 10:09:35');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('213', 'adnvyqsqjhey98ovo425lfzr093ib96q', 'getallproducts', 'gi6lqco9qmyt007bt8-xxyqqbe33qv--', '2020-09-08 10:09:35');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('214', '52qfrub-f1qu0uauo-wzku7i6drpf49g', 'getfilters', 's-p43ys4tnxsl0889qmlj8y9mshekxp2', '2020-09-08 10:09:35');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('215', 'vaebi9v9lxkvs6fkfy88uagjjhr0amkp', 'getallproducts', 'lvg9ivq37y-olvvj8pyfxb1ce8msphz0', '2020-09-08 10:09:35');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('216', 'pxqsvy4i4xvlamqora8hwg37wiw1rzau', 'getfilters', 'girj0gv8jd3v8zxqjys4qd3j4ms3nvox', '2020-09-08 10:09:35');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('217', '924bxk1a6avs1jsf87b2cbr8ueiau30z', 'sitesetting', 'bxu0pj2ccbspou9cfb3jh9f14wrl7ahd', '2020-09-08 11:05:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('218', 'h57yvj094mc68kyi5684owukkzfnv56o', 'getallpages', 'h2xrh1rpj07utsru6o28tfp8war7mcjl', '2020-09-08 11:05:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('219', 'irk88mlxdo0z89t9m4-bg0efxtduwa0v', 'sitesetting', 'letnecwop8c9wqhq7xj-tcdnc4a7dzwj', '2020-09-08 11:05:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('220', 'td6un2zlp9f1-sf6k6f3677y2yur7xfq', 'getallpages', 'ohi5cwwnih922blhhmlervzomi36y3lw', '2020-09-08 11:05:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('221', '0rpwjp59t3oly9h7cq4f0385o-fvxl2h', 'registerdevices', 'x0f6gv01zg8lwm3-hnnruufo1eapnklr', '2020-09-08 11:05:16');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('222', 'dwqgvicblmub1so4pvogc2s3t64y9hhm', 'getbanners', '109diael4fepkaih2b3v5x-zlt98iu-c', '2020-09-08 11:05:17');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('223', '6ad1xc6rhmytu22iclfm-qd2r1pk5u-5', 'allcategories', '0a9gvpa3egumgvv4j-1zpjhcd10vat6q', '2020-09-08 11:05:17');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('224', 'oowcp8bwkif9s3qv12leowkc2ljca8x4', 'getallproducts', 'bhfrq1akwndl7n4p6wxvaw-jq8w61b6p', '2020-09-08 11:05:17');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('225', 'xhryko-gdfm0px1yx62ilwmvc7yxkznk', 'getfilters', 'e5hr6tlmhi10zwp8uqyowcmkvq1peq33', '2020-09-08 11:05:17');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('226', 'uxai7m0-pjsiokk97h7luds-a-77m5m-', 'getallproducts', 'uzq3rqw55hol46vhq2t2iom3n9l5r6av', '2020-09-08 11:05:17');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('227', 'aua7wu48fwudzth33x2jesi1z5hyt97t', 'getfilters', '7mlqueou6hnfibw6rmhv5f0ebtgp4fe3', '2020-09-08 11:05:17');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('228', '2x282epfo-exzu5lfmiop9902u7afvc6', 'sitesetting', 'ulx25ymsf0ay4sj9ptp4ctxvutv9d9nz', '2020-09-09 05:54:46');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('229', '7io8odqztxccus7504g5wmijd9a6dbbs', 'getallpages', 'a4la-sr0afug2mteyt69xou6uujgs8w0', '2020-09-09 05:54:46');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('230', 'xachziiuwvl2-q5mpaumtekp5ps0npfz', 'registerdevices', '05cdj9amsw1ddjvtkzyf9lqxl-bi6omi', '2020-09-09 05:54:52');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('231', '1-1ywhj8-7umyi8xeloveybqohnnsevl', 'getbanners', 'mg1jurkhjmheq3evoy3o4qz1h-ixfi-p', '2020-09-09 05:54:52');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('232', 'hgm5b5jv8ei6eh493dl5je0xfy62l7-u', 'allcategories', 'fuej4r0ey9olkm4qz1sh43jlyjeggmva', '2020-09-09 05:54:52');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('233', '1kcusgv-xow6ukcm15peqkctwi05cj2-', 'getfilters', 'td7m4krs2exznmvto8q6wpxzmmqnk85s', '2020-09-09 05:54:52');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('234', 's12z740m2h--sa64eglvs5thds8j70ne', 'getallproducts', '-z6hhixwim5nxiieg6b48ra3n7tvjo9l', '2020-09-09 05:54:52');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('235', 'l-3trno4p2go3s7hjoqb2kz7v3klc39v', 'getallproducts', 'uubkng5elajuopn4m-uftku9836692ob', '2020-09-09 05:54:52');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('236', 'n9-gyryqxdats-fs0fth1dwfzfm-ogjq', 'getfilters', 'ee-6xunypzufhe2y8swgdd8femxzyt7y', '2020-09-09 05:54:52');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('237', 'etb36o1be9l8pjs00ym8tejzcy9tp7sd', 'sitesetting', 'fqt39fzkbg86ma7w5xka1i59gukbz71b', '2020-09-09 05:54:58');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('238', '2aignu9vp4h-01x3gk4v2t-bv7xuiuwu', 'getallpages', 'r2ohjd5njaq7ugeac0817nco5ynow-p9', '2020-09-09 05:54:58');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('239', 'xufe9pkdcrmp2a1a83axqe4zpll4uo9r', 'getbanners', '4d0tlm13htexi4efx4p8wftnx220bsv6', '2020-09-09 05:54:59');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('240', 'xwr0ue27kneeguceh0my6ms7-02m2qg4', 'allcategories', 'u1okxku8dbwoj293vgmmrcykinat7apy', '2020-09-09 05:54:59');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('241', '7x-ua32-v2zvd4zbymtw-5-dlkni2rnu', 'getallproducts', 'qssry8xcze36e9ap-opx3adnm2l1vpax', '2020-09-09 05:54:59');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('242', 'sgoottummls7w3ry7aep712js313ames', 'getfilters', 'sew3drochap1pa3jtedusnavj5nabi1h', '2020-09-09 05:54:59');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('243', 'g1f180oxeyj4r2f7wiehfurirzidp96g', 'getfilters', 'rhuskdwqrjs8ydf1gxl25nkmu8o9bu4m', '2020-09-09 05:54:59');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('244', 't07sqp6c1yf9qvqwf81btvmatfp9aymt', 'getallproducts', 'eql6dwnic9zgnvssst5woh22qe2jh8hr', '2020-09-09 05:54:59');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('245', 'e-8yl-snt39qfvag87mhau4rzjcvjf9j', 'sitesetting', '7y7zxsmmy8b8zahw6r0331blsh85gyov', '2020-09-09 06:06:13');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('246', '36y9vtnvhwltlkv7ox-gf5psvjfj8vi1', 'getallpages', 'xy18vm-eq7qp9mwkbkcgnkvz-04hha4e', '2020-09-09 06:06:13');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('247', 'xjyq5rkd6lvr-jvwil-e0e33qj7pur73', 'registerdevices', 'v3ueoxksxqcdo6y00aohm1j2rxf2lnaf', '2020-09-09 06:06:26');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('248', 'i4tel933tvr1ap-dkaggvivq54m9so6h', 'getbanners', 'x7xuokqasac5g84hmjoakj3id-s42v16', '2020-09-09 06:06:26');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('249', 'lsb5qgypt8zpjkt3tuu-vbia0b20k4w4', 'allcategories', '1ww4qkg0ma0eogcdxexdcek4x9c8xa9c', '2020-09-09 06:06:26');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('250', '4igv1agumxn5n201lcg4--1plvpcnb5x', 'getallproducts', 'x4tav5jtimd9kcvg5xy5vnfsgsd0e1q2', '2020-09-09 06:06:27');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('251', 'u2-5ymxgno25j4lz5ep62lhsa95wd3dt', 'getfilters', 'km-6k73e5-h-wch0rbweiptjwy2l23qo', '2020-09-09 06:06:27');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('252', 'tdk00maci2p-msc4wkvrzrd8hqtr7ay4', 'getallproducts', '6j4l8hiwz752oi8ngdgmzsv0r3i28711', '2020-09-09 06:06:27');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('253', 'km6hp7dli69yz7w8hbmjk2akmddxacn4', 'getfilters', 'n01h3gwref8n2ov2p64u4p9gwo640w4t', '2020-09-09 06:06:27');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('254', '6bzzgpnt0sf242mn9zx0o9ieo0hacogr', 'sitesetting', '4wuneolhznthkb93z5ejcl528hm4mrqv', '2020-09-09 06:06:32');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('255', 'syov1ao1ani1yk35ja53emhe995-eq6u', 'getallpages', 'emi-9ar9buki6fy-g972lbggc9jxukj0', '2020-09-09 06:06:32');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('256', '2dibff16hds242qn6m7f9y2qjvhgkyxi', 'getbanners', 'rcocibmwxdgu-f881cvvfgsszyh3mo7m', '2020-09-09 06:06:32');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('257', 'kjiq4r8755ww6bjc62i5scvushva8qy4', 'allcategories', '33kyknwqqqk7v02iu5qkr18e7lydcehl', '2020-09-09 06:06:32');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('258', 'uxmuj35lw-os9j1ht12hc88e8h6p7b6m', 'getallproducts', 'fnoq8-lhz85l5c0eshpxxgvdzrg05usg', '2020-09-09 06:06:32');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('259', 'yatx04ck5y2xanq84v5j2m9uzhso5hfb', 'getfilters', 'ogr2ug5mefh3scw1em-mji15a-9y864b', '2020-09-09 06:06:32');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('260', 'n7hau1pl2o3340jnowebg8nwkt-eqb74', 'getallproducts', 'gkob-z-4-nxuew1qfnzzjd8y7ycvyhk7', '2020-09-09 06:06:32');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('261', 'bh7zs1kyf3ujljrtuh3sa86xyh2u164h', 'getfilters', 'em0oyz1ky0t9rgrzqa3dgyzqmdmdc915', '2020-09-09 06:06:32');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('262', 'n8-x4vb6jasi6jm08lqp0swuuo9-y7og', 'sitesetting', 'k65izef8eje8316hz31shmc3drgck81p', '2020-09-12 02:10:24');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('263', 'xro2bfxfs7rhs5c35bwfieoa5hme9u3b', 'getallpages', 'd6l9ymxyyls8fs5-klccl4rhi0magmq5', '2020-09-12 02:10:24');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('264', 'nixohtz6lfjj4z8xlpt5tmuk-1ox8hkg', 'registerdevices', 'se0yv3vb8wlphpocgq40dy06duluu4r2', '2020-09-12 02:10:31');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('265', 'bey2-n5splqslwyy3l-3cxl7ex3tylsp', 'sitesetting', 'k5niofpjluumrwje43j405l5ahigg6u8', '2020-09-12 02:10:52');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('266', 'x9xw1adodtjeitsuoqgq359uetq4mf41', 'getallpages', '-hb7lrkus7tz8jqcmx13d1ktmnajjav8', '2020-09-12 02:10:52');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('267', 'ejihk54faobbh59fn5rr5c6h6zmqnbkc', 'sitesetting', 'cbmiz1t1f1wwm9lca2aa4cglfvw2qq5l', '2020-09-12 02:10:53');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('268', '00kszpq7y1qdrn3kwnpry71ka8rumtty', 'getallpages', 'kd0esc3dt0b6qxaq5ccak5vgoa3bmrzq', '2020-09-12 02:10:53');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('269', 'ajdk47nld5hk19xa9fj0osu3e5rk6ov8', 'sitesetting', 'yvbxw21787ulzwn2yk61qo84wlftt6ii', '2020-09-12 02:11:08');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('270', 'wvm-lwvo3rofsi5p5b11kxmfsvvw60-j', 'getallpages', 'zdlyez2jafitjtw84o2yq9onojqn4t9w', '2020-09-12 02:11:08');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('271', 'lsg6xj010qe3ze-of0bzn1g1w-mp640h', 'sitesetting', 'sixuja0-ula8qdlzz206ahyto6qkf-4l', '2020-09-12 02:15:27');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('272', 'zk9ldvzlwuwknfo-gbnau3rn6wq427pe', 'getallpages', '0sx4bylh-z7kpied9688r6kmybpr6kck', '2020-09-12 02:15:29');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('273', 'euq9klqip5vo31moh9xlt8mz7a4s2aw0', 'sitesetting', 'dgr0bh4ovawkawozo3f1ubtrfywk097i', '2020-09-12 02:15:30');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('274', 'e9c6pqhkk3ipvcz2xtqaz614sdd13sq8', 'getallpages', 'qzc4bb3uo5sx-qf7z3fuawb87w254s4y', '2020-09-12 02:15:30');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('275', '9uk7mbrp3743vegms4427b0nhk5qn3qo', 'registerdevices', 'yl-o2uneztcizyccucytlzzxdnrlf8gh', '2020-09-12 02:15:54');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('276', 'o0d53ishuetb194yyt5ea2jlg8vieebg', 'sitesetting', 'r1yv45p10xs8v4vgxewu0irghibc-5pc', '2020-09-12 02:17:16');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('277', '9bncygh7xjkd6h2gca4j88xdul6ynbfb', 'getallpages', 'p08uzkj1ixl2znhpgvmt71b35-dg2m88', '2020-09-12 02:17:16');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('278', 'to28hnod-kpzvwvrotljgyy65g8j1hwk', 'sitesetting', '294i4pqkg23pyy0e4ulj6o8q3ppn6a20', '2020-09-14 06:14:41');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('279', 'we9p2uxnq4k9yzelq-kd05kam-zk5v1b', 'getallpages', 'e1jjoav-l91uaatbihv9n-5feprx1cti', '2020-09-14 06:14:41');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('280', 'bkbbpc5snclazvcammzkhn3g0cai77em', 'registerdevices', 'hnxmd-4xhc870rt1pesdduwadjr4o-vn', '2020-09-14 06:14:48');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('281', 'yzkdwlrumb5y1kfjy4fouyjkwmq-6d9u', 'sitesetting', '081k6nnk9q8nsky3d3wu4g7wrfmujjuz', '2020-09-14 06:18:32');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('282', '-7kiiq-rbe7507gqwckbmj53dlq8lhx6', 'getallpages', 'cp4zgu08otykoraefw6aewekcuhw2yeu', '2020-09-14 06:18:32');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('283', '14cxb-k97x0g823lrvzuq3cmuelwugyg', 'sitesetting', 'o5l2493d6vdw3tbtcnjjkr-wa8drvojx', '2020-09-14 06:18:34');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('284', 'f15980n8s4dqsj7b9qds9sg87u08oapn', 'getallpages', '4ml2ac2bnodf1k3q9n72rqniu-6kh-mz', '2020-09-14 06:18:34');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('285', 'urrqhv5jj-js0af-yy4qosdxivhj3yl3', 'registerdevices', 'bygvl48bxqsmbksedsqk7jdowb1h1ud-', '2020-09-14 06:18:40');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('286', 'v9tlbl6o8e8i5hr63p72k1f99yqdh1ta', 'sitesetting', '8zo4gt5nj4p85-9hk2qh9y9abnhy4-jq', '2020-09-14 06:03:49');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('287', '1wvwxe44xfnetdykfmkialf9k4cnnxun', 'getallpages', 'd-rbwkgs26s7g355w0nd1ajveu6bxws-', '2020-09-14 06:03:49');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('288', 'ao-qldprtnxjon1y1mj47sbzytrke93n', 'registerdevices', 'vfhfkpit5z4zpjh6rqy69heygzea96cu', '2020-09-14 06:03:56');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('289', 'mj9f5590a-v6emiyhldjc1hhm3czvvno', 'getsearchdata', '74sxbhcc3jt8jvhovlzx4mgiq92i6niu', '2020-09-14 06:04:05');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('290', 'k0fpv-kc3-yapjl6vdi18ccxc5c9gzsf', 'getallproducts', '33b-rmfl6otup7b43ffz--p5fnjugm2l', '2020-09-14 06:04:08');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('291', 'th9chdojp-xhvo5tmlxaf0ejgwm-9k2b', 'getsearchdata', '4g5ocxio4wjlz1--vqw1n0gydtg86onq', '2020-09-14 06:04:26');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('292', 'rzr8-amjzk1o6dfxbwso4xmzrraf0btv', 'getallproducts', '-e3f6kjb7e25ulde62gmgwukf-1x9meq', '2020-09-14 06:04:28');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('293', 'z7f-yq-b071anu9dqmcdiy4o1wmzrsti', 'getsearchdata', '4v7kgoggkccox97wiw5ee5flr9se3uta', '2020-09-14 06:05:03');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('294', 'yj7la84a1824xl0pdb6h325rmmvmp0nx', 'getallproducts', 'qhnp30mk5ojqy7qznd1jl10x8b4nng1j', '2020-09-14 06:05:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('295', 'mlbnw0hvguijwws-q95so7ozz3gcpcyp', 'sitesetting', 'iic1qty--kq1-d-wukgce2p2bktm9bm2', '2020-09-14 06:10:10');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('296', '4nlilso9z1ik1d6145ebggj1frtr1n-l', 'getallpages', '93s8vv3adg8zw0pnk1lktzr1mspzabqm', '2020-09-14 06:10:10');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('297', 'ppvdtawjar-hecva4ol4rhah9xipa7ui', 'getsearchdata', '6zknz8kkmitii56t216zhdmq00-isfcd', '2020-09-14 06:10:26');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('298', 't5fxhqwmnfq1oadsrzd0hcn9a0y6b44o', 'getallproducts', 'jv16s84clsc9oo0zacsf51xvej5-p1wu', '2020-09-14 06:10:27');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('299', '9eeqtvoofedu2o7agjedbt6rtxo38-pt', 'sitesetting', 'jbr6dqmv9eaifd4udo9t5koot70hf0ci', '2020-09-14 06:11:47');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('300', 'g1072x6be6sgqtd2pwx71j8kw4z6k6qe', 'getallpages', 'z293n2nygwh7huhf-y3xmsr-bdv-e04c', '2020-09-14 06:11:47');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('301', 'fs5yzmfnre-zjvi8c2oafcypa96rru7h', 'sitesetting', 'vcg4ztfitxjhu1mq0pewdcjef2-l7jw-', '2020-09-14 06:11:48');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('302', 'q0zgladf7umkip7ymp3jeupkogh8i64r', 'getallpages', 'jddsw3t7gk7b806u20r8jddqe1nnora9', '2020-09-14 06:11:48');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('303', 'nuolkv3352p1hgk1hl7jp1i4y761erbf', 'getsearchdata', 'c4d5wjtz5-2040m77p068hjv6qjopenf', '2020-09-14 06:11:54');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('304', '5ubcricoygzrx4dm26uek5t1mok6h0h7', 'getallproducts', '2qzesfhx8bji2k6hcnx5foi8xby2dk5t', '2020-09-14 06:11:57');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('305', '6mr73pkk1x3-mnc7fm5eeb2sow8iq9il', 'sitesetting', 'vsn6k351dc80olz09frwop-egvoz9bx0', '2020-09-14 06:14:04');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('306', 'nhah-hik60yd4gt1y0phls3ittpje5fi', 'getallpages', '0tpeywj3xx3l7yus8pd9k8mkevi343ur', '2020-09-14 06:14:05');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('307', '3kt-t9p2u9sr2jvi8sulgpmdzz273msx', 'sitesetting', 'xe59jaj8qzf1np4kio1ruai1a64w2hjc', '2020-09-14 06:14:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('308', 'irc1c9hkjxu6tnvha95ber-mw1-tfdb6', 'getallpages', '0l8982ei7ekneegzmq-28a8nqfi044rc', '2020-09-14 06:14:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('309', 'tdgtv2u0uwk60vq4ti0y7poar5sj2d06', 'sitesetting', '0ami56j0g8aqrxykes-xnny8fuxu-lek', '2020-09-14 06:14:15');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('310', 'b4mtk8uepi2cgxzozxytohjlanvrf75q', 'getallpages', '2cf1jkvrzdquz-4kxpw5w3xn5bvtt7vw', '2020-09-14 06:14:16');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('311', 'c67lly9h22281fgfv3o7a7ug0z8iuqg6', 'sitesetting', 't22fko3c1mxfd0d46ftstm144j820v0s', '2020-09-14 06:14:16');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('312', 'q1f-fkyrhdjdwusavowphsvq7908a0s2', 'getallpages', 'm6fgdvqtjax0gsh3lo6f6j0qpss2px8w', '2020-09-14 06:14:16');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('313', 'deqsqd4lluo8pl22waf0dh-wcf42wm8w', 'getcurrencies', 'uj3w3cfa3moia9ttw607-dwe9s419t4o', '2020-09-14 06:14:42');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('314', 'rqdgos8sep1opqu475qcl24u4qbv0-mw', 'sitesetting', 'j4mcv2dwabpmwsahj6pcv-d2unjwfvb9', '2020-09-14 06:14:45');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('315', 'eyc2rxvdnspbv4tt3-zu7r47jesch6rh', 'getallpages', 'wzre2fk6wzjuoczlfvr2vfuo0wdog9yj', '2020-09-14 06:14:45');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('316', 're5oxoi51mvbpkswxcj1gvlckbr6qyt3', 'getsearchdata', 'y4yyp9avdf7qv9e6xgl5ytnfazpns94u', '2020-09-14 06:14:51');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('317', '4hfasd3clcsly0mku27d4zuzvh4djygu', 'getallproducts', 'et3-egv0kkcpcn0hn-01l6bro821k3rb', '2020-09-14 06:14:52');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('318', 'vvqmbyffhqzsgno2jyud7lk08v8407x2', 'sitesetting', 'imyw5p21g3vi3pxb5pzz1r3lakn48hdq', '2020-09-14 06:16:59');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('319', 'm2smg7p89usdz41pan9-k0mz91--fode', 'getallpages', '2s-foc6nc1k5wwqd95v46ep3yomxukvh', '2020-09-14 06:16:59');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('320', '2a76n67ujnuqqrr8w7jyglcznler1tiw', 'sitesetting', 'otfw49g0h2f3crojh3l6liz-s23u0ht2', '2020-09-14 06:16:59');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('321', 'anfy3hplnnkbwxmupaot8k2f8jmay12u', 'getallpages', 'iqwvmbsmts7s-41bwueekywfmsihnr3z', '2020-09-14 06:16:59');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('322', '2df5wk93p3h8je4sjy3e41y8u50zilvt', 'getsearchdata', 'd4azecfnrsi3pnjhb5-7pxejsv2wia4y', '2020-09-14 06:17:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('323', 'lhgm5kfi9diub0xqq3rjkk8u61vng57p', 'getsearchdata', 'em5ek5k5c5kv7cl997-wpgitz3r5ae3f', '2020-09-14 06:17:12');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('324', 'q-jbym7otuuitw4cpyzuffyyty8-r9bm', 'sitesetting', '5p3avgw20qtpgesub5lx1rpjmpujp6o2', '2020-09-14 06:19:54');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('325', 'q4z4dkywd5l13sdp42md3wh5vi2hwt38', 'getallpages', 'n4-dwffxt6sfupldyxlt-rkrog2dmcbu', '2020-09-14 06:19:55');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('326', 'tqv1bq5fpmkro-4r0rik38qqhkj6c34s', 'sitesetting', '5c854f1asce3nmkfywzdodtvznp59geo', '2020-09-14 06:19:55');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('327', '9pfrs49lz-3jj-ll7ejaa24ofi5beugx', 'getallpages', 'iwl3eu4r9cgjinzies8ph1jovm34385h', '2020-09-14 06:19:55');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('328', '3lod9j2a3fh4uglc4dqze2qvjxqe812r', 'getsearchdata', 'ctd3tth-lmiy5q6ze-ca-mgvlc9g7b4g', '2020-09-14 06:19:59');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('329', 'z8bv5f6bx5dpwqpm61vaaaop0yobo2hb', 'getallproducts', 'ddmavsb6fxzrq-10czhbo6ljsiexki7r', '2020-09-14 06:20:00');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('330', 'hobrmg0ealqvu6672q9yshh0iqv7gn0b', 'getallproducts', 's4jsjy06af1l3252e7vod4mix49blf2e', '2020-09-14 06:20:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('331', '2mabu2cb9iwvo05b3l1382tx9ig2ah4n', 'sitesetting', 'ia2gagl8vf-5kx6obi40k6tmyea6pfgn', '2020-09-15 05:47:53');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('332', '7wmgk41suulomz8lq-fco0gbnuddncbb', 'getallpages', 'oage0r2hf6bf5js-4g81r7ajhg4lzkvz', '2020-09-15 05:47:53');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('333', '7xp8427pmup4elfs4s015nkxgb6-348s', 'getlanguages', '3t46-4j5hdr9db6tl0re5li9rgeq7myg', '2020-09-15 05:48:10');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('334', '6nvhkt73ro5qiw5sejldlnv7oci-fjbm', 'getsearchdata', 'dh9es58tko2yveb6pj3078xgeyt8h7gm', '2020-09-15 05:48:22');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('335', 'toy3lnu9taard0xc5ois6-m9cpkscs48', 'getallproducts', 'g14hh8p3r35x9lo9oz8fva6achftxsmq', '2020-09-15 05:48:24');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('336', 'p5z4q-vfa45q9p-fkwmqwt7a19dbwhfm', 'processlogin', 'o43ziar6qe5ry8jhm-z6tgtepdf2dmx-', '2020-09-15 05:49:25');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('337', 'b-ces4urdpt73r5hxa9pq4vheej4nqkv', 'processlogin', '6x-se8gacloj315xpg-s85269gx-sdat', '2020-09-15 05:50:16');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('338', 'ztc25h4ffk2s6lmzm4njspd3o5wnohw6', 'registerdevices', 'eo5wjzo2jv8t8ryqk2ai8ev7ffdk7p9z', '2020-09-15 05:50:17');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('339', 'sx-oi8vie4eucj9da-ty8krtj-zhzztv', 'getsearchdata', 'i24b5f5px43udcpft1ggdoap6zjbp9by', '2020-09-15 05:50:29');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('340', 'r23xkjc8cfo44hu5k2a5w6byghog4n7y', 'getsearchdata', 'e1gktd-7f2qpjj61qk5lk9zadpie2rhq', '2020-09-15 05:50:36');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('341', 'wsa6bx49ava58ki-s53ucqqpn9i7700k', 'sitesetting', 'ytw15ieua1np31z-lgddlqen7fv9xp75', '2020-09-15 05:50:43');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('342', 'mamkwj9ya3b2l0xz8je7rjfr7g2nbn90', 'getallpages', 'tnb9kni0as2f5bw75-we0c2ykkai9mow', '2020-09-15 05:50:44');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('343', '0q38p7vcn5ao498j1l94ojvtjbsls-wk', 'getsearchdata', 'nq8lqpccko09567lq0z-buzmru8dme-i', '2020-09-15 05:50:47');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('344', '-2a6tv7j5htiwctz3ysji5whigye4lei', 'getsearchdata', 'lkerr1u9sl5f26xjy0k9a4cg2vylugfm', '2020-09-15 05:50:50');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('345', '392j8n19ca6snmsz3s80e1c3fhinym8r', 'getallproducts', 'wrq4pw9rj4y2bfqzuqphg1-xuv5nyckr', '2020-09-15 05:50:56');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('346', 'zv5-my6436bulwg3zsf7za05m3kmirbn', 'sitesetting', '14326q7on6r2qpchtwlz9fmrg-08-x5r', '2020-09-15 06:13:23');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('347', 'qz14h-cvrmjor5fdjj6-6xvtrjr27gf7', 'getallpages', 'xpohj0glfoj-n36akte5v-h7fy3iqgld', '2020-09-15 06:13:23');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('348', 'c1wdq51i6wa2k4ivg0ny2murmz594d8i', 'sitesetting', 'j-zchta95-7fs-24ljz9qmktrawcbsa0', '2020-09-15 06:13:24');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('349', 'clj9d1q7uchxy63nn0keml23v3udwq6b', 'getallpages', 'quic4gb0x8e346tpl662i5z169w9zev5', '2020-09-15 06:13:24');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('350', '9k3znlp9i38zuutewa61nd7ruar5470f', 'sitesetting', '3kcpzm3j58o1v39vmfk696mugik76zad', '2020-09-15 06:15:59');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('351', 'mwc1kd4u2uz81r6rj5aqg6domc-d76g4', 'getallpages', '9oyl3aghsolalf0buwj5n5ksen3pa0em', '2020-09-15 06:15:59');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('352', '2pb3u37mfxbt2k841dbujf19op7nieaw', 'sitesetting', 'i0vi9wt4zo2pcnrq3axfxs4bb3pcqk8b', '2020-09-15 04:41:44');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('353', '5piz8so32zhep6zm1gu3lkp9n-9mvr03', 'getallpages', 'sr9aowopvam5qxqwwqm44s2kllhbqrlw', '2020-09-15 04:41:45');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('354', 'cnlf0yr9khmnk3j1seb0rfzocucjcer2', 'registerdevices', 'f30p0jrrcq87rhtzm46li4bzrtdxilaq', '2020-09-15 04:41:51');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('355', 'rnifue8drt2kq53o6p6n3y2x8fr9w3iv', 'sitesetting', '-79l1224uod4m81ife2p82mv1dp0grgb', '2020-09-16 07:30:15');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('356', 'lyoz8er217toziv8xmoeiowt5di9f6ty', 'getallpages', 'sfauanzwp3zro7y12f36xoq6raee92qf', '2020-09-16 07:30:15');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('357', '7pt5dotip1tj5or6-e3fwfn0jshm8duc', 'sitesetting', '8prnu-rehjf2ua9hz4k4w258ewoulrku', '2020-09-16 07:33:05');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('358', 'wwp5oe8lkb699x2z3i77nrgu2ms24qft', 'getallpages', 'gcx-ikyr87txaoirmj6nyqo-sgsttrl0', '2020-09-16 07:33:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('359', 'fnzv53n-jfk-wwasugfio-z8u3aipzv0', 'sitesetting', 'edtthre3elieyuqr5ktswn0qk7vvbwyn', '2020-09-16 01:12:16');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('360', 'rqzefpr4fccppi4jhpn5g4vqe8p22uj8', 'getallpages', 'l52bxp3m5icjg39digdw29a79bpy-iwc', '2020-09-16 01:12:17');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('361', '4iy3bpzvo1o9uk345kbwp5iei2uow39q', 'sitesetting', '4452c9usyyx5dtsca428ifgdyjmc70zb', '2020-09-16 01:12:26');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('362', '9oywlfwl6ki2joa2pgpe57uxc0mjvnqc', 'getallpages', 'sgn-hg0m0460gtsx--szgauj1btcr3dl', '2020-09-16 01:12:28');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('363', '-gmjlc1l0cfwkbkdlvx402n0sg-plf8a', 'sitesetting', 'ap-qetsvx1yg6xzwche56lyg4soykn9t', '2020-09-16 08:10:57');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('364', 'tvc5fzk87ltpfl-z0ar46ulmdkpcwyxi', 'getallpages', '45375jeao5-0l2x-3spn4jhx9do1xwu1', '2020-09-16 08:10:57');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('365', 'nj0j7rz2dqaan0jxml2lwuemuy4fjuu8', 'sitesetting', 'i81xrj7qnnbkypx62pf4kfsd-3hl4ae9', '2020-09-16 08:11:03');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('366', 'on3g6kank45il070ommm90o2mkrhb6jo', 'getallpages', 'ns7aum81tb4p6a748wej8txn3-vyy5ls', '2020-09-16 08:11:04');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('367', '0ekwuu7v9zrd74bd0e-hpwiuuyxf1x6p', 'sitesetting', '3cyzp9-13nsarw45x9ayo1ach1nq3dkx', '2020-09-16 08:11:10');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('368', '6zcbxiefs18bhjh34is-3axilkpj2kp4', 'getallpages', 'inumsw8-p79gce1g6xnmonxlsxx7-qn1', '2020-09-16 08:11:10');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('369', 's7an0sxrddrw9ei6fxbeehbsawrc6fpr', 'sitesetting', '7gdjpad5faxjzifg1q5fba2dozmaupzk', '2020-09-16 08:11:21');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('370', 'tks76qidoyzbxdo9pj4y1a-jowvdnoep', 'getallpages', 'uygiswn214r1456kuqibyq0s088amsby', '2020-09-16 08:11:21');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('371', 'paoct-9hs0zbzz5xkh8--b5xox3-ln4l', 'sitesetting', 'nrwnjz1b--5hk2q8o2t64-v-rnspz4h1', '2020-09-16 08:12:07');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('372', 'wbwhnc0wlk8rzaiwj641u4h-g3vn6u2w', 'getallpages', 'jj-vjh233195cwbs8x3i8nyoumq3oxhf', '2020-09-16 08:12:07');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('373', 'f3aq-vk5mxt6l6b2q-r5qpdv3sv-likh', 'sitesetting', 'p88thkwr0t9iu5hk-x4mwbgnhfobdjsg', '2020-09-16 08:18:14');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('374', 'p1hvxghx4huj5h31tlovqpozx-7rdbm8', 'getallpages', 'b7-lmt5398m2m1vygtox9iu4yjhtspj2', '2020-09-16 08:18:14');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('375', 't083k6iwjtiofl7l-vei1g6l8elzhvnt', 'sitesetting', '2bz-86oq4dman2a19txmj-hzpdp55pu7', '2020-09-16 08:18:20');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('376', 'hsg2pmxmg4uf8v2-iev7e6kwews4x3sb', 'getallpages', 'yj38-6ndvp1iq3t0y7m7d6vpw4ewogx1', '2020-09-16 08:18:20');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('377', 'zrvx-r5sf5wkqoqz7rql01a939huhtvx', 'sitesetting', 'awf1b92-n21e9lydnt0-gliscllae7ff', '2020-09-21 09:44:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('378', 'w5ozsls5ynuqnitcrfyynxdfbixa1bfy', 'getallpages', 'b03hfkx6ienqh8hqwhxuvv-do-m29ym-', '2020-09-21 09:44:07');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('379', 'z9-qjs3yedb4t4nihis24a8n81sk64co', 'sitesetting', 'alyxmy4c83jgmnr8lk1vsel5upg3myao', '2020-09-21 09:44:15');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('380', 'kk7erquka612k7liqie0djjbb1zukrpv', 'getallpages', '2436v71oq7dhpgtk3lw1j69monhyjed-', '2020-09-21 09:44:15');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('381', '8n-9kwqotvgcmm755cnk4-gwgv007q-c', 'sitesetting', 'u7nyeiq2zw5jk68la3gdpyhpu-4oz-2f', '2020-09-21 09:44:21');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('382', 'ro74bx1-4ucen70cxpn4r9lwn2bqfq0c', 'getallpages', '5qzi27yfu47ebz87gs83uxc8hrqqa199', '2020-09-21 09:44:21');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('383', 'ce-wgei-p11ks-p-4iglmdqk0ptu03cw', 'sitesetting', 'v968fvt4f6cz7hgjxzkcaw4y-rrsh7d-', '2020-09-21 09:44:29');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('384', 'whikdqsyzyihv1l7oqh02ew4i2kzwkl7', 'getallpages', 'urkyk-bg0a2egs9raw8ys6yc2pe4g8yq', '2020-09-21 09:44:29');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('385', 'r7m135w1hs8gyvg7gbrhdaekmzgxwerw', 'sitesetting', 'z0dfn63o8y-kd5en2giyj19zvh15svpk', '2020-09-21 09:44:58');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('386', 'domszjjbbpueraoiox57eaz6knznt7ot', 'getallpages', 'lv8fc3hincs3fpzjc9mgzu4ar8w8en8g', '2020-09-21 09:44:58');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('387', '8exuhxu8z0lojt0-bk-dv4r6oukmkyj6', 'sitesetting', 'a63oqz8-xj7qckvqgiw4zot-shisi4v0', '2020-09-21 11:34:15');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('388', 'r34qh6j8q6agv9cqj3dhsrf5j961u421', 'getallpages', 'rtzwlqbn3xf0sb7e19uk7sv8srplub84', '2020-09-21 11:34:15');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('389', 'p8zbjx195ngdf2icqjp8e-joctknuz4f', 'sitesetting', 'zzvk22zs4vvd0jd36zqb-be2rwcv78ea', '2020-09-21 01:18:02');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('390', 'uz3b1btsozg4ftl4m38e5pzf1j1--pxa', 'getallpages', 'ofc92e49e2njvf3pl9ygm4l9v10plwr1', '2020-09-21 01:18:02');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('391', 'mev85yb7fvba9xh2fohq6cie5b-httbs', 'sitesetting', 'xd333l-tgemxe7b8sbg7bps6sysoip5c', '2020-09-23 02:46:20');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('392', 's06fmrcayprjullpt13x4ugy-ag9pss7', 'getallpages', 'fm-5jwyou15x3od0xgholtr6vpb2bolx', '2020-09-23 02:46:20');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('393', 'zei01wuq83dqwclsl9f-rdxa8u0jshj8', 'sitesetting', 'uvtum36w7edlt9xjr1sfz3eiheq7m2d7', '2020-09-23 02:47:18');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('394', 'qhlkfh4gddu23ehhaqacuwtn-oj5yvjt', 'getallpages', 'yt56u1igtl-khaw610edrupikb3h0o20', '2020-09-23 02:47:18');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('395', 'pvwnrs01ubtzznxmnkyykwj8gwsiprl8', 'sitesetting', 'yis4h0d20bvpi8hq0pqak1kk2b9mjyv3', '2020-09-23 02:48:44');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('396', '180zuepc7--fan-yp6ru8evaybszjyyb', 'getallpages', 'j4v01ipooib2jatosy609d99-xdpxwda', '2020-09-23 02:48:44');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('397', 'gcdk29s1wvp13svw3xnnjli6vnr09h1o', 'sitesetting', 'cniw5dr-ig5ikstjnil13zavofm0n-yr', '2020-09-23 02:57:26');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('398', 'x8o1rhsguz2gb9ca1xg5ljeff4xxg6wy', 'getallpages', 'z371g2wpa8sbc1zsizrbaqx0385g221o', '2020-09-23 02:57:26');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('399', 'l5zi8rcl6viu8ke9ccga47oko3elwuhs', 'sitesetting', 'nzz89cpeqdj7gezyutu15kdilhykwgo9', '2020-09-23 03:21:54');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('400', 'tfb8c9sogt7al0p2a-6g4b498z6txqdz', 'getallpages', 's8ocmf-tzjsh9aagk59wi-8lj32wkimr', '2020-09-23 03:21:54');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('401', 'lea-na8t8cdlfjae42gknu4z0-dpnxt3', 'sitesetting', 'm0-at4qasxi2khmt4iiulkg3z7ze4yx9', '2020-09-23 03:23:18');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('402', 'oq3b581x-nqfuhjd8s0tl34d99x98y9c', 'getallpages', 'f2n0guifjdaf10jilgbevx-9b8vkimzh', '2020-09-23 03:23:18');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('403', 'ia34xvdhzjh1t7h-s5eaipy7x5-mr5u3', 'sitesetting', 'b8mcdrxasidl70hgnahq5x3x4oi4bcm8', '2020-09-23 03:24:43');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('404', '6j1vwpz12q7aqodvsr7bpezovlc0msnw', 'getallpages', 'xwwp02rk0uinatq5822n6wqzd8dc58b3', '2020-09-23 03:24:43');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('405', 'sm5lgip55jcn4lmj9gp0km2adhs2qlc2', 'getbanners', 'ihx6ybbons12ixxqbdsr0vuyj7l3tfe4', '2020-09-23 03:24:44');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('406', 'nvaw0cxolzz2beq5x3wilrwaof63zxqs', 'allcategories', 'ujtscat01ux3-k-tvnw1qfpi1-8y4h52', '2020-09-23 03:24:44');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('407', 'thfmoz8y7717pg7iuq2vg4au05s417hg', 'getallproducts', 'mufd2rxlq-obukl464er1aymp-y-0vqw', '2020-09-23 03:24:45');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('408', 'zpmjt1m-p4ohhtg-o-olzu954r8f797z', 'getfilters', 'rhmrmdpm8bttdo8g88lg7oa9162o6mti', '2020-09-23 03:24:45');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('409', 'eoq1uvmgalb-esfvjs6lqxwk8e7d95t3', 'getallproducts', '-1s53b1fe63gr6q1g-42to8bx7b688e8', '2020-09-23 03:24:45');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('410', 'ddoan45hx3g53ebd4wa0-xmduhiw2vrj', 'getfilters', 'ruxo4-t7prtoc4qxkbng75p4xbv7pc5c', '2020-09-23 03:24:45');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('411', 'syivybl0rkzg-w3s554y9ftfifcz0f3v', 'sitesetting', 'q0x4favb09ldn1oks8krh48cixootesz', '2020-09-24 02:38:29');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('412', 'navmitp0x5a6nhlin-qn4hz5nhd-fa01', 'getallpages', 'fqn2hge3an3xye3pdhx402zg6q1fpwaf', '2020-09-24 02:38:29');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('413', 'zp08rfn0chiy149-s36r4tjcycy9xty6', 'sitesetting', '2vn-2ugkils6qcrzdpmmkqux3zozyure', '2020-09-24 02:39:47');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('414', '0izavom0m3ut99ijuu60kntwzbvs09ho', 'getallpages', 'jzf52orfntdhz7l-ruh2hwxroojqj48k', '2020-09-24 02:39:47');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('415', 'z9fa9r7v7xqfy-sn5xzc1ggav96qyqay', 'sitesetting', 'my-vjufxtmluciux1mt0y9cj4sntg7k4', '2020-09-24 02:40:26');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('416', '6bkdh2ze1pz0fgcxu6tq4dqvyybawnz5', 'getallpages', '930c0to2l5gak0pjts5gtsa4xsixrul9', '2020-09-24 02:40:26');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('417', 'gu7hz6hzm4dxuvb66zc2-tim792y-nnl', 'sitesetting', 'pn2pfi2pnn0zoy1d2sim5nlwanpphfef', '2020-09-24 02:41:25');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('418', 'kb7yp5out9vfc1lbduc6j32l2om-g1d-', 'getallpages', 'v5no27xc8764wsy706aurukf4ktj-vfk', '2020-09-24 02:41:26');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('419', 'sjyba6bkr3io96pdxptnp5qczehvepgb', 'registerdevices', 'binnlx3zgdfuyjgn6lj3sn0lk5aoxitm', '2020-09-24 02:41:35');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('420', 'artezbyjklxcybwulmj0hfiko7c71j5z', 'getbanners', 'nuxuv7-xa-csmv7-s59-q74502sjh0wf', '2020-09-24 02:41:35');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('421', '0fauznynsjb6-nm6s7oj2tdtm9nifhxz', 'allcategories', '54i9c484nhbi39yf7sxrew9m5whbbx6t', '2020-09-24 02:41:36');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('422', 'y1crzqsqu3wnz81-4msyir09h3a13o83', 'getallproducts', 'psxtjxyxt364paoa5xmeqnh6pg3iihoh', '2020-09-24 02:41:36');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('423', 'ongpue7q5apfe1dkyfqm5acmd2xj2oha', 'getfilters', '-v1ll9n42u5g0ok62ulubxo397s1b029', '2020-09-24 02:41:36');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('424', '9n2cf510mp5l5nqzcciwmvu5ab8unigl', 'getallproducts', 'm9m7emjfm0ddr727v2b9rs7-fhm6bbsu', '2020-09-24 02:41:36');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('425', 'ujobxsv9881q68h14srnenoh6woowfv8', 'getfilters', 'w-gzu42tho-5u0c8tj6i7pj7qu2-tgvg', '2020-09-24 02:41:36');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('426', '8hxpzz529-1wtjlhurhotgju0yocr8ks', 'getallproducts', 'chwtygqw1az-b-fmp39acjfdevvzx-kn', '2020-09-24 02:41:45');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('427', 'iz64s1w40scdrsplx22gpwitoqv5ix9n', 'getfilters', '5flhrnkkxuyq--ek5047pst02b-1gvq1', '2020-09-24 02:41:45');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('428', 'sf9xf-7z5wfrxb623n7dv08793yy5bn4', 'getallproducts', 'p5iu3t6cmzketm2xwoilbwm-vd2h9ukl', '2020-09-24 02:41:46');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('429', 'r3ulkyd4huwpk69iz5kfn-ev1-k8an-6', 'getfilters', '0ww-nx-e72ermlu887p3va1suivy861d', '2020-09-24 02:41:47');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('430', 'ccb0lgdf6v3e5dwwkb629r9zubtduaxu', 'sitesetting', 'sui0qzovzh-webpk4x21ktm4qtcz-qm5', '2020-09-24 02:42:20');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('431', '14sr45tvtb3dc22lioka9f6akaw3mnmh', 'getallpages', 'ejb1kqx-0ro1nxp4t6bv4ridxrk9m3ob', '2020-09-24 02:42:20');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('432', 'xmdry0d917u1hf3g84g88o5r6vn7l9g-', 'getbanners', '8vmdrue7e065royq225d-pnegrm28uhs', '2020-09-24 02:42:21');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('433', 'oh05ut3ttq5v0ko1tx2kgljb01qj89rz', 'allcategories', 's9slbotk4mpryc2u62pqmy4v7vyi7r29', '2020-09-24 02:42:21');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('434', 'h3m2z0759o1g1d-pg1i1n1n82b2dyiqx', 'getallproducts', 'z9n324dwwlcavny7-1z-stvmsz4vbgc6', '2020-09-24 02:42:22');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('435', 'qarhx-wl59-ktcx550vsweily8qcy140', 'getallproducts', 'mhn-0spccyii898szwz6qyt8u74sdgda', '2020-09-24 02:42:22');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('436', 'yfzo0qde7-oraqmqcov0j0fbqqj8v5l-', 'getfilters', '922tkg7iuj8lgkeg7-1t0vayiq1m5hmb', '2020-09-24 02:42:22');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('437', 'skou-h1vjudn3gbv11b-z4imlnajbd04', 'getfilters', 'j67lfmnd7d6c4ph8n1pqxe0ze92ikyeg', '2020-09-24 02:42:22');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('438', 'pez66etsh7xvz22d75dtp3jn91z2s4tr', 'getallproducts', 'ivso41qiob2k5lracsyx8j8c5yyyz8wt', '2020-09-24 02:42:28');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('439', 'ovtmo3hps2qj5pshdh4e3gshkc8iwnor', 'getfilters', 'dk2ukgjzszcmmino3i-zv5tk-cwjrbvu', '2020-09-24 02:42:28');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('440', 't1lmtsdhhz-1n8mpnc1pb6ir99ffhx5b', 'getfilters', 'v8gwjf8aj1yvi01ak5zimgovy08ybwod', '2020-09-24 02:42:30');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('441', 'x3veard7xjyqh6-yz455sxk31s83ivpx', 'getallproducts', 'hg0b22nnbmsclf2rzddx9giorzxtt351', '2020-09-24 02:42:30');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('442', '-fxb3zwgkqacewfnrlu7rq3o3bqzvc8s', 'getallproducts', 'o92cqn5e5sct6dz2jwzkpfhm9o6qpf4k', '2020-09-24 02:42:46');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('443', '8jay-bhftl91d9ikice-2jvqe24tiyrl', 'getfilters', 'btif-xc5zfjsk-pvj21josalmy05v19z', '2020-09-24 02:42:46');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('444', 'wvo2-gkwm2w3kfmmnl0vblgea-hb6owb', 'getallproducts', 'ibw4c3l20zhgxuvwc6wc2stus-1h6qro', '2020-09-24 02:42:46');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('445', 'zdi1s-sjblh7x8eu2-gu19-fncrtlyh9', 'getfilters', 'sz55xjpf8ac0gl5ogixhmpt0voxmykl7', '2020-09-24 02:42:46');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('446', 'ukrp6zpanf5lopuhum9q7ohmo9h88mrt', 'sitesetting', 'toyp85tu6g-7uvnhegnm3g5iwzaoer59', '2020-09-26 02:30:59');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('447', 'mj-wawswyjllimml81d0r8zi5j7tofdn', 'getallpages', 'lpvoionykanvmohh68j2pxbk0sxjzc36', '2020-09-26 02:30:59');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('448', '63wkdc6dl3suczxp1k14kl5i30fi1mvx', 'getbanners', '6lo0vcqg2wo5z8syjv6g5hivfcagfto0', '2020-09-26 02:31:00');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('449', 'eozrjnuuw3z4rl8il3488m38gcpggvrv', 'allcategories', 'z5w3gzs0vy0f5ogd5oqrea2oe63to5xv', '2020-09-26 02:31:00');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('450', '07z8596qldkxywa5uz9hvv2c0jb7oh40', 'getallproducts', '7tmpotk8u8w1l6qfx08nwv4rzal7x5ii', '2020-09-26 02:31:00');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('451', 'fd8akvs7fqyo4ys7pd3-qpixmdui0d07', 'getfilters', 'q6xcckj2amwi-ifdkej25twrgnokytrc', '2020-09-26 02:31:00');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('452', 'mlihj1c4t8le54xckpcagk-3b7kza63r', 'getallproducts', 'ow56ohl4zqv217421bsul20d5q1iqk8z', '2020-09-26 02:31:00');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('453', 'bi3iv-n6b8cgq10aycqjl11xsj4rbun-', 'getfilters', 'e9x9l9r8ol7q493m7t7e9k3il7f0r7j0', '2020-09-26 02:31:00');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('454', 'b81z8qadzqxbnhulds1h9f-8umyz5dmq', 'getallproducts', 'rt423nbvuteaav0denrudt5au33x6cgm', '2020-09-26 02:31:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('455', '7e5zypr9-trc7fe537fbok14j40necs8', 'getfilters', 'ik4mzhi832fqzm37lwc8vqpaqcjpk6rl', '2020-09-26 02:31:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('456', '16z45nkjzv7s364h7rzdkjuflyiqbadb', 'getallproducts', 'an6ygd72zu7jez67txwhqkp6gs6tyn7x', '2020-09-26 02:31:07');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('457', '0kqgxraioimw7s6eoj9vdhkauxauijqi', 'getfilters', '5hs-6u-55-ymzvx9mivg0qfwwf0o8r5y', '2020-09-26 02:31:07');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('458', 'r36a73jbe7w0v125v0dbpltx7j73zatw', 'getfilters', '0iev45d1m5g50x0gsm6ycbosdu0r3z1a', '2020-09-26 02:31:07');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('459', 'r36a73jbe7w0v125v0dbpltx7j73zatw', 'getallproducts', '0iev45d1m5g50x0gsm6ycbosdu0r3z1a', '2020-09-26 02:31:07');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('460', '0c5tzdtf75m1jphzs6dx4gygqsfldn60', 'getallproducts', '5s7q7n032-lagoq45qo1yrhid7tlpfau', '2020-09-26 02:31:08');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('461', 'jeah2fwo7xvnfu-nvakbfzq-18asgnj9', 'getfilters', 'vigawc-u6re8b5evfhybjwbl5uixa6fm', '2020-09-26 02:31:08');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('462', 'qv3luyu5jquw5e01v4u5sbas0wdymmt1', 'getallproducts', 'um-d7217v4x8uvjl0lhqkt517kyq0z1i', '2020-09-26 02:31:10');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('463', '1eq78xzlgwbcn23afqe275huh9hwzwwt', 'getfilters', 'ocd3vuejy7g3i467udww1b3ea8p0fi3-', '2020-09-26 02:31:10');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('464', 'b2aa6bj0jm3dlutyowz72bd8n8qlelw2', 'getallproducts', 'k2bus82tvumm1rx5sqw93d4xifv1gv99', '2020-09-26 02:31:11');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('465', 'ex5k3gk6l06lknwii9ssr6vg6yuo558h', 'getfilters', 'sd4uu08r172h3sx0il2ytyo-f9unq5lp', '2020-09-26 02:31:11');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('466', 'dykb3qz63lxfu0oinm2h913f2rxbgr7e', 'getallproducts', 'wtt1hiybz9vbhf5yvomnmcf2erxj-2xh', '2020-09-26 02:31:11');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('467', 'jo5y1msyutu7j7rytmeyrvnkqiph7730', 'getfilters', '2-hjtcm90i55lnkhkv5q61n68mtaznod', '2020-09-26 02:31:11');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('468', 'tcfj7bm7zdfkf8l0vnvmdhucycau6par', 'sitesetting', '1mtq2klkhzo544m40y0ca7mgj8clj0cv', '2020-09-26 06:34:00');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('469', '9jp0f3zf7nelz1pw1fpeipuuggbj8wt6', 'getallpages', '7pcqfguo2rkds9goopy-9r9e79tqlh7o', '2020-09-26 06:34:01');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('470', 'xmd1c-nz8r9dxyme9eleyl7zhlo-63f6', 'getbanners', 'fnrx1j7pevk66b2doown6e4sfx3jkkrl', '2020-09-26 06:34:02');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('471', '6vb3cndnd6mha1g3e9a9gb0ed7nd0bd5', 'allcategories', 'oiyabfd2s4tvqc3ytqufbb407dbybykk', '2020-09-26 06:34:02');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('472', 't7m2aana7yj07ow4023ljsgmruo9yq-g', 'getfilters', '3e36ywuq9-t919ygn34keyw5szn5qo6j', '2020-09-26 06:34:03');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('473', '9dap7ia1fpwph999x65gyulm54laxowk', 'getallproducts', '6qs78f92yojq-lqwby74uogh2cj92u6e', '2020-09-26 06:34:03');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('474', 'exeub600cdbg8uo2fax818jlx1a6jfw3', 'getallproducts', '40a0hve8qeg7d6wtrpj21raocfacu2vm', '2020-09-26 06:34:03');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('475', '1bmd66ud0klckgik9u5dfy8l-oyem1m2', 'getfilters', 'h6pib2iaq6q7t8m70ew93j1k2wp7h43d', '2020-09-26 06:34:03');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('476', 'xcf7swo02ql6kpnm3yu7y-v2b6qs63jv', 'getallproducts', 'z4xjcyl7ylzd8f-5wjep1ca6kt89s-kn', '2020-09-26 06:34:36');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('477', 'p5jgp8togvxk3thxdj09tfx5h5jzn6l2', 'getfilters', '6rguy-9iczo6qv0jrrjkwz0zh9rt4vo9', '2020-09-26 06:34:36');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('478', '89f3-h7yhdz36t68saequzrz7n81osxc', 'getallproducts', '-ftjyq6w5grx2l3vzdqkmzxln8caa9x0', '2020-09-26 06:34:36');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('479', 'eepog1exxzti09h8ioiguv2zoelzhkdz', 'getfilters', '754wgbiq2-pq3ej-t0cv4ys4n4qkkma8', '2020-09-26 06:34:36');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('480', 'z73hncxx090rga9w8cl3-993lhjn54x1', 'getallproducts', '2pzfkrkfcn7aw8l62gcbt02ulbsnnxg3', '2020-09-26 06:34:40');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('481', 'zr1zs92olglsm7xd8j744ldkms5lk3-s', 'getfilters', 'is3dgjglh4mouyrzxhlrrua1xkm93lsp', '2020-09-26 06:34:40');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('482', 'kgfykj-phxq2mdt6jflqeo0avxpxgy-j', 'sitesetting', 'lc77g4jn3sx461toyhh88-gy42udtin7', '2020-09-27 10:25:31');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('483', '3qg0vii7y4vt020qx0cppu1i9751pgwo', 'getallpages', 'ci5u9wrxppkl4puhs5t-embulgx8al06', '2020-09-27 10:25:31');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('484', 'xp0ks06oqu200ziraf882bxxi1vd3kw8', 'registerdevices', 'gywnj7apuf6duh60ly8ej1-h8pjus7zu', '2020-09-27 10:25:38');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('485', 'xiryqt2j-9frqqq1iebiirf-ziwg3o17', 'getbanners', 'txpw0103smz-qj1h61zvjtp0p1o9sr78', '2020-09-27 10:25:39');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('486', 'jj4gpbc4u29w9z8-ves1zb6o-1eshgx5', 'allcategories', 'tvxijedzpdmj8nt-ixkf6rg86bl8d6vr', '2020-09-27 10:25:39');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('487', 'fyv4umf1784bcpg1uwhqjsnxr3esoq79', 'getallproducts', 'da3x47l1nfn9bxeoooirj7ea40vtim8l', '2020-09-27 10:25:39');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('488', 'wvncvh5hk3-148j49d2kn2zbysif44nn', 'getfilters', '9zzqy7j1ah16gzgfvi4m86avybp0rya7', '2020-09-27 10:25:39');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('489', 'odxt-eq7t7wtpap-o-xvxraqudqg3yve', 'getallproducts', 'h53kyybqposd2qym3n4tgvm71oxs44q5', '2020-09-27 10:25:39');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('490', 'odxt-eq7t7wtpap-o-xvxraqudqg3yve', 'getfilters', '3kxzz8io9g94lb1ihd71y6n5cwkhljxe', '2020-09-27 10:25:39');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('491', '-rbvx2nw0jhmsv9fkbqvzam5f6amxx50', 'getallproducts', '-5ewpvclh0pq3uzgencruzraxue7w4vf', '2020-09-27 10:25:47');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('492', 'vmdanueoh6gugir4uq5utlehvp4h2piy', 'getfilters', 'kxi40r4sranlvlgk7g4xgpkl4ph--ybx', '2020-09-27 10:25:47');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('493', 'rsuzs0hegu3-er90neig1u8jc2sph0fm', 'getfilters', 'flugiu7v8-a8ge9kc2xq4o8xhw--ch1a', '2020-09-27 10:25:48');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('494', 'rdl5ibg-bq-sx901pmyo3f402-hv1u9c', 'getallproducts', '0rnysz8veg2f5yt1iisguhqd4gfcn1f0', '2020-09-27 10:25:48');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('495', 'v4zm2k59iizaicu9u1p3q88903fqidkl', 'getfilters', 'lsjtggow1t54eaiuvwmrzxd9oz1lr4pe', '2020-09-27 10:25:48');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('496', 'v4zm2k59iizaicu9u1p3q88903fqidkl', 'getallproducts', 'lsjtggow1t54eaiuvwmrzxd9oz1lr4pe', '2020-09-27 10:25:48');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('497', 'r8pq4me5-r2r0s9hyf42uh6n0vlsse4k', 'getreviews', 'yzc0k5bt9nz8yfusrhyqly7vj6xu056w', '2020-09-27 10:26:38');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('498', 'mdv2qx05ns51zwrfp3q6od0k89g5efap', 'getcurrencies', 'jfavx3vzhwetkb77rcabghqjo0ngwk0i', '2020-09-27 10:26:44');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('499', 'ikt5-k9tasoo-ho1suoed6beljh1tzg3', 'sitesetting', 'pyeeq6uk4jv-d0pso-937t8b3hs2judb', '2020-09-27 10:26:48');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('500', 'bn4z7-qnciggh5xl5fewjc23z421ek-b', 'getallpages', 'r8jbn0ldawok-m14h8w9zukm7zpsk7cg', '2020-09-27 10:26:48');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('501', 'oa-wocfn8kvoskvr15yvuebghtaazhul', 'getbanners', 'd1v9-bups75i1vexa1vrlm4do-luv6h2', '2020-09-27 10:26:49');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('502', '2qbliwsqpzmw6dpidcju-in8l9-okyvq', 'allcategories', 'gp9llj6qzaqlc6-8mp7pd8ilzlqjy0hi', '2020-09-27 10:26:49');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('503', 'xmuw2ooqwlj-q3yz8tzlbwnpyxdnnkds', 'getallproducts', 'tkh632r29a0rd2evtlekjrnx19-0chk9', '2020-09-27 10:26:50');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('504', 'z06iwd0moripu9khk4fn7ewm0-jnf8b-', 'getfilters', '6yp0kgwldfwfv-3rq0md8axioa-zgyj6', '2020-09-27 10:26:50');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('505', 'spwys81nldxmz6jltmac7drlkyz0w5zl', 'getallproducts', 'llta3md2z0vor4eywdxexg1fnloaj4lc', '2020-09-27 10:26:50');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('506', 'spwys81nldxmz6jltmac7drlkyz0w5zl', 'getfilters', 'llta3md2z0vor4eywdxexg1fnloaj4lc', '2020-09-27 10:26:50');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('507', '9086h1412p4xj1c5srxd3ffwoscxtlis', 'getallproducts', 'm4oqo65iusxh6i5izdhh4tof-8t43e98', '2020-09-27 10:26:57');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('508', 'ygftxtnp13vikppnm7z2yro9m3tiqb8o', 'getfilters', '5t0rcyiuvkhvjqymi3ebetlels8jfw13', '2020-09-27 10:27:03');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('509', '2b21wcrifoks4w4gwthy464ffu5ck3bf', 'getfilters', 'v0sr2fdwvdj-0fnwa47moruhq88hf2xp', '2020-09-27 10:27:03');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('510', '7f-xtmk2x8fvyftbf-of6zzetgojl53w', 'getallproducts', '-xmeeidl38dkvpz7hdj6rclfzku3yzfg', '2020-09-27 10:27:03');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('511', '4c66ylo6qoj1snleo46chx2wvltinmu5', 'getallproducts', 'qcppjd8-k8xzrir7c4kgfnnz6s9fyynx', '2020-09-27 10:27:03');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('512', '6o2lzouwgznulgmg5suweg5hp1pjxx6m', 'sitesetting', 'nj96q07j1vw0ie6jjvf0-loqp56bm2vh', '2020-09-27 08:44:46');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('513', 'h-d8ye2dyal-1dd7-oa1kkvm4ko1xg37', 'getallpages', 'g8ljc293659z9doen5749fwlzisx7109', '2020-09-27 08:44:46');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('514', 'bdr62kopj767bc6qjp166eyofd3o3675', 'registerdevices', '6pgq7x8lq6trohdsyhn2cso1ya9e9aws', '2020-09-27 08:44:52');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('515', 'llgnotaf2ce33w-4e2vdrxfz9clgjw3k', 'getbanners', 'dqbqawdx-g2skuy7tziby43oio4fovu4', '2020-09-27 08:44:52');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('516', '0hselod56e-lo4c2mpddbxvz2clqenx3', 'allcategories', 'f1kubzlv8sxwi0dqv1-2b-esxhzqna5s', '2020-09-27 08:44:52');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('517', 'hud9eihbx9-l072m4i9vqtcniqwpweb4', 'getallproducts', 'rnni7f1g1uweqjsz6-p0oawpw3q0ca6b', '2020-09-27 08:44:52');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('518', 'ch0l8tufvyikrdywz9hi39sqhh3cbwuo', 'getallproducts', 'jg1767lreiloxq52u6rqgb8a0q8fahju', '2020-09-27 08:44:52');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('519', '97jqel0n0ie7h0hu7c0j-9igbe1gyk81', 'getallproducts', '89s2omlcmpi92-qe207uv565o0jxnahi', '2020-09-27 08:44:52');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('520', 'c5bz5gy0agnuq3-y8jpwa2giu2ujqug7', 'getallproducts', 'xe0ys15thswaoslud20t-90snswyyi4b', '2020-09-27 08:44:52');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('521', 'f0x2gd9fvgnwpzpcjrc1hhkovgvgj9j4', 'getfilters', '7flzwrhd07s8ek4f8op0waug6ew5niv2', '2020-09-27 08:44:52');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('522', 'mh1z312ta9etnj-r4yb11ac2olyoeeln', 'getallproducts', 'haabbvizemumygyldh-gf0zslzu89m2t', '2020-09-27 08:45:12');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('523', '977cg7rt5dnply6yz1-04b252cbqfkhc', 'getcurrencies', '612pxbbnr42adrrz4hrxaq8ibi3jzq6g', '2020-09-27 08:45:29');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('524', 'gpp63tqm87y9d3si631mm5mm0qnabj0d', 'sitesetting', 'g3knsbrm6wtj9uh72uqe1rmutr-3ybye', '2020-09-27 08:45:32');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('525', 'n30tfgyxnsxpc-2d23fllev4lzi6ijla', 'getallpages', '517sodfnetnxfjxyowkwoabtxztx3q66', '2020-09-27 08:45:32');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('526', 'mafjr3m7lmzrptc1w3yuhjgc1y8cxrlf', 'getbanners', 'hio03lxo342x2j6x6kgt4b-nzv76zks6', '2020-09-27 08:45:33');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('527', '06uwahjxwpyp-x-slklq6cegqg-lq9tu', 'allcategories', 'm64-d-ww2wp0-o5yr0o-4ypegnc208jb', '2020-09-27 08:45:33');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('528', 'jc6939yp9cfqzhxvuo5kb02lasdtwhvb', 'getallproducts', 'pq3jt9liiwjd3rn9my6uxzpx8uesmmn5', '2020-09-27 08:45:33');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('529', 'm4y987kou8tm9z79b05iuiz0fbppfmvr', 'getallproducts', 'etilrug6b7ftz--1dr661c4xctl5j0w4', '2020-09-27 08:45:33');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('530', 'itlu29xzc8vbhqde02yyrs0lzbqcvwah', 'getallproducts', 'b-9wb1e51xnao2s0fpz8m7hjl3yg-hb6', '2020-09-27 08:45:33');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('531', '2rav8exetak10r-swskoa9jixre3r3-v', 'getallproducts', '42pxblsakwlfjvx39a82yd9eqhjvbz1n', '2020-09-27 08:45:33');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('532', 'y5xzc0h3b9b7tuvbp5taiaihcgwlke-n', 'getfilters', '-becmu2xtizgxo24rcpo73q7spii3jo4', '2020-09-27 08:45:33');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('533', '8qe2eotrr5izhsaqtx4sunpadcvr3obu', 'getallproducts', '0ei3bepblxv1d1f19wtmezzr3fokyni-', '2020-09-27 08:45:46');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('534', 'ond2a01-xtqxemo6sq5a5v8tmjqn8c33', 'sitesetting', 'tc0leek6koxhp8pguoke8m1ydkr7e03w', '2020-09-27 08:46:18');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('535', '9h-lv1eqewdgl30as7jq4349jyto2snr', 'getallpages', 'qo04giihfphq--3-geo-gjrvmwojdkkb', '2020-09-27 08:46:18');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('536', 'phrl98e5s2hrytbyseb83k7b0dfng8cx', 'getbanners', 'lgi86xpn3otnbunab3xo6ikh61k-xwuf', '2020-09-27 08:46:18');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('537', 'ekoqy6c6pye7uefcp706b1wqp5636j60', 'allcategories', '3wrnhdlax7cq0te0o9ffz3i551qay6mj', '2020-09-27 08:46:18');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('538', 'ivr4xohm5eshby45u-0ge5f8pdfvx38n', 'getallproducts', 'ui2boiefjmtfq5wms6enjt2na25-hsnl', '2020-09-27 08:46:18');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('539', 'jx6vu7k1uesi3nzqm7vk2o6imzdbr4o5', 'getallproducts', 'j7kemw1u343562wljff9q4egpfhfgtsa', '2020-09-27 08:46:19');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('540', 'am-l-dxbch3pvs871nangvuvxwuc-hle', 'getallproducts', 'an1nq7gdae5f5p9v9qa6zlq7p6no3z07', '2020-09-27 08:46:19');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('541', '2dd5ni9ypqm2mxlfnpe6g7bom08pvk3f', 'getfilters', 'uj60lwnf4o4b2gcuhm33k0gedb3aglmc', '2020-09-27 08:46:19');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('542', 'tkbpy6vn9-85ybp8fcrw3w6r1e8xh-kr', 'getallproducts', 'jz1z01z-lp6bo72uagv7rh2l-fc0rb7b', '2020-09-27 08:46:19');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('543', 'ipa3evqj3moq98e6v9h3plvca7pr19z7', 'sitesetting', 'lbmuk1bgc0fybgb4frgx959l06454sys', '2020-09-27 08:46:19');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('544', 'tnuetyv19grckj-qaycqvd168ppwo8h8', 'getallpages', 'dgbrn2iu7tmye7ugiwvq7g8hzio2jfcf', '2020-09-27 08:46:19');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('545', 'pm5p3x88dbls1x6j3lfg3zyxrt7bb94f', 'sitesetting', 'jyirvatkfear775dgzocozveizkqtmmd', '2020-09-27 08:48:05');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('546', '06xs-hx3vb644t51wwpn3vho8txis3w0', 'getallpages', 'q24pg0vmp50c38-7g9391kj-k226260v', '2020-09-27 08:48:05');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('547', 'xmrb1b0whtduu5siapxnd812v71lzjmv', 'getbanners', 'ru-m705x6ke7cywgmuifl5l9eq3l8wh9', '2020-09-27 08:48:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('548', 'wzpi3ms1p2oaetwp0mh2fgrniu9139kt', 'allcategories', 'nlmp-0x05jy4f471suhi--qjevttj4ec', '2020-09-27 08:48:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('549', '8p98xn1ud52l8pzve5k3mzh2hmirkn6i', 'getallproducts', 'xmenbxxvlb8ex52ts7k441m-qjui33xe', '2020-09-27 08:48:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('550', 'f8cfajrxj19l46yo2-brpoac7h0d2rg6', 'getallproducts', 'bpb9mn4pu9hp4alxf23p0stbw1nd0x1t', '2020-09-27 08:48:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('551', 'fwq8d0k3uqyz5jnn0bdsgdv6wp3uc75x', 'getallproducts', 'ezkhvmq8cbe5al77pn60wpekwhueds5i', '2020-09-27 08:48:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('552', 'ouvbsu63cxbqqcda53exfv8at66mvaql', 'getallproducts', 'b17x6f2-s5xizxoan0v9c6f2x1b-meki', '2020-09-27 08:48:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('553', 'kkxra0akq45jm2yc4kcmhoreo2hbjsvq', 'sitesetting', 'mkg0dr0wr4a3473n2wlfj2ta8dn7l6en', '2020-09-27 08:48:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('554', 'st4ogr939aaof1txf51i8vzn4xy26smn', 'getfilters', 'ivpt8jhalvhzfokxsgzp06amsj8dx9i1', '2020-09-27 08:48:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('555', '17580g4pua--8epnp59zi-8zhg810u68', 'getallpages', 'qunjf2inr88uv4jf75nfqg--eyfmjmkr', '2020-09-27 08:48:06');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('556', 'vih09hgw2e-gceju1e6x-mwyp07yq9ql', 'getallproducts', 'r52i-k3q215ghu3fcktxs6y7e7vzvs2z', '2020-09-27 08:48:08');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('557', 'gkjp2pkmobcrav6mns8s-t4bgka43nnx', 'getfilters', 'xqst9z012joizn705qimvpylmqsjsiam', '2020-09-27 08:48:08');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('558', '9jzyk-e5mpo3chwhnw7zx-f96snjpyu6', 'getfilters', '40iyg3hzb9tcqh0646wlt6xkmm0spbq9', '2020-09-27 08:48:08');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('559', 'p1w98af6euyfz4kgmdpmc4rzfkhpyt52', 'getallproducts', 'o66pmv5ubagtzhpa8vvb2-k182q3u1dc', '2020-09-27 08:48:08');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('560', '-lcxtkohn8zxm0haenialycxe4bkl324', 'getallproducts', '5s1f9lub9y82j4hsevhj4in1rwfon9cb', '2020-09-27 08:48:08');


INSERT INTO api_calls_list (`id`, `nonce`, `url`, `device_id`, `created_at`); VALUES ('561', 's11catntjqa0ah5hd9z48y-2epdx1g96', 'getfilters', '23b-l-ptrku9cj8r73f-rsnfgbhygytt', '2020-09-27 08:48:09');


TRUNCATE bank_detail; TRUNCATE banners; INSERT INTO banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `banners_group`, `banners_html_text`, `expires_impressions`, `expires_date`, `date_scheduled`, `date_added`, `date_status_change`, `status`, `type`, `banners_slug`, `created_at`, `updated_at`, `languages_id`); VALUES ('2', 'Selamat Datang Di Rumah Sayur KIta', '1', '338', '', '', '0', '2021-03-05 00:00:00', '', '0000-00-00 00:00:00', '', '1', 'category', '', '2020-09-27 20:47:54', '', '1');


TRUNCATE banners_history; TRUNCATE block_ips; TRUNCATE categories; INSERT INTO categories (`categories_id`, `categories_image`, `categories_icon`, `parent_id`, `sort_order`, `date_added`, `last_modified`, `categories_slug`, `categories_status`, `created_at`, `updated_at`); VALUES ('-1', '120', '120', '0', '', '', '', 'uncategorized', '0', '', '2020-08-26 01:53:17');


INSERT INTO categories (`categories_id`, `categories_image`, `categories_icon`, `parent_id`, `sort_order`, `date_added`, `last_modified`, `categories_slug`, `categories_status`, `created_at`, `updated_at`); VALUES ('1', '132', '132', '0', '', '', '', 'sayuran', '1', '2020-07-20 05:04:10', '');


INSERT INTO categories (`categories_id`, `categories_image`, `categories_icon`, `parent_id`, `sort_order`, `date_added`, `last_modified`, `categories_slug`, `categories_status`, `created_at`, `updated_at`); VALUES ('2', '125', '125', '0', '', '', '', 'daging-ayam-segar', '1', '2020-07-20 05:04:23', '');


INSERT INTO categories (`categories_id`, `categories_image`, `categories_icon`, `parent_id`, `sort_order`, `date_added`, `last_modified`, `categories_slug`, `categories_status`, `created_at`, `updated_at`); VALUES ('3', '124', '124', '0', '', '', '', 'buah', '1', '2020-07-20 05:04:35', '');


INSERT INTO categories (`categories_id`, `categories_image`, `categories_icon`, `parent_id`, `sort_order`, `date_added`, `last_modified`, `categories_slug`, `categories_status`, `created_at`, `updated_at`); VALUES ('4', '128', '128', '0', '', '', '', 'ikan-segar', '1', '2020-07-20 05:04:47', '');


INSERT INTO categories (`categories_id`, `categories_image`, `categories_icon`, `parent_id`, `sort_order`, `date_added`, `last_modified`, `categories_slug`, `categories_status`, `created_at`, `updated_at`); VALUES ('5', '126', '126', '0', '', '', '', 'bumbu-dapur', '1', '2020-07-20 05:05:03', '');


INSERT INTO categories (`categories_id`, `categories_image`, `categories_icon`, `parent_id`, `sort_order`, `date_added`, `last_modified`, `categories_slug`, `categories_status`, `created_at`, `updated_at`); VALUES ('6', '127', '127', '0', '', '', '', 'frozen-food', '1', '2020-07-20 05:05:13', '');


INSERT INTO categories (`categories_id`, `categories_image`, `categories_icon`, `parent_id`, `sort_order`, `date_added`, `last_modified`, `categories_slug`, `categories_status`, `created_at`, `updated_at`); VALUES ('7', '129', '129', '0', '', '', '', 'ikan-kering-asin', '1', '2020-07-20 05:05:38', '');


INSERT INTO categories (`categories_id`, `categories_image`, `categories_icon`, `parent_id`, `sort_order`, `date_added`, `last_modified`, `categories_slug`, `categories_status`, `created_at`, `updated_at`); VALUES ('8', '133', '133', '0', '', '', '', 'sembako', '1', '2020-07-20 05:06:03', '');


INSERT INTO categories (`categories_id`, `categories_image`, `categories_icon`, `parent_id`, `sort_order`, `date_added`, `last_modified`, `categories_slug`, `categories_status`, `created_at`, `updated_at`); VALUES ('9', '130', '130', '0', '', '', '', 'keperluan-rumah-tangga', '1', '2020-07-20 05:06:16', '');


TRUNCATE categories_description; INSERT INTO categories_description (`categories_description_id`, `categories_id`, `language_id`, `categories_name`, `categories_description`); VALUES ('1', '1', '1', 'SAYURAN', '');


INSERT INTO categories_description (`categories_description_id`, `categories_id`, `language_id`, `categories_name`, `categories_description`); VALUES ('2', '2', '1', 'DAGING & AYAM SEGAR', '');


INSERT INTO categories_description (`categories_description_id`, `categories_id`, `language_id`, `categories_name`, `categories_description`); VALUES ('3', '3', '1', 'BUAH', '');


INSERT INTO categories_description (`categories_description_id`, `categories_id`, `language_id`, `categories_name`, `categories_description`); VALUES ('4', '4', '1', 'IKAN SEGAR', '');


INSERT INTO categories_description (`categories_description_id`, `categories_id`, `language_id`, `categories_name`, `categories_description`); VALUES ('5', '5', '1', 'BUMBU DAPUR', '');


INSERT INTO categories_description (`categories_description_id`, `categories_id`, `language_id`, `categories_name`, `categories_description`); VALUES ('6', '6', '1', 'FROZEN FOOD', '');


INSERT INTO categories_description (`categories_description_id`, `categories_id`, `language_id`, `categories_name`, `categories_description`); VALUES ('7', '7', '1', 'IKAN KERING & ASIN', '');


INSERT INTO categories_description (`categories_description_id`, `categories_id`, `language_id`, `categories_name`, `categories_description`); VALUES ('8', '8', '1', 'SEMBAKO', '');


INSERT INTO categories_description (`categories_description_id`, `categories_id`, `language_id`, `categories_name`, `categories_description`); VALUES ('9', '9', '1', 'KEPERLUAN RUMAH TANGGA', '');


INSERT INTO categories_description (`categories_description_id`, `categories_id`, `language_id`, `categories_name`, `categories_description`); VALUES ('10', '-1', '1', 'uncategorized', 'uncategorized');


INSERT INTO categories_description (`categories_description_id`, `categories_id`, `language_id`, `categories_name`, `categories_description`); VALUES ('11', '-1', '2', 'uncategorized', 'uncategorized');


TRUNCATE categories_role; TRUNCATE compare; TRUNCATE constant_banners; INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('1', 'style0', '', '114', '2019-09-08 18:43:14', '1', '1', '1');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('2', 'style0', '', '114', '2019-09-08 18:43:25', '1', '1', '2');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('3', 'banner1', '', '83', '2019-09-08 18:43:34', '1', '1', '3');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('4', 'banner1', '', '83', '2019-09-08 18:43:42', '1', '1', '4');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('5', 'banner1', '', '83', '2019-09-08 18:44:15', '1', '1', '5');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('6', 'banner2_3_4', '', '84', '2019-09-10 08:50:55', '1', '1', '6');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('7', 'banner2_3_4', '', '85', '2019-09-10 08:54:18', '1', '1', '7');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('8', 'banner2_3_4', '', '86', '2019-09-10 08:54:28', '1', '1', '8');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('9', 'banner2_3_4', '', '86', '2019-09-10 08:54:38', '1', '1', '9');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('10', 'banner5_6', '', '92', '2019-09-10 09:31:13', '1', '1', '10');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('11', 'banner5_6', '', '92', '2019-09-10 09:31:24', '1', '1', '11');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('12', 'banner5_6', '', '92', '2019-09-10 09:31:35', '1', '1', '12');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('13', 'banner5_6', '', '92', '2019-09-10 09:32:18', '1', '1', '13');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('14', 'banner5_6', '', '91', '2019-09-10 09:32:28', '1', '1', '14');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('15', 'banner7_8', '', '95', '2019-09-10 09:52:02', '1', '1', '15');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('16', 'banner7_8', '', '96', '2019-09-10 09:52:29', '1', '1', '16');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('17', 'banner7_8', '', '96', '2019-09-10 09:47:56', '1', '1', '17');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('18', 'banner7_8', '', '94', '2019-09-10 09:48:05', '1', '1', '18');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('19', 'banner9', '', '97', '2019-09-10 10:19:03', '1', '1', '19');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('20', 'banner9', '', '97', '2019-09-10 10:19:13', '1', '1', '20');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('21', 'banner10_11_12', '', '98', '2019-09-10 10:26:12', '1', '1', '21');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('22', 'banner10_11_12', '', '96', '2019-09-10 10:26:30', '1', '1', '22');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('23', 'banner10_11_12', '', '96', '2019-09-10 10:26:41', '1', '1', '23');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('24', 'banner10_11_12', '', '99', '2019-09-10 10:26:54', '1', '1', '24');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('25', '25', 'http://rumahsayurkita.com/shop?category=daging-ayam-segar', '283', '2020-07-22 17:46:39', '1', '1', '25');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('26', '26', 'http://download.rumahsayurkita.com/', '341', '2020-09-14 09:12:52', '1', '1', '26');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('27', '27', 'http://rumahsayurkita.com/shop?category=sayuran', '338', '2020-09-14 07:32:07', '1', '1', '27');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('28', '28', 'http://rumahsayurkita.com/shop?category=buah', '339', '2020-09-14 07:33:00', '1', '1', '28');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('29', '29', 'http://rumahsayurkita.com/shop?category=daging-ayam-segar', '340', '2020-09-14 07:33:24', '1', '1', '29');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('30', 'banner16_17', '', '104', '2019-09-10 11:19:45', '1', '1', '30');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('31', 'banner16_17', '', '104', '2019-09-10 11:19:58', '1', '1', '31');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('32', 'banner16_17', '', '105', '2019-09-10 11:21:00', '1', '1', '32');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('33', 'banner18_19', '', '116', '2019-09-10 11:30:35', '1', '1', '33');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('34', 'banner18_19', '', '116', '2019-09-10 11:30:49', '1', '1', '34');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('35', 'banner18_19', '', '96', '2019-09-10 11:31:04', '1', '1', '35');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('36', 'banner18_19', '', '96', '2019-09-10 11:31:20', '1', '1', '36');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('37', 'banner18_19', '', '115', '2019-09-10 11:31:54', '1', '1', '37');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('38', 'banner18_19', '', '115', '2019-09-10 11:32:06', '1', '1', '38');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('39', 'ad_banner1', '', '107', '2019-09-11 06:17:45', '1', '1', '39');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('40', 'ad_banner2', '', '106', '2019-09-11 06:17:58', '1', '1', '40');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('81', 'ad_banner3', '', '107', '0000-00-00 00:00:00', '1', '1', '41');


TRUNCATE countries; INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('1', 'Afghanistan', 'AF', 'AFG', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('2', 'Albania', 'AL', 'ALB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('3', 'Algeria', 'DZ', 'DZA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('4', 'American Samoa', 'AS', 'ASM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('5', 'Andorra', 'AD', 'AND', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('6', 'Angola', 'AO', 'AGO', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('7', 'Anguilla', 'AI', 'AIA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('8', 'Antarctica', 'AQ', 'ATA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('9', 'Antigua and Barbuda', 'AG', 'ATG', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('10', 'Argentina', 'AR', 'ARG', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('11', 'Armenia', 'AM', 'ARM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('12', 'Aruba', 'AW', 'ABW', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('13', 'Australia', 'AU', 'AUS', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('14', 'Austria', 'AT', 'AUT', '5', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('15', 'Azerbaijan', 'AZ', 'AZE', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('16', 'Bahamas', 'BS', 'BHS', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('17', 'Bahrain', 'BH', 'BHR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('18', 'Bangladesh', 'BD', 'BGD', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('19', 'Barbados', 'BB', 'BRB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('20', 'Belarus', 'BY', 'BLR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('21', 'Belgium', 'BE', 'BEL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('22', 'Belize', 'BZ', 'BLZ', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('23', 'Benin', 'BJ', 'BEN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('24', 'Bermuda', 'BM', 'BMU', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('25', 'Bhutan', 'BT', 'BTN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('26', 'Bolivia', 'BO', 'BOL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('27', 'Bosnia and Herzegowina', 'BA', 'BIH', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('28', 'Botswana', 'BW', 'BWA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('29', 'Bouvet Island', 'BV', 'BVT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('30', 'Brazil', 'BR', 'BRA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('31', 'British Indian Ocean Territory', 'IO', 'IOT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('32', 'Brunei Darussalam', 'BN', 'BRN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('33', 'Bulgaria', 'BG', 'BGR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('34', 'Burkina Faso', 'BF', 'BFA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('35', 'Burundi', 'BI', 'BDI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('36', 'Cambodia', 'KH', 'KHM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('37', 'Cameroon', 'CM', 'CMR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('38', 'Canada', 'CA', 'CAN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('39', 'Cape Verde', 'CV', 'CPV', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('40', 'Cayman Islands', 'KY', 'CYM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('41', 'Central African Republic', 'CF', 'CAF', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('42', 'Chad', 'TD', 'TCD', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('43', 'Chile', 'CL', 'CHL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('44', 'China', 'CN', 'CHN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('45', 'Christmas Island', 'CX', 'CXR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('46', 'Cocos (Keeling) Islands', 'CC', 'CCK', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('47', 'Colombia', 'CO', 'COL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('48', 'Comoros', 'KM', 'COM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('49', 'Congo', 'CG', 'COG', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('50', 'Cook Islands', 'CK', 'COK', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('51', 'Costa Rica', 'CR', 'CRI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('52', 'Cote D\'Ivoire', 'CI', 'CIV', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('53', 'Croatia', 'HR', 'HRV', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('54', 'Cuba', 'CU', 'CUB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('55', 'Cyprus', 'CY', 'CYP', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('56', 'Czech Republic', 'CZ', 'CZE', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('57', 'Denmark', 'DK', 'DNK', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('58', 'Djibouti', 'DJ', 'DJI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('59', 'Dominica', 'DM', 'DMA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('60', 'Dominican Republic', 'DO', 'DOM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('61', 'East Timor', 'TP', 'TMP', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('62', 'Ecuador', 'EC', 'ECU', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('63', 'Egypt', 'EG', 'EGY', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('64', 'El Salvador', 'SV', 'SLV', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('65', 'Equatorial Guinea', 'GQ', 'GNQ', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('66', 'Eritrea', 'ER', 'ERI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('67', 'Estonia', 'EE', 'EST', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('68', 'Ethiopia', 'ET', 'ETH', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('69', 'Falkland Islands (Malvinas)', 'FK', 'FLK', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('70', 'Faroe Islands', 'FO', 'FRO', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('71', 'Fiji', 'FJ', 'FJI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('72', 'Finland', 'FI', 'FIN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('73', 'France', 'FR', 'FRA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('74', 'France, Metropolitan', 'FX', 'FXX', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('75', 'French Guiana', 'GF', 'GUF', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('76', 'French Polynesia', 'PF', 'PYF', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('77', 'French Southern Territories', 'TF', 'ATF', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('78', 'Gabon', 'GA', 'GAB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('79', 'Gambia', 'GM', 'GMB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('80', 'Georgia', 'GE', 'GEO', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('81', 'Germany', 'DE', 'DEU', '5', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('82', 'Ghana', 'GH', 'GHA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('83', 'Gibraltar', 'GI', 'GIB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('84', 'Greece', 'GR', 'GRC', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('85', 'Greenland', 'GL', 'GRL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('86', 'Grenada', 'GD', 'GRD', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('87', 'Guadeloupe', 'GP', 'GLP', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('88', 'Guam', 'GU', 'GUM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('89', 'Guatemala', 'GT', 'GTM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('90', 'Guinea', 'GN', 'GIN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('91', 'Guinea-bissau', 'GW', 'GNB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('92', 'Guyana', 'GY', 'GUY', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('93', 'Haiti', 'HT', 'HTI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('94', 'Heard and Mc Donald Islands', 'HM', 'HMD', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('95', 'Honduras', 'HN', 'HND', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('96', 'Hong Kong', 'HK', 'HKG', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('97', 'Hungary', 'HU', 'HUN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('98', 'Iceland', 'IS', 'ISL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('99', 'India', 'IN', 'IND', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('100', 'Indonesia', 'ID', 'IDN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('101', 'Iran (Islamic Republic of)', 'IR', 'IRN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('102', 'Iraq', 'IQ', 'IRQ', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('103', 'Ireland', 'IE', 'IRL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('104', 'Israel', 'IL', 'ISR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('105', 'Italy', 'IT', 'ITA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('106', 'Jamaica', 'JM', 'JAM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('107', 'Japan', 'JP', 'JPN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('108', 'Jordan', 'JO', 'JOR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('109', 'Kazakhstan', 'KZ', 'KAZ', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('110', 'Kenya', 'KE', 'KEN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('111', 'Kiribati', 'KI', 'KIR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('112', 'Korea, Democratic People\'s Republic of', 'KP', 'PRK', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('113', 'Korea, Republic of', 'KR', 'KOR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('114', 'Kuwait', 'KW', 'KWT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('115', 'Kyrgyzstan', 'KG', 'KGZ', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('116', 'Lao People\'s Democratic Republic', 'LA', 'LAO', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('117', 'Latvia', 'LV', 'LVA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('118', 'Lebanon', 'LB', 'LBN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('119', 'Lesotho', 'LS', 'LSO', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('120', 'Liberia', 'LR', 'LBR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('121', 'Libyan Arab Jamahiriya', 'LY', 'LBY', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('122', 'Liechtenstein', 'LI', 'LIE', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('123', 'Lithuania', 'LT', 'LTU', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('124', 'Luxembourg', 'LU', 'LUX', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('125', 'Macau', 'MO', 'MAC', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('126', 'Macedonia, The Former Yugoslav Republic of', 'MK', 'MKD', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('127', 'Madagascar', 'MG', 'MDG', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('128', 'Malawi', 'MW', 'MWI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('129', 'Malaysia', 'MY', 'MYS', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('130', 'Maldives', 'MV', 'MDV', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('131', 'Mali', 'ML', 'MLI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('132', 'Malta', 'MT', 'MLT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('133', 'Marshall Islands', 'MH', 'MHL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('134', 'Martinique', 'MQ', 'MTQ', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('135', 'Mauritania', 'MR', 'MRT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('136', 'Mauritius', 'MU', 'MUS', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('137', 'Mayotte', 'YT', 'MYT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('138', 'Mexico', 'MX', 'MEX', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('139', 'Micronesia, Federated States of', 'FM', 'FSM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('140', 'Moldova, Republic of', 'MD', 'MDA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('141', 'Monaco', 'MC', 'MCO', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('142', 'Mongolia', 'MN', 'MNG', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('143', 'Montserrat', 'MS', 'MSR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('144', 'Morocco', 'MA', 'MAR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('145', 'Mozambique', 'MZ', 'MOZ', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('146', 'Myanmar', 'MM', 'MMR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('147', 'Namibia', 'NA', 'NAM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('148', 'Nauru', 'NR', 'NRU', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('149', 'Nepal', 'NP', 'NPL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('150', 'Netherlands', 'NL', 'NLD', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('151', 'Netherlands Antilles', 'AN', 'ANT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('152', 'New Caledonia', 'NC', 'NCL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('153', 'New Zealand', 'NZ', 'NZL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('154', 'Nicaragua', 'NI', 'NIC', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('155', 'Niger', 'NE', 'NER', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('156', 'Nigeria', 'NG', 'NGA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('157', 'Niue', 'NU', 'NIU', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('158', 'Norfolk Island', 'NF', 'NFK', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('159', 'Northern Mariana Islands', 'MP', 'MNP', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('160', 'Norway', 'NO', 'NOR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('161', 'Oman', 'OM', 'OMN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('162', 'Pakistan', 'PK', 'PAK', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('163', 'Palau', 'PW', 'PLW', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('164', 'Panama', 'PA', 'PAN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('165', 'Papua New Guinea', 'PG', 'PNG', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('166', 'Paraguay', 'PY', 'PRY', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('167', 'Peru', 'PE', 'PER', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('168', 'Philippines', 'PH', 'PHL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('169', 'Pitcairn', 'PN', 'PCN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('170', 'Poland', 'PL', 'POL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('171', 'Portugal', 'PT', 'PRT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('172', 'Puerto Rico', 'PR', 'PRI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('173', 'Qatar', 'QA', 'QAT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('174', 'Reunion', 'RE', 'REU', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('175', 'Romania', 'RO', 'ROM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('176', 'Russian Federation', 'RU', 'RUS', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('177', 'Rwanda', 'RW', 'RWA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('178', 'Saint Kitts and Nevis', 'KN', 'KNA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('179', 'Saint Lucia', 'LC', 'LCA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('180', 'Saint Vincent and the Grenadines', 'VC', 'VCT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('181', 'Samoa', 'WS', 'WSM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('182', 'San Marino', 'SM', 'SMR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('183', 'Sao Tome and Principe', 'ST', 'STP', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('184', 'Saudi Arabia', 'SA', 'SAU', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('185', 'Senegal', 'SN', 'SEN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('186', 'Seychelles', 'SC', 'SYC', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('187', 'Sierra Leone', 'SL', 'SLE', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('188', 'Singapore', 'SG', 'SGP', '4', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('189', 'Slovakia (Slovak Republic)', 'SK', 'SVK', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('190', 'Slovenia', 'SI', 'SVN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('191', 'Solomon Islands', 'SB', 'SLB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('192', 'Somalia', 'SO', 'SOM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('193', 'South Africa', 'ZA', 'ZAF', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('194', 'South Georgia and the South Sandwich Islands', 'GS', 'SGS', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('195', 'Spain', 'ES', 'ESP', '3', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('196', 'Sri Lanka', 'LK', 'LKA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('197', 'St. Helena', 'SH', 'SHN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('198', 'St. Pierre and Miquelon', 'PM', 'SPM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('199', 'Sudan', 'SD', 'SDN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('200', 'Suriname', 'SR', 'SUR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('201', 'Svalbard and Jan Mayen Islands', 'SJ', 'SJM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('202', 'Swaziland', 'SZ', 'SWZ', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('203', 'Sweden', 'SE', 'SWE', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('204', 'Switzerland', 'CH', 'CHE', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('205', 'Syrian Arab Republic', 'SY', 'SYR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('206', 'Taiwan', 'TW', 'TWN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('207', 'Tajikistan', 'TJ', 'TJK', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('208', 'Tanzania, United Republic of', 'TZ', 'TZA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('209', 'Thailand', 'TH', 'THA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('210', 'Togo', 'TG', 'TGO', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('211', 'Tokelau', 'TK', 'TKL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('212', 'Tonga', 'TO', 'TON', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('213', 'Trinidad and Tobago', 'TT', 'TTO', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('214', 'Tunisia', 'TN', 'TUN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('215', 'Turkey', 'TR', 'TUR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('216', 'Turkmenistan', 'TM', 'TKM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('217', 'Turks and Caicos Islands', 'TC', 'TCA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('218', 'Tuvalu', 'TV', 'TUV', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('219', 'Uganda', 'UG', 'UGA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('220', 'Ukraine', 'UA', 'UKR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('221', 'United Arab Emirates', 'AE', 'ARE', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('222', 'United Kingdom', 'GB', 'GBR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('223', 'United States', 'US', 'USA', '2', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('224', 'United States Minor Outlying Islands', 'UM', 'UMI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('225', 'Uruguay', 'UY', 'URY', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('226', 'Uzbekistan', 'UZ', 'UZB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('227', 'Vanuatu', 'VU', 'VUT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('228', 'Vatican City State (Holy See)', 'VA', 'VAT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('229', 'Venezuela', 'VE', 'VEN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('230', 'Viet Nam', 'VN', 'VNM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('231', 'Virgin Islands (British)', 'VG', 'VGB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('232', 'Virgin Islands (U.S.)', 'VI', 'VIR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('233', 'Wallis and Futuna Islands', 'WF', 'WLF', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('234', 'Western Sahara', 'EH', 'ESH', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('235', 'Yemen', 'YE', 'YEM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('236', 'Yugoslavia', 'YU', 'YUG', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('237', 'Zaire', 'ZR', 'ZAR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('238', 'Zambia', 'ZM', 'ZMB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('239', 'Zimbabwe', 'ZW', 'ZWE', '1', '');


TRUNCATE coupons; TRUNCATE currencies; INSERT INTO currencies (`id`, `title`, `code`, `symbol_left`, `symbol_right`, `decimal_point`, `thousands_point`, `decimal_places`, `created_at`, `updated_at`, `value`, `is_default`, `status`, `is_current`); VALUES ('1', 'U.S. Dollar', 'USD', '$', '', '', '', '2', '2019-09-06 08:33:11', '2019-09-06 08:33:11', '1', '0', '1', '1');


INSERT INTO currencies (`id`, `title`, `code`, `symbol_left`, `symbol_right`, `decimal_point`, `thousands_point`, `decimal_places`, `created_at`, `updated_at`, `value`, `is_default`, `status`, `is_current`); VALUES ('2', 'Indonesia', 'IDR', 'Rp', '', '', '', '0', '2020-07-20 07:55:52', '2020-07-20 07:55:52', '1', '1', '1', '1');


TRUNCATE currency_record; INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('64', 'IDR', 'Indonesian Rupiah');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('151', 'USD', 'United States Dollar');


TRUNCATE current_theme; INSERT INTO current_theme (`id`, `top_offer`, `header`, `carousel`, `banner`, `footer`, `product_section_order`, `cart`, `news`, `detail`, `shop`, `contact`, `login`, `transitions`, `banner_two`, `category`); VALUES ('1', '1', '9', '1', '15', '5', '[{\"id\":1,\"name\":\"Banner Section\",\"order\":1,\"file_name\":\"banner_section\",\"status\":1,\"image\":\"images\\/prototypes\\/banner_section.jpg\",\"alt\":\"Banner Section\"},{\"id\":5,\"name\":\"Categories\",\"order\":2,\"file_name\":\"categories\",\"status\":1,\"image\":\"images\\/prototypes\\/categories.jpg\",\"disabled_image\":\"images\\/prototypes\\/categories-cross.jpg\",\"alt\":\"Categories\"},{\"id\":7,\"name\":\"Info Boxes\",\"order\":3,\"file_name\":\"info_boxes\",\"status\":1,\"image\":\"images\\/prototypes\\/info_boxes.jpg\",\"disabled_image\":\"images\\/prototypes\\/info_boxes-cross.jpg\",\"alt\":\"Info Boxes\"},{\"id\":11,\"name\":\"Tab Products View\",\"order\":4,\"file_name\":\"tab\",\"status\":0,\"image\":\"images\\/prototypes\\/tab.jpg\",\"disabled_image\":\"images\\/prototypes\\/tab-cross.jpg\",\"alt\":\"Tab Products View\"},{\"id\":2,\"name\":\"Flash Sale Section\",\"order\":5,\"file_name\":\"flash_sale_section\",\"status\":1,\"image\":\"images\\/prototypes\\/flash_sale_section.jpg\",\"disabled_image\":\"images\\/prototypes\\/flash_sale_section-cross.jpg\",\"alt\":\"Flash Sale Section\"},{\"id\":10,\"name\":\"Second Ad Section\",\"order\":6,\"file_name\":\"sec_ad_banner\",\"status\":1,\"image\":\"images\\/prototypes\\/sec_ad_section.jpg\",\"disabled_image\":\"images\\/prototypes\\/sec_ad_section-cross.jpg\",\"alt\":\"Second Ad Section\"},{\"id\":9,\"name\":\"Top Selling\",\"order\":7,\"file_name\":\"top\",\"status\":1,\"image\":\"images\\/prototypes\\/top.jpg\",\"disabled_image\":\"images\\/prototypes\\/top-cross.jpg\",\"alt\":\"Top Selling\"},{\"id\":4,\"name\":\"Ad Section\",\"order\":8,\"file_name\":\"ad_banner_section\",\"status\":1,\"image\":\"images\\/prototypes\\/ad_banner_section.jpg\",\"disabled_image\":\"images\\/prototypes\\/ad_banner_section-cross.jpg\",\"alt\":\"Ad Section\"},{\"id\":8,\"name\":\"Newest Product Section\",\"order\":9,\"file_name\":\"newest_product\",\"status\":1,\"image\":\"images\\/prototypes\\/newest_product.jpg\",\"disabled_image\":\"images\\/prototypes\\/newest_product-cross.jpg\",\"alt\":\"Newest Product Section\"},{\"id\":3,\"name\":\"Special Products Section\",\"order\":10,\"file_name\":\"special\",\"status\":1,\"image\":\"images\\/prototypes\\/special_product.jpg\",\"disabled_image\":\"images\\/prototypes\\/special_product-cross.jpg\",\"alt\":\"Special Products Section\"},{\"id\":12,\"name\":\"Banner 2 Section\",\"order\":11,\"file_name\":\"banner_two_section\",\"status\":1,\"image\":\"images\\/prototypes\\/sec_ad_section.jpg\",\"disabled_image\":\"images\\/prototypes\\/sec_ad_section-cross.jpg\",\"alt\":\"Banner 2 Section\"},{\"id\":13,\"name\":\"Category\",\"order\":12,\"file_name\":\"Category_section\",\"status\":1,\"image\":\"images\\/prototypes\\/category_section.jpg\",\"disabled_image\":\"images\\/prototypes\\/category_section-cross.jpg\",\"alt\":\"Category 2 Section\"},{\"id\":6,\"name\":\"Blog Section\",\"order\":13,\"file_name\":\"blog_section\",\"status\":1,\"image\":\"images\\/prototypes\\/blog_section.jpg\",\"disabled_image\":\"images\\/prototypes\\/blog_section-cross.jpg\",\"alt\":\"Blog Section\"}]', '1', '1', '1', '1', '1', '1', '3', '1', '1');


TRUNCATE customers; TRUNCATE customers_basket; INSERT INTO customers_basket (`customers_basket_id`, `customers_id`, `products_id`, `customers_basket_quantity`, `final_price`, `customers_basket_date_added`, `is_order`, `session_id`); VALUES ('1', '4', '1', '1', '8750.00', '2020-08-31', '1', 'iKyDSOhRKyYSNH5dgYRF0Vl0WIFIrMFVe1i7U8xP');


INSERT INTO customers_basket (`customers_basket_id`, `customers_id`, `products_id`, `customers_basket_quantity`, `final_price`, `customers_basket_date_added`, `is_order`, `session_id`); VALUES ('2', '5', '96', '1', '41000.00', '2020-09-26', '0', 'v15GlNYNhMdzIC7Pu73Xan1baZ7fYOA74mFu9yx1');


INSERT INTO customers_basket (`customers_basket_id`, `customers_id`, `products_id`, `customers_basket_quantity`, `final_price`, `customers_basket_date_added`, `is_order`, `session_id`); VALUES ('3', '5', '95', '1', '17500.00', '2020-09-26', '0', 'v15GlNYNhMdzIC7Pu73Xan1baZ7fYOA74mFu9yx1');


TRUNCATE customers_basket_attributes; TRUNCATE customers_info; INSERT INTO customers_info (`customers_info_id`, `customers_info_date_of_last_logon`, `customers_info_number_of_logons`, `customers_info_date_account_created`, `customers_info_date_account_last_modified`, `global_product_notifications`); VALUES ('4', '2020-09-15 05:50:16', '1', '2020-09-15 05:50:16', '', '1');


TRUNCATE delievery_time_slot_with_zone; TRUNCATE delievery_time_slots; TRUNCATE deliveryboy_info; TRUNCATE devices; TRUNCATE flash_sale; TRUNCATE flate_rate; INSERT INTO flate_rate (`id`, `flate_rate`, `currency`); VALUES ('1', '11', 'USD');


TRUNCATE floating_cash; TRUNCATE front_end_theme_content; INSERT INTO front_end_theme_content (`id`, `top_offers`, `headers`, `carousels`, `banners`, `footers`, `product_section_order`, `cart`, `news`, `detail`, `shop`, `contact`, `login`, `transitions`, `banners_two`, `category`); VALUES ('1', '[{ \"id\": 1, \"name\": \"Top Offer\", \"image\": \"images/prototypes/banner1.jpg\", \"alt\": \"Top Offer\" }]', '[
{
\"id\": 1,
\"name\": \"Header One\",
\"image\": \"images/prototypes/header1.jpg\",
\"alt\" : \"header One\" 
},
{
\"id\": 2,
\"name\": \"Header Two\",
\"image\": \"images/prototypes/header2.jpg\",
\"alt\" : \"header Two\" 
},
{
\"id\": 3,
\"name\": \"Header Three\",
\"image\": \"images/prototypes/header3.jpg\",
\"alt\" : \"header Three\" 
},
{
\"id\": 4,
\"name\": \"Header Four\",
\"image\": \"images/prototypes/header4.jpg\",
\"alt\" : \"header Four\" 
},
{
\"id\": 5,
\"name\": \"Header Five\",
\"image\": \"images/prototypes/header5.jpg\",
\"alt\" : \"header Five\" 
},
{
\"id\": 6,
\"name\": \"Header Six\",
\"image\": \"images/prototypes/header6.jpg\",
\"alt\" : \"header Six\" 
},
{
\"id\": 7,
\"name\": \"Header Seven\",
\"image\": \"images/prototypes/header7.jpg\",
\"alt\" : \"header Seven\" 
},
{
\"id\": 8,
\"name\": \"Header Eight\",
\"image\": \"images/prototypes/header8.jpg\",
\"alt\" : \"header Eight\" 
},
{
\"id\": 9,
\"name\": \"Header Nine\",
\"image\": \"images/prototypes/header9.jpg\",
\"alt\" : \"header Nine\" 
},
{
\"id\": 10,
\"name\": \"Header Ten\",
\"image\": \"images/prototypes/header10.jpg\",
\"alt\" : \"header Ten\" 
}
]', '[
{
\"id\": 1,
\"name\": \"Bootstrap Carousel Content Full Screen\",
\"image\": \"images/prototypes/carousal1.jpg\",
\"alt\": \"Bootstrap Carousel Content Full Screen\"
},
{
\"id\": 2,
\"name\": \"Bootstrap Carousel Content Full Width\",
\"image\": \"images/prototypes/carousal2.jpg\",
\"alt\": \"Bootstrap Carousel Content Full Width\"
},
{
\"id\": 3,
\"name\": \"Bootstrap Carousel Content with Left Banner\",
\"image\": \"images/prototypes/carousal3.jpg\",
\"alt\": \"Bootstrap Carousel Content with Left Banner\"
},
{
\"id\": 4,
\"name\": \"Bootstrap Carousel Content with Navigation\",
\"image\": \"images/prototypes/carousal4.jpg\",
\"alt\": \"Bootstrap Carousel Content with Navigation\"
},
{
\"id\": 5,
\"name\": \"Bootstrap Carousel Content with Right Banner\",
\"image\": \"images/prototypes/carousal5.jpg\",
\"alt\": \"Bootstrap Carousel Content with Right Banner\"
}
]', '[
{
\"id\": 1,
\"name\": \"Banner One\",
\"image\": \"images/prototypes/banner1.jpg\",
\"alt\": \"Banner One\"
},
{
\"id\": 2,
\"name\": \"Banner Two\",
\"image\": \"images/prototypes/banner2.jpg\",
\"alt\": \"Banner Two\"
},
{
\"id\": 3,
\"name\": \"Banner Three\",
\"image\": \"images/prototypes/banner3.jpg\",
\"alt\": \"Banner Three\"
},
{
\"id\": 4,
\"name\": \"Banner Four\",
\"image\": \"images/prototypes/banner4.jpg\",
\"alt\": \"Banner Four\"
},
{
\"id\": 5,
\"name\": \"Banner Five\",
\"image\": \"images/prototypes/banner5.jpg\",
\"alt\": \"Banner Five\"
},
{
\"id\": 6,
\"name\": \"Banner Six\",
\"image\": \"images/prototypes/banner6.jpg\",
\"alt\": \"Banner Six\"
},
{
\"id\": 7,
\"name\": \"Banner Seven\",
\"image\": \"images/prototypes/banner7.jpg\",
\"alt\": \"Banner Seven\"
},
{
\"id\": 8,
\"name\": \"Banner Eight\",
\"image\": \"images/prototypes/banner8.jpg\",
\"alt\": \"Banner Eight\"
},
{
\"id\": 9,
\"name\": \"Banner Nine\",
\"image\": \"images/prototypes/banner9.jpg\",
\"alt\": \"Banner Nine\"
},
{
\"id\": 10,
\"name\": \"Banner Ten\",
\"image\": \"images/prototypes/banner10.jpg\",
\"alt\": \"Banner Ten\"
},
{
\"id\": 11,
\"name\": \"Banner Eleven\",
\"image\": \"images/prototypes/banner11.jpg\",
\"alt\": \"Banner Eleven\"
},
{
\"id\": 12,
\"name\": \"Banner Twelve\",
\"image\": \"images/prototypes/banner12.jpg\",
\"alt\": \"Banner Twelve\"
},
{
\"id\": 13,
\"name\": \"Banner Thirteen\",
\"image\": \"images/prototypes/banner13.jpg\",
\"alt\": \"Banner Thirteen\"
},
{
\"id\": 14,
\"name\": \"Banner Fourteen\",
\"image\": \"images/prototypes/banner14.jpg\",
\"alt\": \"Banner Fourteen\"
},
{
\"id\": 15,
\"name\": \"Banner Fifteen\",
\"image\": \"images/prototypes/banner15.jpg\",
\"alt\": \"Banner Fifteen\"
},
{
\"id\": 16,
\"name\": \"Banner Sixteen\",
\"image\": \"images/prototypes/banner16.jpg\",
\"alt\": \"Banner Sixteen\"
},
{
\"id\": 17,
\"name\": \"Banner Seventeen\",
\"image\": \"images/prototypes/banner17.jpg\",
\"alt\": \"Banner Seventeen\"
},
{
\"id\": 18,
\"name\": \"Banner Eighteen\",
\"image\": \"images/prototypes/banner18.jpg\",
\"alt\": \"Banner Eighteen\"
},
{
\"id\": 19,
\"name\": \"Banner Nineteen\",
\"image\": \"images/prototypes/banner19.jpg\",
\"alt\": \"Banner Nineteen\"
}
]', '[
{
\"id\": 1,
\"name\": \"Footer One\",
\"image\": \"images/prototypes/footer1.png\",
\"alt\" : \"Footer One\"
},
{
\"id\": 2,
\"name\": \"Footer Two\",
\"image\": \"images/prototypes/footer2.png\",
\"alt\" : \"Footer Two\"
},
{
\"id\": 3,
\"name\": \"Footer Three\",
\"image\": \"images/prototypes/footer3.png\",
\"alt\" : \"Footer Three\"
},
{
\"id\": 4,
\"name\": \"Footer Four\",
\"image\": \"images/prototypes/footer4.png\",
\"alt\" : \"Footer Four\"
},
{
\"id\": 5,
\"name\": \"Footer Five\",
\"image\": \"images/prototypes/footer5.png\",
\"alt\" : \"Footer Five\"
},
{
\"id\": 6,
\"name\": \"Footer Six\",
\"image\": \"images/prototypes/footer6.png\",
\"alt\" : \"Footer Six\"
},
{
\"id\": 7,
\"name\": \"Footer Seven\",
\"image\": \"images/prototypes/footer7.png\",
\"alt\" : \"Footer Seven\"
},
{
\"id\": 8,
\"name\": \"Footer Eight\",
\"image\": \"images/prototypes/footer8.png\",
\"alt\" : \"Footer Eight\"
},
{
\"id\": 9,
\"name\": \"Footer Nine\",
\"image\": \"images/prototypes/footer9.png\",
\"alt\" : \"Footer Nine\"
},
{
\"id\": 10,
\"name\": \"Footer Ten\",
\"image\": \"images/prototypes/footer10.png\",
\"alt\" : \"Footer Ten\"
}
]', '[{\"id\":1,\"name\":\"Banner Section\",\"order\":1,\"file_name\":\"banner_section\",\"status\":1,\"image\":\"images\\/prototypes\\/banner_section.jpg\",\"alt\":\"Banner Section\"},{\"id\":5,\"name\":\"Categories\",\"order\":2,\"file_name\":\"categories\",\"status\":1,\"image\":\"images\\/prototypes\\/categories.jpg\",\"disabled_image\":\"images\\/prototypes\\/categories-cross.jpg\",\"alt\":\"Categories\"},{\"id\":7,\"name\":\"Info Boxes\",\"order\":3,\"file_name\":\"info_boxes\",\"status\":1,\"image\":\"images\\/prototypes\\/info_boxes.jpg\",\"disabled_image\":\"images\\/prototypes\\/info_boxes-cross.jpg\",\"alt\":\"Info Boxes\"},{\"id\":11,\"name\":\"Tab Products View\",\"order\":4,\"file_name\":\"tab\",\"status\":0,\"image\":\"images\\/prototypes\\/tab.jpg\",\"disabled_image\":\"images\\/prototypes\\/tab-cross.jpg\",\"alt\":\"Tab Products View\"},{\"id\":2,\"name\":\"Flash Sale Section\",\"order\":5,\"file_name\":\"flash_sale_section\",\"status\":1,\"image\":\"images\\/prototypes\\/flash_sale_section.jpg\",\"disabled_image\":\"images\\/prototypes\\/flash_sale_section-cross.jpg\",\"alt\":\"Flash Sale Section\"},{\"id\":10,\"name\":\"Second Ad Section\",\"order\":6,\"file_name\":\"sec_ad_banner\",\"status\":1,\"image\":\"images\\/prototypes\\/sec_ad_section.jpg\",\"disabled_image\":\"images\\/prototypes\\/sec_ad_section-cross.jpg\",\"alt\":\"Second Ad Section\"},{\"id\":9,\"name\":\"Top Selling\",\"order\":7,\"file_name\":\"top\",\"status\":1,\"image\":\"images\\/prototypes\\/top.jpg\",\"disabled_image\":\"images\\/prototypes\\/top-cross.jpg\",\"alt\":\"Top Selling\"},{\"id\":4,\"name\":\"Ad Section\",\"order\":8,\"file_name\":\"ad_banner_section\",\"status\":1,\"image\":\"images\\/prototypes\\/ad_banner_section.jpg\",\"disabled_image\":\"images\\/prototypes\\/ad_banner_section-cross.jpg\",\"alt\":\"Ad Section\"},{\"id\":8,\"name\":\"Newest Product Section\",\"order\":9,\"file_name\":\"newest_product\",\"status\":1,\"image\":\"images\\/prototypes\\/newest_product.jpg\",\"disabled_image\":\"images\\/prototypes\\/newest_product-cross.jpg\",\"alt\":\"Newest Product Section\"},{\"id\":3,\"name\":\"Special Products Section\",\"order\":10,\"file_name\":\"special\",\"status\":1,\"image\":\"images\\/prototypes\\/special_product.jpg\",\"disabled_image\":\"images\\/prototypes\\/special_product-cross.jpg\",\"alt\":\"Special Products Section\"},{\"id\":12,\"name\":\"Banner 2 Section\",\"order\":11,\"file_name\":\"banner_two_section\",\"status\":1,\"image\":\"images\\/prototypes\\/sec_ad_section.jpg\",\"disabled_image\":\"images\\/prototypes\\/sec_ad_section-cross.jpg\",\"alt\":\"Banner 2 Section\"},{\"id\":13,\"name\":\"Category\",\"order\":12,\"file_name\":\"Category_section\",\"status\":1,\"image\":\"images\\/prototypes\\/category_section.jpg\",\"disabled_image\":\"images\\/prototypes\\/category_section-cross.jpg\",\"alt\":\"Category 2 Section\"},{\"id\":6,\"name\":\"Blog Section\",\"order\":13,\"file_name\":\"blog_section\",\"status\":1,\"image\":\"images\\/prototypes\\/blog_section.jpg\",\"disabled_image\":\"images\\/prototypes\\/blog_section-cross.jpg\",\"alt\":\"Blog Section\"}]', '[      {         \"id\":1,       \"name\":\"Cart One\"    },    {         \"id\":2,       \"name\":\"Cart Two\"    }     ]', '[      {         \"id\":1,       \"name\":\"News One\"    },    {         \"id\":2,       \"name\":\"News Two\"    }     ]', '[  
{  
\"id\":1,
\"name\":\"Product Detail Page One\"
},
{  
\"id\":2,
\"name\":\"Product Detail Page Two\"
},
{  
\"id\":3,
\"name\":\"Product Detail Page Three\"
},
{  
\"id\":4,
\"name\":\"Product Detail Page Four\"
},
{  
\"id\":5,
\"name\":\"Product Detail Page Five\"
},
{  
\"id\":6,
\"name\":\"Product Detail Page Six\"
}

]', '[ { \"id\":1, \"name\":\"Shop Page One\" }, { \"id\":2, \"name\":\"Shop Page Two\" }, { \"id\":3, \"name\":\"Shop Page Three\" }, { \"id\":4, \"name\":\"Shop Page Four\" }, { \"id\":5, \"name\":\"Shop Page Five\" } ]', '[      {         \"id\":1,       \"name\":\"Contact Page One\"    },    {         \"id\":2,       \"name\":\"Contact Page Two\"    } ]', '[      {         \"id\":1,       \"name\":\"Login Page One\"    },    {         \"id\":2,       \"name\":\"Login Page Two\"    } ]', '[      {         \"id\":1,       \"name\":\"Transition Zoomin\"    },    {         \"id\":2,       \"name\":\"Transition Flashing\"    },    {         \"id\":3,       \"name\":\"Transition Shine\"    },    {         \"id\":4,       \"name\":\"Transition Circle\"    },    {         \"id\":5,       \"name\":\"Transition Opacity\"    } ]', '[ { \"id\": 1, \"name\": \"Banner One\", \"image\": \"images/prototypes/banner1.jpg\", \"alt\": \"Banner One\" }, { \"id\": 2, \"name\": \"Banner Two\", \"image\": \"images/prototypes/banner2.jpg\", \"alt\": \"Banner Two\" }, { \"id\": 3, \"name\": \"Banner Three\", \"image\": \"images/prototypes/banner3.jpg\", \"alt\": \"Banner Three\" }, { \"id\": 4, \"name\": \"Banner Four\", \"image\": \"images/prototypes/banner4.jpg\", \"alt\": \"Banner Four\" }, { \"id\": 5, \"name\": \"Banner Five\", \"image\": \"images/prototypes/banner5.jpg\", \"alt\": \"Banner Five\" }, { \"id\": 6, \"name\": \"Banner Six\", \"image\": \"images/prototypes/banner6.jpg\", \"alt\": \"Banner Six\" }, { \"id\": 7, \"name\": \"Banner Seven\", \"image\": \"images/prototypes/banner7.jpg\", \"alt\": \"Banner Seven\" }, { \"id\": 8, \"name\": \"Banner Eight\", \"image\": \"images/prototypes/banner8.jpg\", \"alt\": \"Banner Eight\" }, { \"id\": 9, \"name\": \"Banner Nine\", \"image\": \"images/prototypes/banner9.jpg\", \"alt\": \"Banner Nine\" }, { \"id\": 10, \"name\": \"Banner Ten\", \"image\": \"images/prototypes/banner10.jpg\", \"alt\": \"Banner Ten\" }, { \"id\": 11, \"name\": \"Banner Eleven\", \"image\": \"images/prototypes/banner11.jpg\", \"alt\": \"Banner Eleven\" }, { \"id\": 12, \"name\": \"Banner Twelve\", \"image\": \"images/prototypes/banner12.jpg\", \"alt\": \"Banner Twelve\" }, { \"id\": 13, \"name\": \"Banner Thirteen\", \"image\": \"images/prototypes/banner13.jpg\", \"alt\": \"Banner Thirteen\" }, { \"id\": 14, \"name\": \"Banner Fourteen\", \"image\": \"images/prototypes/banner14.jpg\", \"alt\": \"Banner Fourteen\" }, { \"id\": 15, \"name\": \"Banner Fifteen\", \"image\": \"images/prototypes/banner15.jpg\", \"alt\": \"Banner Fifteen\" }, { \"id\": 16, \"name\": \"Banner Sixteen\", \"image\": \"images/prototypes/banner16.jpg\", \"alt\": \"Banner Sixteen\" }, { \"id\": 17, \"name\": \"Banner Seventeen\", \"image\": \"images/prototypes/banner17.jpg\", \"alt\": \"Banner Seventeen\" }, { \"id\": 18, \"name\": \"Banner Eighteen\", \"image\": \"images/prototypes/banner18.jpg\", \"alt\": \"Banner Eighteen\" }, { \"id\": 19, \"name\": \"Banner Nineteen\", \"image\": \"images/prototypes/banner19.jpg\", \"alt\": \"Banner Nineteen\" } ]', '1');


TRUNCATE geo_zones; TRUNCATE home_banners; INSERT INTO home_banners (`home_banners_id`, `banner_name`, `language_id`, `text`, `image`, `created_at`, `updated_at`); VALUES ('1', 'banners_1', '1', '<div class=\\\"parallax-banner-text\\\">
        <div class=\\\"parallax-banner-text\\\">
        <h2> Food Festival</h2>
        <h4>Idul Adha Special</h4>
        <div class=\\\"hover-link\\\">
          <a href=\\\"/shop\\\" class=\\\"btn btn-secondary swipe-to-top\\\" data-toggle=\\\"tooltip\\\" data-placement=\\\"bottom\\\" title=\\\"\\\" data-original-title=\\\"View All Range\\\">Belanja Sekarang</a>
        </div>  
      </div>      </div>', '280', '2020-07-22 06:11:18', '2020-07-22 06:11:18');


INSERT INTO home_banners (`home_banners_id`, `banner_name`, `language_id`, `text`, `image`, `created_at`, `updated_at`); VALUES ('2', 'banners_2', '1', '<div class=\\\"parallax-banner-text\\\">
        <div class=\\\"parallax-banner-text\\\">
        <h2> BELANJA</h2>
        <h4>TANPA HARUS RIBET KELUAR RUMAH</h4>
        <div class=\\\"hover-link\\\">
          <a href=\\\"/shop\\\" class=\\\"btn btn-secondary swipe-to-top\\\" data-toggle=\\\"tooltip\\\" data-placement=\\\"bottom\\\" title=\\\"\\\" data-original-title=\\\"View All Range\\\">belanja Sekarang</a>
        </div>  
      </div>      </div>', '281', '2020-07-22 06:11:18', '2020-07-22 06:11:18');


INSERT INTO home_banners (`home_banners_id`, `banner_name`, `language_id`, `text`, `image`, `created_at`, `updated_at`); VALUES ('3', 'banners_3', '1', '<div class=\\\"parallax-banner-text\\\">
        <div class=\\\"parallax-banner-text\\\">
        <h2> ZONA BELANJA</h2>
        <h4>FAVORITE ANDA</h4>
        <div class=\\\"hover-link\\\">
          <a href=\\\"/shop\\\" class=\\\"btn btn-secondary swipe-to-top\\\" data-toggle=\\\"tooltip\\\" data-placement=\\\"bottom\\\" title=\\\"\\\" data-original-title=\\\"View All Range\\\">belanja Sekarang</a>
        </div>  
      </div>      </div>', '282', '2020-07-22 06:11:18', '2020-07-22 06:11:18');


TRUNCATE http_call_record; INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('1', 'mj3gi750fl42y--25tlzqxly5dmzm3cf', '15.2.0.10', 'sitesetting', '2020-09-07 06:35:46', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('2', 'js7fja0xy5gi5dq2edkpk24b6ifr69i9', '15.2.0.10', 'getallpages', '2020-09-07 06:35:46', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('3', 'w3bofz-enkmpxo3z1i00pbq-5kvit235', '15.2.0.10', 'getallproducts', '2020-09-07 06:35:58', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('4', 'sytdqnqdvfq1a230fwlb1naqdg57-13n', '15.2.0.10', 'getallproducts', '2020-09-07 06:35:58', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('5', 'z1nn52js6srmin2c7bdh7w9w-easfv8i', '15.2.0.10', 'getallproducts', '2020-09-07 06:35:58', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('6', '6jfhma2t-uk4h-i9ti7hpqvtq2aerq8c', '15.2.0.10', 'registerdevices', '2020-09-07 06:35:58', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('7', 'x90uydobxd129b9d1w0gngnav1azrnym', '15.2.0.10', 'getallproducts', '2020-09-07 06:35:58', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('8', 'xey-vcj4iyn9ehuybsp7rrrz-7qo74fy', '15.2.0.10', 'getbanners', '2020-09-07 06:35:58', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('9', 'jc3cc2cvf8zgd2eqhyugkyzpgcsn90e9', '15.2.0.10', 'sitesetting', '2020-09-07 06:36:05', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('10', '8whqg7i1y7riiym2913rv2tkfxqqih4m', '15.2.0.10', 'getallpages', '2020-09-07 06:36:05', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('11', 'l3q2sl36m5re1v4bxkjpw-b36g2cdqqn', '15.2.0.10', 'getbanners', '2020-09-07 06:36:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('12', 'mrcibrw6bvm07rd1-l9qgf7o8wjfl24y', '15.2.0.10', 'getallproducts', '2020-09-07 06:36:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('13', 'yd2znl4p9cbpkx0u0ozenro8z38kizg0', '15.2.0.10', 'getallproducts', '2020-09-07 06:36:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('14', 'y98zugcq3w5p6o0a6bi4lqanaqfcwfmv', '15.2.0.10', 'getallproducts', '2020-09-07 06:36:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('15', 'qyz4yj8pg3ovkdxmavjzzaurzx6b3rys', '15.2.0.10', 'allcategories', '2020-09-07 06:36:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('16', '-5fl2y67p53faw35nlttrf58-k28pw-p', '15.2.0.10', 'getallproducts', '2020-09-07 06:36:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('17', '031kku67yjsfrpne5o20nauq3g79l24g', '15.2.0.10', 'sitesetting', '2020-09-07 06:36:39', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('18', 'hizvq-w0q2jzhlafi9kc3kvxcjnvefn0', '15.2.0.10', 'getallpages', '2020-09-07 06:36:39', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('19', '4-c5wvf7hgeiwrdjt-y24pmlydga8ee4', '15.2.0.10', 'getallproducts', '2020-09-07 06:36:40', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('20', 'cw9s732wf2rcmtkfy1pvf5lyij-eodtr', '15.2.0.10', 'getallproducts', '2020-09-07 06:36:40', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('21', '-06yf3l3a06d38ue556s7eyhd8xx1w5j', '15.2.0.10', 'getbanners', '2020-09-07 06:36:40', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('22', 'lqiiuxp4ycy6y1wylhzn91-hizm21q-1', '15.2.0.10', 'getallproducts', '2020-09-07 06:36:40', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('23', '59b-r-kda4ub9v7lrtcm7j8x3goaptpi', '15.2.0.10', 'getallproducts', '2020-09-07 06:36:40', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('24', 'fss6-pktg5961s5xlhuyz2hh6sap6-85', '15.2.0.10', 'allcategories', '2020-09-07 06:36:40', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('25', '5xjjbnmirjhm8xoci53yo6lutszcqk3c', '15.2.0.10', 'sitesetting', '2020-09-07 07:15:43', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('26', 'nolnuo54upfe60408uvy5cybxofl9vgw', '15.2.0.10', 'getallpages', '2020-09-07 07:15:44', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('27', 'tzxkkvtw9rsxt4gqujtdxw3d7uwlhzg-', '15.2.0.10', 'sitesetting', '2020-09-07 07:15:44', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('28', '3ebnm10e5s1ar4ukxarphwtjt08faagg', '15.2.0.10', 'getallpages', '2020-09-07 07:15:44', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('29', 'nh31tb2akxoz6iaxclrzwh379p027gnn', '15.2.0.10', 'getallproducts', '2020-09-07 07:15:44', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('30', 'wzqc2qhsrez3-wro0r2kd094jfi6tz82', '15.2.0.10', 'getallproducts', '2020-09-07 07:15:44', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('31', '54ymltslq2q07u5dn8afw1hlp13uu30c', '15.2.0.10', 'getallproducts', '2020-09-07 07:15:45', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('32', '-n-gtnesh-ssgyzp6k4jfh2p49z8trda', '15.2.0.10', 'getbanners', '2020-09-07 07:15:45', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('33', 'ju-xaz4xpepmofjewc3w-cd269q6dacm', '15.2.0.10', 'getallproducts', '2020-09-07 07:15:45', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('34', 'fjnrwy6x96t4t7iqxx1zh0fuin0nprvm', '15.2.0.10', 'sitesetting', '2020-09-07 07:38:29', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('35', 'kmfmdqh087vz4yt2z01hnerxyynyt6w9', '15.2.0.10', 'getallpages', '2020-09-07 07:38:29', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('36', 'uc8h8nqe43ies0l44ahg641dmq31hry-', '15.2.0.10', 'sitesetting', '2020-09-07 07:38:30', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('37', 'nmsspc7kgmms1opb6l-cy2l9f-wrgqov', '15.2.0.10', 'getallpages', '2020-09-07 07:38:30', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('38', '14i9eiix97tgy2j-96cs49pauqh04mwc', '15.2.0.10', 'getallproducts', '2020-09-07 07:38:34', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('39', 'afrhuqwwpd55supreylliztgps7jatjl', '15.2.0.10', 'registerdevices', '2020-09-07 07:38:34', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('40', '2fmzc8nqn7792ern11zvceltt4son-5v', '15.2.0.10', 'getallproducts', '2020-09-07 07:38:35', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('41', '84oj26a-h2mj449d1ox-ylnhue937pc5', '15.2.0.10', 'getbanners', '2020-09-07 07:38:35', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('42', 'pv95bdvibd5y4ezxfq98m91u7h2a0on-', '15.2.0.10', 'getallproducts', '2020-09-07 07:38:35', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('43', 'etybbfim0sneisy3-b9bvgatxcm7sy-u', '15.2.0.10', 'getallproducts', '2020-09-07 07:38:35', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('44', 'jj5t6da329q0paig6udwccjwenou9fae', '15.2.0.10', 'allcategories', '2020-09-07 07:38:35', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('45', 'w2mv7rce3co4r4d10ww72-e4mzbgtvub', '15.2.0.10', 'sitesetting', '2020-09-07 07:38:52', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('46', '6ofp0avad50rp20mzk6ho25tjpvodfr1', '15.2.0.10', 'getallpages', '2020-09-07 07:38:53', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('47', 'dbydc7-l0vmp4uosabhkljvme3e8zx5l', '15.2.0.10', 'getallproducts', '2020-09-07 07:38:53', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('48', '-aq8lsgzqvjo4kxgiztbqzjfuk15wk4s', '15.2.0.10', 'getbanners', '2020-09-07 07:38:53', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('49', 'whrq7rnbim0bb4sk7pstvlb27szwc78w', '15.2.0.10', 'getallproducts', '2020-09-07 07:38:53', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('50', 'ned47uok1ey7hoolq9mfl0bt2c6hxy8t', '15.2.0.10', 'getallproducts', '2020-09-07 07:38:53', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('51', 'cu8aqrnbe6mvybmvh4t9zpxcdbzfopy4', '15.2.0.10', 'getallproducts', '2020-09-07 07:38:53', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('52', '04vihj1poyltql-3ayk-hn94hbecs4ih', '15.2.0.10', 'allcategories', '2020-09-07 07:38:54', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('53', 'omteywbgbdhkt9eh3p54jf3fea59zaat', '15.2.0.10', 'sitesetting', '2020-09-07 07:38:59', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('54', 'fzlldccaanu1dbon0d100d5lkcgdx0rj', '15.2.0.10', 'getallpages', '2020-09-07 07:39:00', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('55', 'rzyt-ysqoo022umohmybbr8556gxi87g', '15.2.0.10', 'getallproducts', '2020-09-07 07:39:00', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('56', 'tvyao6z-ukbuy2hn2ajydcl14m2nwz3o', '15.2.0.10', 'getbanners', '2020-09-07 07:39:00', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('57', 'k0ak1tw3uz1pob-imy82ogf75y27bums', '15.2.0.10', 'getallproducts', '2020-09-07 07:39:00', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('58', 'kp9ileyjtdjg1712ts4mcnaxx3u7wiws', '15.2.0.10', 'getallproducts', '2020-09-07 07:39:00', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('59', 'y7ao1v1iqhcxva0iwumocvuh613517q8', '15.2.0.10', 'getallproducts', '2020-09-07 07:39:00', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('60', 'nsyx9hehhqtmwumhuk4unirowyo58pkb', '15.2.0.10', 'allcategories', '2020-09-07 07:39:00', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('61', 'gtp35qrkp4d6xd2xxxmy2350v--5w6j6', '15.2.0.10', 'sitesetting', '2020-09-07 08:12:19', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('62', '5jzk--udwk-nkg0db6qvfdfxtxhiww7z', '15.2.0.10', 'getallpages', '2020-09-07 08:12:19', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('63', 'x1hpg6i2rgcux2jxb96wr6n86lzs5jw1', '15.2.0.10', 'sitesetting', '2020-09-07 08:12:19', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('64', 'wjkhm0gtbuqkqrun1fzqs0h650fowefp', '15.2.0.10', 'getallpages', '2020-09-07 08:12:20', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('65', 'q0d78w5stg3gb7jkwhea2ld0xicskdxv', '15.2.0.10', 'getallproducts', '2020-09-07 08:12:26', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('66', 'lqpbqr6lo8rx3cv1jwm3ubtzcvrrx-77', '15.2.0.10', 'registerdevices', '2020-09-07 08:12:26', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('67', '95e3c1-j0k6om2ojvt75pf-zwlleuhew', '15.2.0.10', 'getallproducts', '2020-09-07 08:12:26', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('68', 'khqhzfuvywu1gutjxxyeb6lcl74pgj3r', '15.2.0.10', 'getallproducts', '2020-09-07 08:12:26', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('69', 'hw3308nwhmmt5rzmtq7ds1zgzphu50er', '15.2.0.10', 'getbanners', '2020-09-07 08:12:26', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('70', '09fgims2agzm7auyd2fk18c2q1yd6-4j', '15.2.0.10', 'getallproducts', '2020-09-07 08:12:26', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('71', 'r5x7i63wrg2u4whr22enat5842axyt0g', '15.2.0.10', 'allcategories', '2020-09-07 08:12:27', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('72', 'ki6jhnq80ijg-48ougc5h1n1ovinm8xe', '15.2.0.10', 'sitesetting', '2020-09-07 13:52:04', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('73', 'nltgbywlhh5u8rtf7-ypc0k3bca-c4yd', '15.2.0.10', 'getallpages', '2020-09-07 13:52:04', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('74', '-16b3hvraz9ufw5ukiiv9gnknte4wmg6', '15.2.0.10', 'sitesetting', '2020-09-07 13:52:05', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('75', 'fbycds6whsch9ab87ff2pp-jvkv8vtat', '15.2.0.10', 'getallpages', '2020-09-07 13:52:05', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('76', 'ldugsqod-l99dxim3g14171ydham0vxi', '15.2.0.10', 'registerdevices', '2020-09-07 13:52:10', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('77', '9taw4gsjgms7-icjf08m43vy5dyiw306', '15.2.0.10', 'getbanners', '2020-09-07 13:52:10', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('78', 'pmv0fite9t3yyb7mlfxwrurngbmcm-yz', '15.2.0.10', 'allcategories', '2020-09-07 13:52:10', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('79', '89068ruu9m1kmy2pajx4re450jdo3ul0', '15.2.0.10', 'getfilters', '2020-09-07 13:52:10', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('80', 'en5e0khz4d8rw-k08bi7vx-ro1w3ucyf', '15.2.0.10', 'getallproducts', '2020-09-07 13:52:10', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('81', 'v7i72qg0bq9sh85p0r-2rn3839xdfgcv', '15.2.0.10', 'getfilters', '2020-09-07 13:52:10', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('82', 'qe8ph8owquo47hku45ak64v881kj6tnk', '15.2.0.10', 'getallproducts', '2020-09-07 13:52:10', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('83', '7vqz3-4z958qu8qgjoh6p625e5kbv61n', '15.2.0.10', 'sitesetting', '2020-09-07 13:52:37', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('84', 'l7ckvxole5jspe-wbu9mvkd-ly4qmka0', '15.2.0.10', 'getallpages', '2020-09-07 13:52:37', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('85', '3irc09y434g5ebo5z3ddmgw0-pojajec', '15.2.0.10', 'getbanners', '2020-09-07 13:52:37', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('86', 'uq9kd6h1h596qk9wh619yew-1d3fglxb', '15.2.0.10', 'allcategories', '2020-09-07 13:52:37', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('87', 'dllhdeplaiger11y2j-ohiflt004hkgb', '15.2.0.10', 'getallproducts', '2020-09-07 13:52:38', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('88', '8onw7jljz4hm7oc8bdfyxpd09-a4wtk8', '15.2.0.10', 'getallproducts', '2020-09-07 13:52:38', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('89', '6gx3zx68i1f--hxryw7tlenihfk35jgc', '15.2.0.10', 'getfilters', '2020-09-07 13:52:38', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('90', 'e7wfu7j61pwx3r94gk6t5kr9v2l5-57y', '15.2.0.10', 'getfilters', '2020-09-07 13:52:38', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('91', 'bdrqkd-bre2my2p3axokvqtmq1bv2i5t', '15.2.0.10', 'sitesetting', '2020-09-07 13:52:38', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('92', 'q78aq8qoghaugt487m--8fmavd4od6g8', '15.2.0.10', 'sitesetting', '2020-09-07 13:57:01', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('93', 'jnasbmrgt7z-3oebrlgofw0qak-9de71', '15.2.0.10', 'getallpages', '2020-09-07 13:57:01', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('94', '43v1cqhfx06e384ttiy3aumch6hhehuj', '15.2.0.10', 'registerdevices', '2020-09-07 13:57:05', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('95', '7i4wkxmkq92t9ltytybtrhgq-xrm6178', '15.2.0.10', 'getbanners', '2020-09-07 13:57:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('96', '3s7upknql-ynszbgx7c6bsmvde2l7r0n', '15.2.0.10', 'allcategories', '2020-09-07 13:57:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('97', '8bwjjmo185tssl-0d9vwvw2cvr5gb7pa', '15.2.0.10', 'getallproducts', '2020-09-07 13:57:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('98', '2jqklobl9f-15xgnljveqm4yq3fvjyua', '15.2.0.10', 'getfilters', '2020-09-07 13:57:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('99', 'mm7cw1itkya3693frw7hau6oyoqsc5gy', '15.2.0.10', 'getallproducts', '2020-09-07 13:57:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('100', 'n0x0zq2vglrsds3fcduzhstip-zuvwfe', '15.2.0.10', 'getfilters', '2020-09-07 13:57:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('101', '4dwh41l2g5v2a5p-j52x-ff-dogpyt26', '15.2.0.10', 'sitesetting', '2020-09-07 14:09:02', '2000-07-16 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('102', 'z77h7kx6blm2jt3fudubdiaefgnn-hh0', '15.2.0.10', 'getallpages', '2020-09-07 14:09:03', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('103', 'kric0kg91ravt1vgwayicobefp16-lhj', '15.2.0.10', 'sitesetting', '2020-09-07 14:09:03', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('104', 'y3pzdliifomaca2ldaio0gc77a-ac66q', '15.2.0.10', 'getallpages', '2020-09-07 14:09:03', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('105', 'df7iqqpx4xtryg26my-vsqeml7byja7s', '15.2.0.10', 'registerdevices', '2020-09-07 14:09:08', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('106', 'i-9z87igicl0zhzglaznrg4f-xbha7m1', '15.2.0.10', 'getbanners', '2020-09-07 14:09:08', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('107', '598d7lh5uz4ij884c8j11kojoxgs3s38', '15.2.0.10', 'allcategories', '2020-09-07 14:09:08', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('108', 'wui4bq05ffatcvu85er2aiwna6x0o733', '15.2.0.10', 'getallproducts', '2020-09-07 14:09:08', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('109', '8dm6ua8ua6g5we3wcdvskomdd7oa5spi', '15.2.0.10', 'getfilters', '2020-09-07 14:09:08', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('110', 'ybc0z1kgz5rochjys8lg72h2jd-e0pas', '15.2.0.10', 'getallproducts', '2020-09-07 14:09:08', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('111', 'rnz7p195br2uejfvzr8stgzllqlur6ac', '15.2.0.10', 'getfilters', '2020-09-07 14:09:08', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('112', 'hfozclo656-t9g60jgxj-ny3eiyvcz7q', '15.2.0.10', 'sitesetting', '2020-09-07 14:09:20', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('113', '833ja3px2ndq150apt1t1i2e9g4buiff', '15.2.0.10', 'getallpages', '2020-09-07 14:09:20', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('114', '-nceg79o1ucmtw5t8vr9gf66if8yp4pn', '15.2.0.10', 'getbanners', '2020-09-07 14:09:21', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('115', 'x6f36bolsids6zjksvnztb7j927s97xq', '15.2.0.10', 'allcategories', '2020-09-07 14:09:21', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('116', '5esdkm7oclvexmhughqfy6xzea5rq64z', '15.2.0.10', 'getallproducts', '2020-09-07 14:09:21', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('117', 'mlhtzm2dc31tmsa45j0br-c2lh8tikv2', '15.2.0.10', 'getfilters', '2020-09-07 14:09:21', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('118', 'h36y2a-upr38irdric57dmg97fjujd8m', '15.2.0.10', 'getfilters', '2020-09-07 14:09:21', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('119', '03zn4fagb4a9-iei25ld5xxbph8yhq24', '15.2.0.10', 'getallproducts', '2020-09-07 14:09:21', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('120', 'abvolr5vu0r78870frfkyr4jrh3gix4o', '15.2.0.10', 'sitesetting', '2020-09-07 14:09:21', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('121', 'c4brc9sh49qwqvjbuzi99o9efgswu8i3', '15.2.0.10', 'sitesetting', '2020-09-07 14:09:28', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('122', '2wj-wrka-88aahc5z49biqyj2fiep733', '15.2.0.10', 'getallpages', '2020-09-07 14:09:28', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('123', 'vmim0b788dyxg63ir13ox4d59uy0gnr1', '15.2.0.10', 'getbanners', '2020-09-07 14:09:28', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('124', 'm86cvlpuh1khz4ud1y-gcnxqjwioj555', '15.2.0.10', 'allcategories', '2020-09-07 14:09:29', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('125', 'x0h4dg0h2eu0jao4bnms329mqo6m0fcw', '15.2.0.10', 'getallproducts', '2020-09-07 14:09:29', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('126', 'n1bfm47mr7d3aqf-a2xe90-fcmv8s15q', '15.2.0.10', 'getfilters', '2020-09-07 14:09:29', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('127', 'ijdt-8ymj0bgx6ugpj5q63y9cm8lnjo6', '15.2.0.10', 'getfilters', '2020-09-07 14:09:29', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('128', 'dsddgnrrsxx08xdhv7s236xnspprld2m', '15.2.0.10', 'getallproducts', '2020-09-07 14:09:29', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('129', '0rg9tsi41iol-5-67hr7f7af9ssu552p', '15.2.0.10', 'sitesetting', '2020-09-07 14:09:29', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('130', 'hxlb0a0ubn2tvw6hw380ken5pays2wtw', '15.2.0.10', 'sitesetting', '2020-09-08 21:41:16', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('131', 'vp95x0imujoptvilv8z4b61krm3u3-5s', '15.2.0.10', 'getallpages', '2020-09-08 21:41:17', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('132', 'mtr5qy1iw9ux-cz6dbgdrd1qj82hzp0a', '15.2.0.10', 'registerdevices', '2020-09-08 21:41:23', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('133', 'np6o-nuwuis7hs1wpjh41-eegg60u0uy', '15.2.0.10', 'getbanners', '2020-09-08 21:41:23', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('134', 'e0p5c3vu0j1u7bay7s1chm2huovbvn8n', '15.2.0.10', 'allcategories', '2020-09-08 21:41:24', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('135', 'x2z97scqp6yapz6gqo82r7y0eumhiifv', '15.2.0.10', 'getallproducts', '2020-09-08 21:41:24', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('136', 'm5kgmhqwath9sd6jqbkieawjgtnly69k', '15.2.0.10', 'getallproducts', '2020-09-08 21:41:24', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('137', 'pe-87b2ulum5x5704gdlivc-lsq8c9ny', '15.2.0.10', 'getfilters', '2020-09-08 21:41:24', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('138', 'dv13clooe-5a55nw09hfs0ya316ch5-c', '15.2.0.10', 'getfilters', '2020-09-08 21:41:24', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('139', '325ojzso1hkgjccy1d1i62uwef11zgzy', '15.2.0.10', 'sitesetting', '2020-09-08 21:41:32', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('140', '03q3znvtxyiw4y8bbvukjs2gd9d9x0bk', '15.2.0.10', 'getallpages', '2020-09-08 21:41:32', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('141', '2zgrt0kv0tv-axm9z3ewywp315pofr1d', '15.2.0.10', 'sitesetting', '2020-09-08 21:41:33', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('142', 'guf8852p0x74il-wboewjo7tl2xm5xkj', '15.2.0.10', 'getallpages', '2020-09-08 21:41:33', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('143', '6shqmi9g4k3gij93jt88t0k90mhkkqir', '15.2.0.10', 'getbanners', '2020-09-08 21:41:33', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('144', '1ulym79g53ulapidovs9d850j83g3xp-', '15.2.0.10', 'allcategories', '2020-09-08 21:41:33', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('145', 'tdvhsf2eqc96r4dp71ngqkbv2bj8h156', '15.2.0.10', 'getallproducts', '2020-09-08 21:41:33', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('146', 'aolny3g5vgvb1mg4ufwkjqi22l1zytk9', '15.2.0.10', 'getfilters', '2020-09-08 21:41:33', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('147', 'k30huuyzyfjgc7yhz4p6vp24vfrw6q4c', '15.2.0.10', 'getallproducts', '2020-09-08 21:41:33', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('148', '-n3gqmgervj7cx3pkdv8vokjk07zvo15', '15.2.0.10', 'getfilters', '2020-09-08 21:41:33', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('149', 'd02rqxb4i6s5jcdv3xbeix9tgsaijctp', '15.2.0.10', 'sitesetting', '2020-09-08 21:41:39', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('150', '4j0ciq-uoynzvzzgyyz31ve4optea5xy', '15.2.0.10', 'getallpages', '2020-09-08 21:41:40', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('151', 'vsxzkmzd9lawkad9n8b95p155glv4ory', '15.2.0.10', 'getbanners', '2020-09-08 21:41:40', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('152', 'b0eax6oufv32gr3gh3i8m7by2ku7trcw', '15.2.0.10', 'allcategories', '2020-09-08 21:41:40', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('153', 'rqpbwjcqejbal7ej4j6r-yz8yisc7y0z', '15.2.0.10', 'getallproducts', '2020-09-08 21:41:41', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('154', 'a40kxacb87c0uazpu01tft8gxm2wzk2m', '15.2.0.10', 'getallproducts', '2020-09-08 21:41:41', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('155', 'bovf8p2gu0swbbljsea4xmcbova8w6jw', '15.2.0.10', 'getfilters', '2020-09-08 21:41:41', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('156', 'pz36leyzm46u7hoveisx18atzv5uxd30', '15.2.0.10', 'getfilters', '2020-09-08 21:41:41', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('157', 'mg-3e82cbf3j18rnrl58k82peame3-2w', '15.2.0.10', 'sitesetting', '2020-09-08 21:41:50', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('158', 'fk2uol8xe6qms--i-cutgx28az8b769j', '15.2.0.10', 'getallpages', '2020-09-08 21:41:51', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('159', '9-d9xhxcciptkxq23p7jczpf-1sogkyj', '15.2.0.10', 'sitesetting', '2020-09-08 21:41:52', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('160', 'jg0fl7id-vw1d99ku4tgpscf2ycrn53o', '15.2.0.10', 'getallpages', '2020-09-08 21:41:52', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('161', 'v43hm9s17dcjzie82rrguyhf415i2d2a', '15.2.0.10', 'getbanners', '2020-09-08 21:41:53', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('162', '6-o98szik97zi1h-ck48u5z0h9mwgo14', '15.2.0.10', 'allcategories', '2020-09-08 21:41:53', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('163', 'ja7gnd2ol34ork9is3a8uqezkm81hj9i', '15.2.0.10', 'getallproducts', '2020-09-08 21:41:54', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('164', '97sazjfjjwcruasdjwkzvlehu7u2por-', '15.2.0.10', 'getfilters', '2020-09-08 21:41:54', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('165', 'd9mjr92bt5mz-197pzfl5j1usq5tuuks', '15.2.0.10', 'getfilters', '2020-09-08 21:41:54', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('166', 'f7b2umxi-sfgq57bkpj2hvcr0hl3ktyw', '15.2.0.10', 'getallproducts', '2020-09-08 21:41:54', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('167', 's1irnw6vaim47s6sd570rmjp45srywmm', '15.2.0.10', 'sitesetting', '2020-09-08 21:43:48', '2000-01-14 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('168', 'f2-ltri1k1o1hs0zbyoyzivj76ogkkoe', '15.2.0.10', 'getallpages', '2020-09-08 21:43:48', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('169', 'ohv0026mp57s7x4kzgcmu5rdv4ia2p15', '15.2.0.10', 'sitesetting', '2020-09-08 21:43:49', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('170', 'bicji4tnoreuq2hope2qi5ho0-0s5jsj', '15.2.0.10', 'getallpages', '2020-09-08 21:43:49', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('171', 'gi-chpy--fn1da7dzisv3hx05rx2yi0k', '15.2.0.10', 'getbanners', '2020-09-08 21:43:49', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('172', 'k2u89ls9su5vy3f0tjsp34aknwjpwhgb', '15.2.0.10', 'allcategories', '2020-09-08 21:43:50', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('173', '138snelmnu7g7sd-611plk8d-xpt9s1n', '15.2.0.10', 'getallproducts', '2020-09-08 21:43:50', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('174', '5kai0qma20ometty88h-4n8ogi84xud4', '15.2.0.10', 'getallproducts', '2020-09-08 21:43:50', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('175', '7jkvsm-p3oomwj0pydgxwswb9jr9n46l', '15.2.0.10', 'getfilters', '2020-09-08 21:43:50', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('176', 'x0xu4sp9hkwatk5arrt2fbdh60ly4h8p', '15.2.0.10', 'getfilters', '2020-09-08 21:43:50', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('177', 'xyobrgfeng0cs7bm4jzck901myi80-h9', '15.2.0.10', 'sitesetting', '2020-09-08 21:43:58', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('178', 're6kl-keh4xicod7e9g0g4hb04lu11xx', '15.2.0.10', 'getallpages', '2020-09-08 21:43:58', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('179', 'gw3bm905zxrq-lmb281t4i8r0lq-6yn0', '15.2.0.10', 'getbanners', '2020-09-08 21:43:59', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('180', 'q4d0811adrzkej-98ftuefv-vmuerz3w', '15.2.0.10', 'allcategories', '2020-09-08 21:43:59', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('181', 'ae76cklx1iuys6bi9u5om6iza4w4qm2h', '15.2.0.10', 'getallproducts', '2020-09-08 21:44:00', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('182', 'kq8k1jv4ns9plni4jj1uvmuoe1q92ntk', '15.2.0.10', 'getfilters', '2020-09-08 21:44:00', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('183', '1ebhv28rqus85ixa9f5a5lhp3sl0m93n', '15.2.0.10', 'getallproducts', '2020-09-08 21:44:00', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('184', 'u4hcq9k3m8pg4wuezt1jr37ejbo2531u', '15.2.0.10', 'getfilters', '2020-09-08 21:44:00', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('185', 'k8dsqjibnlybosf3c1buizge3x1d3fp9', '15.2.0.10', 'sitesetting', '2020-09-08 21:44:00', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('186', '4m16f6jwfr1vpl1ohbehxj3369egggr5', '15.2.0.10', 'sitesetting', '2020-09-08 21:44:09', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('187', 'nqj6r65mr6wa6w8qdkgujo0-6onahs6w', '15.2.0.10', 'getallpages', '2020-09-08 21:44:09', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('188', '5mq18p3w4zapf4ynrkucg1jcjkkorx3d', '15.2.0.10', 'getbanners', '2020-09-08 21:44:10', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('189', '53j4yc2npbzavt-wlcv4047upzp99ec9', '15.2.0.10', 'allcategories', '2020-09-08 21:44:10', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('190', 'p-jm4fk4so1l5z57973k2nphu7cy9gyd', '15.2.0.10', 'getallproducts', '2020-09-08 21:44:10', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('191', '3-opp85npj9u8cn5qswoytucro7g4gi9', '15.2.0.10', 'getfilters', '2020-09-08 21:44:10', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('192', 'znw-zd31kqzhw2mpl7c8j84yeixv85v7', '15.2.0.10', 'getfilters', '2020-09-08 21:44:10', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('193', '0bk81u8jt4hmb31e62w8ky40gbbq-wxc', '15.2.0.10', 'getallproducts', '2020-09-08 21:44:10', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('194', 'cdg4y1h96d9gm6pwuglc4ntmylsjv3ig', '15.2.0.10', 'sitesetting', '2020-09-08 21:44:10', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('195', 'a4eam7gyn3120-0oijta88l6-kjwn065', '15.2.0.10', 'sitesetting', '2020-09-08 22:05:38', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('196', 'jkb28y2rz8tr9itkcexypnk9v3dxsx90', '15.2.0.10', 'getallpages', '2020-09-08 22:05:38', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('197', 'px2d1wpxpnbtg92i6pta9-jl6t20hk7g', '15.2.0.10', 'sitesetting', '2020-09-08 22:05:39', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('198', '2wg3dlad0th8tchiey2owk68ybucqiww', '15.2.0.10', 'getallpages', '2020-09-08 22:05:39', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('199', 'vkjh4ooewph7l95-f-isa2r-wssip33s', '15.2.0.10', 'registerdevices', '2020-09-08 22:05:56', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('200', 'hclb-98o9gbwjde7evsalpedz6pqovt7', '15.2.0.10', 'getbanners', '2020-09-08 22:05:56', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('201', 'irbcx1-ivatzf8x3y1m7gth-4ff7veou', '15.2.0.10', 'allcategories', '2020-09-08 22:05:56', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('202', '56312vl88jc10f6krhnjviktm-2r2jn0', '15.2.0.10', 'getallproducts', '2020-09-08 22:05:56', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('203', 'dgdpdtfjabmsx-xphfzrd8jc04n94g97', '15.2.0.10', 'getallproducts', '2020-09-08 22:05:56', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('204', 'b3nmcjrqcl63iw04qllswdsb2ndq1kvp', '15.2.0.10', 'getfilters', '2020-09-08 22:05:57', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('205', 'shhiwk10qnnr0oh4-03hd1yeqvx3npng', '15.2.0.10', 'getfilters', '2020-09-08 22:05:57', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('206', 'k3nkka7j9y16x1conf68zy0nqd9ap453', '15.2.0.10', 'sitesetting', '2020-09-08 22:09:20', '2000-02-03 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('207', '0hpi1d49iux8aatevlqm94rtjgrsm6pd', '15.2.0.10', 'getallpages', '2020-09-08 22:09:20', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('208', '6nmbaw-dnt2zq4dbvje8xcjzlke81q73', '15.2.0.10', 'sitesetting', '2020-09-08 22:09:21', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('209', '-wp928o23rjljhgjhfuv5w0s2hpryhsq', '15.2.0.10', 'getallpages', '2020-09-08 22:09:21', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('210', '09agm77h742fd2jl0mahd-wxy4swvsd3', '15.2.0.10', 'registerdevices', '2020-09-08 22:09:35', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('211', 'lueysic8bih6ajb15sfgiq9z--tnp3ao', '15.2.0.10', 'getbanners', '2020-09-08 22:09:35', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('212', 'ak0siv-r1mbj15wotgsm168wwsgjtbsx', '15.2.0.10', 'allcategories', '2020-09-08 22:09:35', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('213', 'gi6lqco9qmyt007bt8-xxyqqbe33qv--', '15.2.0.10', 'getallproducts', '2020-09-08 22:09:35', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('214', 's-p43ys4tnxsl0889qmlj8y9mshekxp2', '15.2.0.10', 'getfilters', '2020-09-08 22:09:35', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('215', 'lvg9ivq37y-olvvj8pyfxb1ce8msphz0', '15.2.0.10', 'getallproducts', '2020-09-08 22:09:35', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('216', 'girj0gv8jd3v8zxqjys4qd3j4ms3nvox', '15.2.0.10', 'getfilters', '2020-09-08 22:09:35', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('217', 'bxu0pj2ccbspou9cfb3jh9f14wrl7ahd', '15.2.0.10', 'sitesetting', '2020-09-08 23:05:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('218', 'h2xrh1rpj07utsru6o28tfp8war7mcjl', '15.2.0.10', 'getallpages', '2020-09-08 23:05:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('219', 'letnecwop8c9wqhq7xj-tcdnc4a7dzwj', '15.2.0.10', 'sitesetting', '2020-09-08 23:05:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('220', 'ohi5cwwnih922blhhmlervzomi36y3lw', '15.2.0.10', 'getallpages', '2020-09-08 23:05:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('221', 'x0f6gv01zg8lwm3-hnnruufo1eapnklr', '15.2.0.10', 'registerdevices', '2020-09-08 23:05:16', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('222', '109diael4fepkaih2b3v5x-zlt98iu-c', '15.2.0.10', 'getbanners', '2020-09-08 23:05:17', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('223', '0a9gvpa3egumgvv4j-1zpjhcd10vat6q', '15.2.0.10', 'allcategories', '2020-09-08 23:05:17', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('224', 'bhfrq1akwndl7n4p6wxvaw-jq8w61b6p', '15.2.0.10', 'getallproducts', '2020-09-08 23:05:17', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('225', 'e5hr6tlmhi10zwp8uqyowcmkvq1peq33', '15.2.0.10', 'getfilters', '2020-09-08 23:05:17', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('226', 'uzq3rqw55hol46vhq2t2iom3n9l5r6av', '15.2.0.10', 'getallproducts', '2020-09-08 23:05:17', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('227', '7mlqueou6hnfibw6rmhv5f0ebtgp4fe3', '15.2.0.10', 'getfilters', '2020-09-08 23:05:17', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('228', 'ulx25ymsf0ay4sj9ptp4ctxvutv9d9nz', '15.2.0.10', 'sitesetting', '2020-09-09 05:54:46', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('229', 'a4la-sr0afug2mteyt69xou6uujgs8w0', '15.2.0.10', 'getallpages', '2020-09-09 05:54:46', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('230', '05cdj9amsw1ddjvtkzyf9lqxl-bi6omi', '15.2.0.10', 'registerdevices', '2020-09-09 05:54:52', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('231', 'mg1jurkhjmheq3evoy3o4qz1h-ixfi-p', '15.2.0.10', 'getbanners', '2020-09-09 05:54:52', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('232', 'fuej4r0ey9olkm4qz1sh43jlyjeggmva', '15.2.0.10', 'allcategories', '2020-09-09 05:54:52', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('233', 'td7m4krs2exznmvto8q6wpxzmmqnk85s', '15.2.0.10', 'getfilters', '2020-09-09 05:54:52', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('234', '-z6hhixwim5nxiieg6b48ra3n7tvjo9l', '15.2.0.10', 'getallproducts', '2020-09-09 05:54:52', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('235', 'uubkng5elajuopn4m-uftku9836692ob', '15.2.0.10', 'getallproducts', '2020-09-09 05:54:52', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('236', 'ee-6xunypzufhe2y8swgdd8femxzyt7y', '15.2.0.10', 'getfilters', '2020-09-09 05:54:52', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('237', 'fqt39fzkbg86ma7w5xka1i59gukbz71b', '15.2.0.10', 'sitesetting', '2020-09-09 05:54:58', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('238', 'r2ohjd5njaq7ugeac0817nco5ynow-p9', '15.2.0.10', 'getallpages', '2020-09-09 05:54:58', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('239', '4d0tlm13htexi4efx4p8wftnx220bsv6', '15.2.0.10', 'getbanners', '2020-09-09 05:54:59', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('240', 'u1okxku8dbwoj293vgmmrcykinat7apy', '15.2.0.10', 'allcategories', '2020-09-09 05:54:59', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('241', 'qssry8xcze36e9ap-opx3adnm2l1vpax', '15.2.0.10', 'getallproducts', '2020-09-09 05:54:59', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('242', 'sew3drochap1pa3jtedusnavj5nabi1h', '15.2.0.10', 'getfilters', '2020-09-09 05:54:59', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('243', 'rhuskdwqrjs8ydf1gxl25nkmu8o9bu4m', '15.2.0.10', 'getfilters', '2020-09-09 05:54:59', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('244', 'eql6dwnic9zgnvssst5woh22qe2jh8hr', '15.2.0.10', 'getallproducts', '2020-09-09 05:54:59', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('245', '7y7zxsmmy8b8zahw6r0331blsh85gyov', '15.2.0.10', 'sitesetting', '2020-09-09 06:06:13', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('246', 'xy18vm-eq7qp9mwkbkcgnkvz-04hha4e', '15.2.0.10', 'getallpages', '2020-09-09 06:06:13', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('247', 'v3ueoxksxqcdo6y00aohm1j2rxf2lnaf', '15.2.0.10', 'registerdevices', '2020-09-09 06:06:26', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('248', 'x7xuokqasac5g84hmjoakj3id-s42v16', '15.2.0.10', 'getbanners', '2020-09-09 06:06:26', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('249', '1ww4qkg0ma0eogcdxexdcek4x9c8xa9c', '15.2.0.10', 'allcategories', '2020-09-09 06:06:26', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('250', 'x4tav5jtimd9kcvg5xy5vnfsgsd0e1q2', '15.2.0.10', 'getallproducts', '2020-09-09 06:06:27', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('251', 'km-6k73e5-h-wch0rbweiptjwy2l23qo', '15.2.0.10', 'getfilters', '2020-09-09 06:06:27', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('252', '6j4l8hiwz752oi8ngdgmzsv0r3i28711', '15.2.0.10', 'getallproducts', '2020-09-09 06:06:27', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('253', 'n01h3gwref8n2ov2p64u4p9gwo640w4t', '15.2.0.10', 'getfilters', '2020-09-09 06:06:27', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('254', '4wuneolhznthkb93z5ejcl528hm4mrqv', '15.2.0.10', 'sitesetting', '2020-09-09 06:06:32', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('255', 'emi-9ar9buki6fy-g972lbggc9jxukj0', '15.2.0.10', 'getallpages', '2020-09-09 06:06:32', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('256', 'rcocibmwxdgu-f881cvvfgsszyh3mo7m', '15.2.0.10', 'getbanners', '2020-09-09 06:06:32', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('257', '33kyknwqqqk7v02iu5qkr18e7lydcehl', '15.2.0.10', 'allcategories', '2020-09-09 06:06:32', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('258', 'fnoq8-lhz85l5c0eshpxxgvdzrg05usg', '15.2.0.10', 'getallproducts', '2020-09-09 06:06:32', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('259', 'ogr2ug5mefh3scw1em-mji15a-9y864b', '15.2.0.10', 'getfilters', '2020-09-09 06:06:32', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('260', 'gkob-z-4-nxuew1qfnzzjd8y7ycvyhk7', '15.2.0.10', 'getallproducts', '2020-09-09 06:06:32', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('261', 'em0oyz1ky0t9rgrzqa3dgyzqmdmdc915', '15.2.0.10', 'getfilters', '2020-09-09 06:06:32', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('262', 'k65izef8eje8316hz31shmc3drgck81p', '15.2.0.10', 'sitesetting', '2020-09-12 14:10:24', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('263', 'd6l9ymxyyls8fs5-klccl4rhi0magmq5', '15.2.0.10', 'getallpages', '2020-09-12 14:10:24', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('264', 'se0yv3vb8wlphpocgq40dy06duluu4r2', '15.2.0.10', 'registerdevices', '2020-09-12 14:10:31', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('265', 'k5niofpjluumrwje43j405l5ahigg6u8', '15.2.0.10', 'sitesetting', '2020-09-12 14:10:52', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('266', '-hb7lrkus7tz8jqcmx13d1ktmnajjav8', '15.2.0.10', 'getallpages', '2020-09-12 14:10:52', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('267', 'cbmiz1t1f1wwm9lca2aa4cglfvw2qq5l', '15.2.0.10', 'sitesetting', '2020-09-12 14:10:53', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('268', 'kd0esc3dt0b6qxaq5ccak5vgoa3bmrzq', '15.2.0.10', 'getallpages', '2020-09-12 14:10:53', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('269', 'yvbxw21787ulzwn2yk61qo84wlftt6ii', '15.2.0.10', 'sitesetting', '2020-09-12 14:11:08', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('270', 'zdlyez2jafitjtw84o2yq9onojqn4t9w', '15.2.0.10', 'getallpages', '2020-09-12 14:11:08', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('271', 'sixuja0-ula8qdlzz206ahyto6qkf-4l', '15.2.0.10', 'sitesetting', '2020-09-12 14:15:27', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('272', '0sx4bylh-z7kpied9688r6kmybpr6kck', '15.2.0.10', 'getallpages', '2020-09-12 14:15:29', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('273', 'dgr0bh4ovawkawozo3f1ubtrfywk097i', '15.2.0.10', 'sitesetting', '2020-09-12 14:15:30', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('274', 'qzc4bb3uo5sx-qf7z3fuawb87w254s4y', '15.2.0.10', 'getallpages', '2020-09-12 14:15:30', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('275', 'yl-o2uneztcizyccucytlzzxdnrlf8gh', '15.2.0.10', 'registerdevices', '2020-09-12 14:15:54', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('276', 'r1yv45p10xs8v4vgxewu0irghibc-5pc', '15.2.0.10', 'sitesetting', '2020-09-12 14:17:16', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('277', 'p08uzkj1ixl2znhpgvmt71b35-dg2m88', '15.2.0.10', 'getallpages', '2020-09-12 14:17:16', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('278', '294i4pqkg23pyy0e4ulj6o8q3ppn6a20', '15.2.0.10', 'sitesetting', '2020-09-14 06:14:41', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('279', 'e1jjoav-l91uaatbihv9n-5feprx1cti', '15.2.0.10', 'getallpages', '2020-09-14 06:14:41', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('280', 'hnxmd-4xhc870rt1pesdduwadjr4o-vn', '15.2.0.10', 'registerdevices', '2020-09-14 06:14:48', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('281', '081k6nnk9q8nsky3d3wu4g7wrfmujjuz', '15.2.0.10', 'sitesetting', '2020-09-14 06:18:32', '2000-02-24 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('282', 'cp4zgu08otykoraefw6aewekcuhw2yeu', '15.2.0.10', 'getallpages', '2020-09-14 06:18:32', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('283', 'o5l2493d6vdw3tbtcnjjkr-wa8drvojx', '15.2.0.10', 'sitesetting', '2020-09-14 06:18:34', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('284', '4ml2ac2bnodf1k3q9n72rqniu-6kh-mz', '15.2.0.10', 'getallpages', '2020-09-14 06:18:34', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('285', 'bygvl48bxqsmbksedsqk7jdowb1h1ud-', '15.2.0.10', 'registerdevices', '2020-09-14 06:18:40', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('286', '8zo4gt5nj4p85-9hk2qh9y9abnhy4-jq', '15.2.0.10', 'sitesetting', '2020-09-14 18:03:49', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('287', 'd-rbwkgs26s7g355w0nd1ajveu6bxws-', '15.2.0.10', 'getallpages', '2020-09-14 18:03:49', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('288', 'vfhfkpit5z4zpjh6rqy69heygzea96cu', '15.2.0.10', 'registerdevices', '2020-09-14 18:03:56', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('289', '74sxbhcc3jt8jvhovlzx4mgiq92i6niu', '15.2.0.10', 'getsearchdata', '2020-09-14 18:04:05', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('290', '33b-rmfl6otup7b43ffz--p5fnjugm2l', '15.2.0.10', 'getallproducts', '2020-09-14 18:04:08', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('291', '4g5ocxio4wjlz1--vqw1n0gydtg86onq', '15.2.0.10', 'getsearchdata', '2020-09-14 18:04:26', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('292', '-e3f6kjb7e25ulde62gmgwukf-1x9meq', '15.2.0.10', 'getallproducts', '2020-09-14 18:04:28', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('293', '4v7kgoggkccox97wiw5ee5flr9se3uta', '15.2.0.10', 'getsearchdata', '2020-09-14 18:05:03', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('294', 'qhnp30mk5ojqy7qznd1jl10x8b4nng1j', '15.2.0.10', 'getallproducts', '2020-09-14 18:05:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('295', 'iic1qty--kq1-d-wukgce2p2bktm9bm2', '15.2.0.10', 'sitesetting', '2020-09-14 18:10:10', '2000-03-04 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('296', '93s8vv3adg8zw0pnk1lktzr1mspzabqm', '15.2.0.10', 'getallpages', '2020-09-14 18:10:10', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('297', '6zknz8kkmitii56t216zhdmq00-isfcd', '15.2.0.10', 'getsearchdata', '2020-09-14 18:10:26', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('298', 'jv16s84clsc9oo0zacsf51xvej5-p1wu', '15.2.0.10', 'getallproducts', '2020-09-14 18:10:27', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('299', 'jbr6dqmv9eaifd4udo9t5koot70hf0ci', '15.2.0.10', 'sitesetting', '2020-09-14 18:11:47', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('300', 'z293n2nygwh7huhf-y3xmsr-bdv-e04c', '15.2.0.10', 'getallpages', '2020-09-14 18:11:47', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('301', 'vcg4ztfitxjhu1mq0pewdcjef2-l7jw-', '15.2.0.10', 'sitesetting', '2020-09-14 18:11:48', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('302', 'jddsw3t7gk7b806u20r8jddqe1nnora9', '15.2.0.10', 'getallpages', '2020-09-14 18:11:48', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('303', 'c4d5wjtz5-2040m77p068hjv6qjopenf', '15.2.0.10', 'getsearchdata', '2020-09-14 18:11:54', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('304', '2qzesfhx8bji2k6hcnx5foi8xby2dk5t', '15.2.0.10', 'getallproducts', '2020-09-14 18:11:57', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('305', 'vsn6k351dc80olz09frwop-egvoz9bx0', '15.2.0.10', 'sitesetting', '2020-09-14 18:14:04', '2000-01-27 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('306', '0tpeywj3xx3l7yus8pd9k8mkevi343ur', '15.2.0.10', 'getallpages', '2020-09-14 18:14:05', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('307', 'xe59jaj8qzf1np4kio1ruai1a64w2hjc', '15.2.0.10', 'sitesetting', '2020-09-14 18:14:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('308', '0l8982ei7ekneegzmq-28a8nqfi044rc', '15.2.0.10', 'getallpages', '2020-09-14 18:14:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('309', '0ami56j0g8aqrxykes-xnny8fuxu-lek', '15.2.0.10', 'sitesetting', '2020-09-14 18:14:15', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('310', '2cf1jkvrzdquz-4kxpw5w3xn5bvtt7vw', '15.2.0.10', 'getallpages', '2020-09-14 18:14:16', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('311', 't22fko3c1mxfd0d46ftstm144j820v0s', '15.2.0.10', 'sitesetting', '2020-09-14 18:14:16', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('312', 'm6fgdvqtjax0gsh3lo6f6j0qpss2px8w', '15.2.0.10', 'getallpages', '2020-09-14 18:14:16', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('313', 'uj3w3cfa3moia9ttw607-dwe9s419t4o', '15.2.0.10', 'getcurrencies', '2020-09-14 18:14:42', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('314', 'j4mcv2dwabpmwsahj6pcv-d2unjwfvb9', '15.2.0.10', 'sitesetting', '2020-09-14 18:14:45', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('315', 'wzre2fk6wzjuoczlfvr2vfuo0wdog9yj', '15.2.0.10', 'getallpages', '2020-09-14 18:14:45', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('316', 'y4yyp9avdf7qv9e6xgl5ytnfazpns94u', '15.2.0.10', 'getsearchdata', '2020-09-14 18:14:51', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('317', 'et3-egv0kkcpcn0hn-01l6bro821k3rb', '15.2.0.10', 'getallproducts', '2020-09-14 18:14:52', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('318', 'imyw5p21g3vi3pxb5pzz1r3lakn48hdq', '15.2.0.10', 'sitesetting', '2020-09-14 18:16:59', '2000-01-27 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('319', '2s-foc6nc1k5wwqd95v46ep3yomxukvh', '15.2.0.10', 'getallpages', '2020-09-14 18:16:59', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('320', 'otfw49g0h2f3crojh3l6liz-s23u0ht2', '15.2.0.10', 'sitesetting', '2020-09-14 18:16:59', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('321', 'iqwvmbsmts7s-41bwueekywfmsihnr3z', '15.2.0.10', 'getallpages', '2020-09-14 18:16:59', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('322', 'd4azecfnrsi3pnjhb5-7pxejsv2wia4y', '15.2.0.10', 'getsearchdata', '2020-09-14 18:17:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('323', 'em5ek5k5c5kv7cl997-wpgitz3r5ae3f', '15.2.0.10', 'getsearchdata', '2020-09-14 18:17:12', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('324', '5p3avgw20qtpgesub5lx1rpjmpujp6o2', '15.2.0.10', 'sitesetting', '2020-09-14 18:19:54', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('325', 'n4-dwffxt6sfupldyxlt-rkrog2dmcbu', '15.2.0.10', 'getallpages', '2020-09-14 18:19:55', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('326', '5c854f1asce3nmkfywzdodtvznp59geo', '15.2.0.10', 'sitesetting', '2020-09-14 18:19:55', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('327', 'iwl3eu4r9cgjinzies8ph1jovm34385h', '15.2.0.10', 'getallpages', '2020-09-14 18:19:55', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('328', 'ctd3tth-lmiy5q6ze-ca-mgvlc9g7b4g', '15.2.0.10', 'getsearchdata', '2020-09-14 18:19:59', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('329', 'ddmavsb6fxzrq-10czhbo6ljsiexki7r', '15.2.0.10', 'getallproducts', '2020-09-14 18:20:00', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('330', 's4jsjy06af1l3252e7vod4mix49blf2e', '15.2.0.10', 'getallproducts', '2020-09-14 18:20:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('331', 'ia2gagl8vf-5kx6obi40k6tmyea6pfgn', '15.2.0.10', 'sitesetting', '2020-09-15 05:47:53', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('332', 'oage0r2hf6bf5js-4g81r7ajhg4lzkvz', '15.2.0.10', 'getallpages', '2020-09-15 05:47:53', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('333', '3t46-4j5hdr9db6tl0re5li9rgeq7myg', '15.2.0.10', 'getlanguages', '2020-09-15 05:48:10', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('334', 'dh9es58tko2yveb6pj3078xgeyt8h7gm', '15.2.0.10', 'getsearchdata', '2020-09-15 05:48:22', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('335', 'g14hh8p3r35x9lo9oz8fva6achftxsmq', '15.2.0.10', 'getallproducts', '2020-09-15 05:48:24', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('336', 'o43ziar6qe5ry8jhm-z6tgtepdf2dmx-', '15.2.0.10', 'processlogin', '2020-09-15 05:49:24', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('337', '6x-se8gacloj315xpg-s85269gx-sdat', '15.2.0.10', 'processlogin', '2020-09-15 05:50:16', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('338', 'eo5wjzo2jv8t8ryqk2ai8ev7ffdk7p9z', '15.2.0.10', 'registerdevices', '2020-09-15 05:50:17', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('339', 'i24b5f5px43udcpft1ggdoap6zjbp9by', '15.2.0.10', 'getsearchdata', '2020-09-15 05:50:29', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('340', 'e1gktd-7f2qpjj61qk5lk9zadpie2rhq', '15.2.0.10', 'getsearchdata', '2020-09-15 05:50:36', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('341', 'ytw15ieua1np31z-lgddlqen7fv9xp75', '15.2.0.10', 'sitesetting', '2020-09-15 05:50:43', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('342', 'tnb9kni0as2f5bw75-we0c2ykkai9mow', '15.2.0.10', 'getallpages', '2020-09-15 05:50:44', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('343', 'nq8lqpccko09567lq0z-buzmru8dme-i', '15.2.0.10', 'getsearchdata', '2020-09-15 05:50:47', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('344', 'lkerr1u9sl5f26xjy0k9a4cg2vylugfm', '15.2.0.10', 'getsearchdata', '2020-09-15 05:50:50', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('345', 'wrq4pw9rj4y2bfqzuqphg1-xuv5nyckr', '15.2.0.10', 'getallproducts', '2020-09-15 05:50:56', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('346', '14326q7on6r2qpchtwlz9fmrg-08-x5r', '15.2.0.10', 'sitesetting', '2020-09-15 06:13:23', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('347', 'xpohj0glfoj-n36akte5v-h7fy3iqgld', '15.2.0.10', 'getallpages', '2020-09-15 06:13:23', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('348', 'j-zchta95-7fs-24ljz9qmktrawcbsa0', '15.2.0.10', 'sitesetting', '2020-09-15 06:13:24', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('349', 'quic4gb0x8e346tpl662i5z169w9zev5', '15.2.0.10', 'getallpages', '2020-09-15 06:13:24', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('350', '3kcpzm3j58o1v39vmfk696mugik76zad', '15.2.0.10', 'sitesetting', '2020-09-15 06:15:59', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('351', '9oyl3aghsolalf0buwj5n5ksen3pa0em', '15.2.0.10', 'getallpages', '2020-09-15 06:15:59', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('352', 'i0vi9wt4zo2pcnrq3axfxs4bb3pcqk8b', '15.2.0.10', 'sitesetting', '2020-09-15 16:41:44', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('353', 'sr9aowopvam5qxqwwqm44s2kllhbqrlw', '15.2.0.10', 'getallpages', '2020-09-15 16:41:45', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('354', 'f30p0jrrcq87rhtzm46li4bzrtdxilaq', '15.2.0.10', 'registerdevices', '2020-09-15 16:41:51', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('355', '-79l1224uod4m81ife2p82mv1dp0grgb', '15.2.0.10', 'sitesetting', '2020-09-16 07:30:15', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('356', 'sfauanzwp3zro7y12f36xoq6raee92qf', '15.2.0.10', 'getallpages', '2020-09-16 07:30:15', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('357', '8prnu-rehjf2ua9hz4k4w258ewoulrku', '15.2.0.10', 'sitesetting', '2020-09-16 07:33:05', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('358', 'gcx-ikyr87txaoirmj6nyqo-sgsttrl0', '15.2.0.10', 'getallpages', '2020-09-16 07:33:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('359', 'edtthre3elieyuqr5ktswn0qk7vvbwyn', '15.2.0.10', 'sitesetting', '2020-09-16 13:12:16', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('360', 'l52bxp3m5icjg39digdw29a79bpy-iwc', '15.2.0.10', 'getallpages', '2020-09-16 13:12:17', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('361', '4452c9usyyx5dtsca428ifgdyjmc70zb', '15.2.0.10', 'sitesetting', '2020-09-16 13:12:26', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('362', 'sgn-hg0m0460gtsx--szgauj1btcr3dl', '15.2.0.10', 'getallpages', '2020-09-16 13:12:28', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('363', 'ap-qetsvx1yg6xzwche56lyg4soykn9t', '15.2.0.10', 'sitesetting', '2020-09-16 20:10:57', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('364', '45375jeao5-0l2x-3spn4jhx9do1xwu1', '15.2.0.10', 'getallpages', '2020-09-16 20:10:57', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('365', 'i81xrj7qnnbkypx62pf4kfsd-3hl4ae9', '15.2.0.10', 'sitesetting', '2020-09-16 20:11:03', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('366', 'ns7aum81tb4p6a748wej8txn3-vyy5ls', '15.2.0.10', 'getallpages', '2020-09-16 20:11:04', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('367', '3cyzp9-13nsarw45x9ayo1ach1nq3dkx', '15.2.0.10', 'sitesetting', '2020-09-16 20:11:10', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('368', 'inumsw8-p79gce1g6xnmonxlsxx7-qn1', '15.2.0.10', 'getallpages', '2020-09-16 20:11:10', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('369', '7gdjpad5faxjzifg1q5fba2dozmaupzk', '15.2.0.10', 'sitesetting', '2020-09-16 20:11:21', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('370', 'uygiswn214r1456kuqibyq0s088amsby', '15.2.0.10', 'getallpages', '2020-09-16 20:11:21', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('371', 'nrwnjz1b--5hk2q8o2t64-v-rnspz4h1', '15.2.0.10', 'sitesetting', '2020-09-16 20:12:07', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('372', 'jj-vjh233195cwbs8x3i8nyoumq3oxhf', '15.2.0.10', 'getallpages', '2020-09-16 20:12:07', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('373', 'p88thkwr0t9iu5hk-x4mwbgnhfobdjsg', '15.2.0.10', 'sitesetting', '2020-09-16 20:18:14', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('374', 'b7-lmt5398m2m1vygtox9iu4yjhtspj2', '15.2.0.10', 'getallpages', '2020-09-16 20:18:14', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('375', '2bz-86oq4dman2a19txmj-hzpdp55pu7', '15.2.0.10', 'sitesetting', '2020-09-16 20:18:20', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('376', 'yj38-6ndvp1iq3t0y7m7d6vpw4ewogx1', '15.2.0.10', 'getallpages', '2020-09-16 20:18:20', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('377', 'awf1b92-n21e9lydnt0-gliscllae7ff', '15.2.0.10', 'sitesetting', '2020-09-21 09:44:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('378', 'b03hfkx6ienqh8hqwhxuvv-do-m29ym-', '15.2.0.10', 'getallpages', '2020-09-21 09:44:07', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('379', 'alyxmy4c83jgmnr8lk1vsel5upg3myao', '15.2.0.10', 'sitesetting', '2020-09-21 09:44:15', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('380', '2436v71oq7dhpgtk3lw1j69monhyjed-', '15.2.0.10', 'getallpages', '2020-09-21 09:44:15', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('381', 'u7nyeiq2zw5jk68la3gdpyhpu-4oz-2f', '15.2.0.10', 'sitesetting', '2020-09-21 09:44:21', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('382', '5qzi27yfu47ebz87gs83uxc8hrqqa199', '15.2.0.10', 'getallpages', '2020-09-21 09:44:21', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('383', 'v968fvt4f6cz7hgjxzkcaw4y-rrsh7d-', '15.2.0.10', 'sitesetting', '2020-09-21 09:44:29', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('384', 'urkyk-bg0a2egs9raw8ys6yc2pe4g8yq', '15.2.0.10', 'getallpages', '2020-09-21 09:44:29', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('385', 'z0dfn63o8y-kd5en2giyj19zvh15svpk', '15.2.0.10', 'sitesetting', '2020-09-21 09:44:58', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('386', 'lv8fc3hincs3fpzjc9mgzu4ar8w8en8g', '15.2.0.10', 'getallpages', '2020-09-21 09:44:58', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('387', 'a63oqz8-xj7qckvqgiw4zot-shisi4v0', '15.2.0.10', 'sitesetting', '2020-09-21 11:34:15', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('388', 'rtzwlqbn3xf0sb7e19uk7sv8srplub84', '15.2.0.10', 'getallpages', '2020-09-21 11:34:15', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('389', 'zzvk22zs4vvd0jd36zqb-be2rwcv78ea', '15.2.0.10', 'sitesetting', '2020-09-21 13:18:02', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('390', 'ofc92e49e2njvf3pl9ygm4l9v10plwr1', '15.2.0.10', 'getallpages', '2020-09-21 13:18:02', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('391', 'xd333l-tgemxe7b8sbg7bps6sysoip5c', '193.99.27.241', 'sitesetting', '2020-09-23 02:46:20', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('392', 'fm-5jwyou15x3od0xgholtr6vpb2bolx', '193.99.27.241', 'getallpages', '2020-09-23 02:46:20', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('393', 'uvtum36w7edlt9xjr1sfz3eiheq7m2d7', '193.99.27.241', 'sitesetting', '2020-09-23 02:47:18', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('394', 'yt56u1igtl-khaw610edrupikb3h0o20', '193.99.27.241', 'getallpages', '2020-09-23 02:47:18', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('395', 'yis4h0d20bvpi8hq0pqak1kk2b9mjyv3', '193.99.27.241', 'sitesetting', '2020-09-23 02:48:44', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('396', 'j4v01ipooib2jatosy609d99-xdpxwda', '193.99.27.241', 'getallpages', '2020-09-23 02:48:44', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('397', 'cniw5dr-ig5ikstjnil13zavofm0n-yr', '193.99.27.241', 'sitesetting', '2020-09-23 02:57:26', '2000-05-22 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('398', 'z371g2wpa8sbc1zsizrbaqx0385g221o', '193.99.27.241', 'getallpages', '2020-09-23 02:57:26', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('399', 'nzz89cpeqdj7gezyutu15kdilhykwgo9', '193.99.27.241', 'sitesetting', '2020-09-23 03:21:54', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('400', 's8ocmf-tzjsh9aagk59wi-8lj32wkimr', '193.99.27.241', 'getallpages', '2020-09-23 03:21:54', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('401', 'm0-at4qasxi2khmt4iiulkg3z7ze4yx9', '193.99.27.241', 'sitesetting', '2020-09-23 03:23:18', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('402', 'f2n0guifjdaf10jilgbevx-9b8vkimzh', '193.99.27.241', 'getallpages', '2020-09-23 03:23:18', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('403', 'b8mcdrxasidl70hgnahq5x3x4oi4bcm8', '193.99.27.241', 'sitesetting', '2020-09-23 03:24:43', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('404', 'xwwp02rk0uinatq5822n6wqzd8dc58b3', '193.99.27.241', 'getallpages', '2020-09-23 03:24:43', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('405', 'ihx6ybbons12ixxqbdsr0vuyj7l3tfe4', '193.99.27.241', 'getbanners', '2020-09-23 03:24:44', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('406', 'ujtscat01ux3-k-tvnw1qfpi1-8y4h52', '193.99.27.241', 'allcategories', '2020-09-23 03:24:44', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('407', 'mufd2rxlq-obukl464er1aymp-y-0vqw', '193.99.27.241', 'getallproducts', '2020-09-23 03:24:45', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('408', 'rhmrmdpm8bttdo8g88lg7oa9162o6mti', '193.99.27.241', 'getfilters', '2020-09-23 03:24:45', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('409', '-1s53b1fe63gr6q1g-42to8bx7b688e8', '193.99.27.241', 'getallproducts', '2020-09-23 03:24:45', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('410', 'ruxo4-t7prtoc4qxkbng75p4xbv7pc5c', '193.99.27.241', 'getfilters', '2020-09-23 03:24:45', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('411', 'q0x4favb09ldn1oks8krh48cixootesz', '52.51.5.83', 'sitesetting', '2020-09-24 02:38:29', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('412', 'fqn2hge3an3xye3pdhx402zg6q1fpwaf', '52.51.5.83', 'getallpages', '2020-09-24 02:38:29', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('413', '2vn-2ugkils6qcrzdpmmkqux3zozyure', '52.51.5.83', 'sitesetting', '2020-09-24 02:39:47', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('414', 'jzf52orfntdhz7l-ruh2hwxroojqj48k', '52.51.5.83', 'getallpages', '2020-09-24 02:39:47', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('415', 'my-vjufxtmluciux1mt0y9cj4sntg7k4', '52.51.5.83', 'sitesetting', '2020-09-24 02:40:26', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('416', '930c0to2l5gak0pjts5gtsa4xsixrul9', '52.51.5.83', 'getallpages', '2020-09-24 02:40:26', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('417', 'pn2pfi2pnn0zoy1d2sim5nlwanpphfef', '52.51.5.83', 'sitesetting', '2020-09-24 02:41:25', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('418', 'v5no27xc8764wsy706aurukf4ktj-vfk', '52.51.5.83', 'getallpages', '2020-09-24 02:41:26', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('419', 'binnlx3zgdfuyjgn6lj3sn0lk5aoxitm', '52.51.5.83', 'registerdevices', '2020-09-24 02:41:35', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('420', 'nuxuv7-xa-csmv7-s59-q74502sjh0wf', '52.51.5.83', 'getbanners', '2020-09-24 02:41:35', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('421', '54i9c484nhbi39yf7sxrew9m5whbbx6t', '52.51.5.83', 'allcategories', '2020-09-24 02:41:36', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('422', 'psxtjxyxt364paoa5xmeqnh6pg3iihoh', '52.51.5.83', 'getallproducts', '2020-09-24 02:41:36', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('423', '-v1ll9n42u5g0ok62ulubxo397s1b029', '52.51.5.83', 'getfilters', '2020-09-24 02:41:36', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('424', 'm9m7emjfm0ddr727v2b9rs7-fhm6bbsu', '52.51.5.83', 'getallproducts', '2020-09-24 02:41:36', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('425', 'w-gzu42tho-5u0c8tj6i7pj7qu2-tgvg', '52.51.5.83', 'getfilters', '2020-09-24 02:41:36', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('426', 'chwtygqw1az-b-fmp39acjfdevvzx-kn', '52.51.5.83', 'getallproducts', '2020-09-24 02:41:45', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('427', '5flhrnkkxuyq--ek5047pst02b-1gvq1', '52.51.5.83', 'getfilters', '2020-09-24 02:41:45', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('428', 'p5iu3t6cmzketm2xwoilbwm-vd2h9ukl', '52.51.5.83', 'getallproducts', '2020-09-24 02:41:46', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('429', '0ww-nx-e72ermlu887p3va1suivy861d', '52.51.5.83', 'getfilters', '2020-09-24 02:41:47', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('430', 'sui0qzovzh-webpk4x21ktm4qtcz-qm5', '52.51.5.83', 'sitesetting', '2020-09-24 02:42:20', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('431', 'ejb1kqx-0ro1nxp4t6bv4ridxrk9m3ob', '52.51.5.83', 'getallpages', '2020-09-24 02:42:20', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('432', '8vmdrue7e065royq225d-pnegrm28uhs', '52.51.5.83', 'getbanners', '2020-09-24 02:42:21', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('433', 's9slbotk4mpryc2u62pqmy4v7vyi7r29', '52.51.5.83', 'allcategories', '2020-09-24 02:42:21', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('434', 'z9n324dwwlcavny7-1z-stvmsz4vbgc6', '52.51.5.83', 'getallproducts', '2020-09-24 02:42:22', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('435', 'mhn-0spccyii898szwz6qyt8u74sdgda', '52.51.5.83', 'getallproducts', '2020-09-24 02:42:22', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('436', '922tkg7iuj8lgkeg7-1t0vayiq1m5hmb', '52.51.5.83', 'getfilters', '2020-09-24 02:42:22', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('437', 'j67lfmnd7d6c4ph8n1pqxe0ze92ikyeg', '52.51.5.83', 'getfilters', '2020-09-24 02:42:22', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('438', 'ivso41qiob2k5lracsyx8j8c5yyyz8wt', '52.51.5.83', 'getallproducts', '2020-09-24 02:42:28', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('439', 'dk2ukgjzszcmmino3i-zv5tk-cwjrbvu', '52.51.5.83', 'getfilters', '2020-09-24 02:42:28', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('440', 'v8gwjf8aj1yvi01ak5zimgovy08ybwod', '52.51.5.83', 'getfilters', '2020-09-24 02:42:30', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('441', 'hg0b22nnbmsclf2rzddx9giorzxtt351', '52.51.5.83', 'getallproducts', '2020-09-24 02:42:30', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('442', 'o92cqn5e5sct6dz2jwzkpfhm9o6qpf4k', '52.51.5.83', 'getallproducts', '2020-09-24 02:42:46', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('443', 'btif-xc5zfjsk-pvj21josalmy05v19z', '52.51.5.83', 'getfilters', '2020-09-24 02:42:46', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('444', 'ibw4c3l20zhgxuvwc6wc2stus-1h6qro', '52.51.5.83', 'getallproducts', '2020-09-24 02:42:46', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('445', 'sz55xjpf8ac0gl5ogixhmpt0voxmykl7', '52.51.5.83', 'getfilters', '2020-09-24 02:42:46', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('446', 'toyp85tu6g-7uvnhegnm3g5iwzaoer59', '15.2.0.10', 'sitesetting', '2020-09-26 02:30:59', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('447', 'lpvoionykanvmohh68j2pxbk0sxjzc36', '15.2.0.10', 'getallpages', '2020-09-26 02:30:59', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('448', '6lo0vcqg2wo5z8syjv6g5hivfcagfto0', '15.2.0.10', 'getbanners', '2020-09-26 02:31:00', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('449', 'z5w3gzs0vy0f5ogd5oqrea2oe63to5xv', '15.2.0.10', 'allcategories', '2020-09-26 02:31:00', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('450', '7tmpotk8u8w1l6qfx08nwv4rzal7x5ii', '15.2.0.10', 'getallproducts', '2020-09-26 02:31:00', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('451', 'q6xcckj2amwi-ifdkej25twrgnokytrc', '15.2.0.10', 'getfilters', '2020-09-26 02:31:00', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('452', 'ow56ohl4zqv217421bsul20d5q1iqk8z', '15.2.0.10', 'getallproducts', '2020-09-26 02:31:00', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('453', 'e9x9l9r8ol7q493m7t7e9k3il7f0r7j0', '15.2.0.10', 'getfilters', '2020-09-26 02:31:00', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('454', 'rt423nbvuteaav0denrudt5au33x6cgm', '15.2.0.10', 'getallproducts', '2020-09-26 02:31:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('455', 'ik4mzhi832fqzm37lwc8vqpaqcjpk6rl', '15.2.0.10', 'getfilters', '2020-09-26 02:31:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('456', 'an6ygd72zu7jez67txwhqkp6gs6tyn7x', '15.2.0.10', 'getallproducts', '2020-09-26 02:31:07', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('457', '5hs-6u-55-ymzvx9mivg0qfwwf0o8r5y', '15.2.0.10', 'getfilters', '2020-09-26 02:31:07', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('458', '0iev45d1m5g50x0gsm6ycbosdu0r3z1a', '15.2.0.10', 'getfilters', '2020-09-26 02:31:07', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('459', '0iev45d1m5g50x0gsm6ycbosdu0r3z1a', '15.2.0.10', 'getallproducts', '2020-09-26 02:31:07', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('460', '5s7q7n032-lagoq45qo1yrhid7tlpfau', '15.2.0.10', 'getallproducts', '2020-09-26 02:31:08', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('461', 'vigawc-u6re8b5evfhybjwbl5uixa6fm', '15.2.0.10', 'getfilters', '2020-09-26 02:31:08', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('462', 'um-d7217v4x8uvjl0lhqkt517kyq0z1i', '15.2.0.10', 'getallproducts', '2020-09-26 02:31:10', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('463', 'ocd3vuejy7g3i467udww1b3ea8p0fi3-', '15.2.0.10', 'getfilters', '2020-09-26 02:31:10', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('464', 'k2bus82tvumm1rx5sqw93d4xifv1gv99', '15.2.0.10', 'getallproducts', '2020-09-26 02:31:11', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('465', 'sd4uu08r172h3sx0il2ytyo-f9unq5lp', '15.2.0.10', 'getfilters', '2020-09-26 02:31:11', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('466', 'wtt1hiybz9vbhf5yvomnmcf2erxj-2xh', '15.2.0.10', 'getallproducts', '2020-09-26 02:31:11', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('467', '2-hjtcm90i55lnkhkv5q61n68mtaznod', '15.2.0.10', 'getfilters', '2020-09-26 02:31:11', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('468', '1mtq2klkhzo544m40y0ca7mgj8clj0cv', '15.2.0.10', 'sitesetting', '2020-09-26 18:34:00', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('469', '7pcqfguo2rkds9goopy-9r9e79tqlh7o', '15.2.0.10', 'getallpages', '2020-09-26 18:34:01', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('470', 'fnrx1j7pevk66b2doown6e4sfx3jkkrl', '15.2.0.10', 'getbanners', '2020-09-26 18:34:02', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('471', 'oiyabfd2s4tvqc3ytqufbb407dbybykk', '15.2.0.10', 'allcategories', '2020-09-26 18:34:02', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('472', '3e36ywuq9-t919ygn34keyw5szn5qo6j', '15.2.0.10', 'getfilters', '2020-09-26 18:34:03', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('473', '6qs78f92yojq-lqwby74uogh2cj92u6e', '15.2.0.10', 'getallproducts', '2020-09-26 18:34:03', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('474', '40a0hve8qeg7d6wtrpj21raocfacu2vm', '15.2.0.10', 'getallproducts', '2020-09-26 18:34:03', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('475', 'h6pib2iaq6q7t8m70ew93j1k2wp7h43d', '15.2.0.10', 'getfilters', '2020-09-26 18:34:03', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('476', 'z4xjcyl7ylzd8f-5wjep1ca6kt89s-kn', '15.2.0.10', 'getallproducts', '2020-09-26 18:34:36', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('477', '6rguy-9iczo6qv0jrrjkwz0zh9rt4vo9', '15.2.0.10', 'getfilters', '2020-09-26 18:34:36', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('478', '-ftjyq6w5grx2l3vzdqkmzxln8caa9x0', '15.2.0.10', 'getallproducts', '2020-09-26 18:34:36', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('479', '754wgbiq2-pq3ej-t0cv4ys4n4qkkma8', '15.2.0.10', 'getfilters', '2020-09-26 18:34:36', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('480', '2pzfkrkfcn7aw8l62gcbt02ulbsnnxg3', '15.2.0.10', 'getallproducts', '2020-09-26 18:34:40', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('481', 'is3dgjglh4mouyrzxhlrrua1xkm93lsp', '15.2.0.10', 'getfilters', '2020-09-26 18:34:40', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('482', 'lc77g4jn3sx461toyhh88-gy42udtin7', '15.2.0.10', 'sitesetting', '2020-09-27 10:25:31', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('483', 'ci5u9wrxppkl4puhs5t-embulgx8al06', '15.2.0.10', 'getallpages', '2020-09-27 10:25:31', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('484', 'gywnj7apuf6duh60ly8ej1-h8pjus7zu', '15.2.0.10', 'registerdevices', '2020-09-27 10:25:38', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('485', 'txpw0103smz-qj1h61zvjtp0p1o9sr78', '15.2.0.10', 'getbanners', '2020-09-27 10:25:39', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('486', 'tvxijedzpdmj8nt-ixkf6rg86bl8d6vr', '15.2.0.10', 'allcategories', '2020-09-27 10:25:39', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('487', 'da3x47l1nfn9bxeoooirj7ea40vtim8l', '15.2.0.10', 'getallproducts', '2020-09-27 10:25:39', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('488', '9zzqy7j1ah16gzgfvi4m86avybp0rya7', '15.2.0.10', 'getfilters', '2020-09-27 10:25:39', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('489', 'h53kyybqposd2qym3n4tgvm71oxs44q5', '15.2.0.10', 'getallproducts', '2020-09-27 10:25:39', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('490', '3kxzz8io9g94lb1ihd71y6n5cwkhljxe', '15.2.0.10', 'getfilters', '2020-09-27 10:25:39', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('491', '-5ewpvclh0pq3uzgencruzraxue7w4vf', '15.2.0.10', 'getallproducts', '2020-09-27 10:25:47', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('492', 'kxi40r4sranlvlgk7g4xgpkl4ph--ybx', '15.2.0.10', 'getfilters', '2020-09-27 10:25:47', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('493', 'flugiu7v8-a8ge9kc2xq4o8xhw--ch1a', '15.2.0.10', 'getfilters', '2020-09-27 10:25:48', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('494', '0rnysz8veg2f5yt1iisguhqd4gfcn1f0', '15.2.0.10', 'getallproducts', '2020-09-27 10:25:48', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('495', 'lsjtggow1t54eaiuvwmrzxd9oz1lr4pe', '15.2.0.10', 'getfilters', '2020-09-27 10:25:48', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('496', 'lsjtggow1t54eaiuvwmrzxd9oz1lr4pe', '15.2.0.10', 'getallproducts', '2020-09-27 10:25:48', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('497', 'yzc0k5bt9nz8yfusrhyqly7vj6xu056w', '15.2.0.10', 'getreviews', '2020-09-27 10:26:38', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('498', 'jfavx3vzhwetkb77rcabghqjo0ngwk0i', '15.2.0.10', 'getcurrencies', '2020-09-27 10:26:44', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('499', 'pyeeq6uk4jv-d0pso-937t8b3hs2judb', '15.2.0.10', 'sitesetting', '2020-09-27 10:26:48', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('500', 'r8jbn0ldawok-m14h8w9zukm7zpsk7cg', '15.2.0.10', 'getallpages', '2020-09-27 10:26:48', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('501', 'd1v9-bups75i1vexa1vrlm4do-luv6h2', '15.2.0.10', 'getbanners', '2020-09-27 10:26:49', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('502', 'gp9llj6qzaqlc6-8mp7pd8ilzlqjy0hi', '15.2.0.10', 'allcategories', '2020-09-27 10:26:49', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('503', 'tkh632r29a0rd2evtlekjrnx19-0chk9', '15.2.0.10', 'getallproducts', '2020-09-27 10:26:50', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('504', '6yp0kgwldfwfv-3rq0md8axioa-zgyj6', '15.2.0.10', 'getfilters', '2020-09-27 10:26:50', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('505', 'llta3md2z0vor4eywdxexg1fnloaj4lc', '15.2.0.10', 'getallproducts', '2020-09-27 10:26:50', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('506', 'llta3md2z0vor4eywdxexg1fnloaj4lc', '15.2.0.10', 'getfilters', '2020-09-27 10:26:50', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('507', 'm4oqo65iusxh6i5izdhh4tof-8t43e98', '15.2.0.10', 'getallproducts', '2020-09-27 10:26:57', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('508', '5t0rcyiuvkhvjqymi3ebetlels8jfw13', '15.2.0.10', 'getfilters', '2020-09-27 10:27:03', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('509', 'v0sr2fdwvdj-0fnwa47moruhq88hf2xp', '15.2.0.10', 'getfilters', '2020-09-27 10:27:03', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('510', '-xmeeidl38dkvpz7hdj6rclfzku3yzfg', '15.2.0.10', 'getallproducts', '2020-09-27 10:27:03', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('511', 'qcppjd8-k8xzrir7c4kgfnnz6s9fyynx', '15.2.0.10', 'getallproducts', '2020-09-27 10:27:03', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('512', 'nj96q07j1vw0ie6jjvf0-loqp56bm2vh', '15.2.0.10', 'sitesetting', '2020-09-27 20:44:46', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('513', 'g8ljc293659z9doen5749fwlzisx7109', '15.2.0.10', 'getallpages', '2020-09-27 20:44:46', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('514', '6pgq7x8lq6trohdsyhn2cso1ya9e9aws', '15.2.0.10', 'registerdevices', '2020-09-27 20:44:52', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('515', 'dqbqawdx-g2skuy7tziby43oio4fovu4', '15.2.0.10', 'getbanners', '2020-09-27 20:44:52', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('516', 'f1kubzlv8sxwi0dqv1-2b-esxhzqna5s', '15.2.0.10', 'allcategories', '2020-09-27 20:44:52', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('517', 'rnni7f1g1uweqjsz6-p0oawpw3q0ca6b', '15.2.0.10', 'getallproducts', '2020-09-27 20:44:52', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('518', 'jg1767lreiloxq52u6rqgb8a0q8fahju', '15.2.0.10', 'getallproducts', '2020-09-27 20:44:52', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('519', '89s2omlcmpi92-qe207uv565o0jxnahi', '15.2.0.10', 'getallproducts', '2020-09-27 20:44:52', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('520', 'xe0ys15thswaoslud20t-90snswyyi4b', '15.2.0.10', 'getallproducts', '2020-09-27 20:44:52', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('521', '7flzwrhd07s8ek4f8op0waug6ew5niv2', '15.2.0.10', 'getfilters', '2020-09-27 20:44:52', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('522', 'haabbvizemumygyldh-gf0zslzu89m2t', '15.2.0.10', 'getallproducts', '2020-09-27 20:45:12', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('523', '612pxbbnr42adrrz4hrxaq8ibi3jzq6g', '15.2.0.10', 'getcurrencies', '2020-09-27 20:45:29', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('524', 'g3knsbrm6wtj9uh72uqe1rmutr-3ybye', '15.2.0.10', 'sitesetting', '2020-09-27 20:45:32', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('525', '517sodfnetnxfjxyowkwoabtxztx3q66', '15.2.0.10', 'getallpages', '2020-09-27 20:45:32', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('526', 'hio03lxo342x2j6x6kgt4b-nzv76zks6', '15.2.0.10', 'getbanners', '2020-09-27 20:45:33', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('527', 'm64-d-ww2wp0-o5yr0o-4ypegnc208jb', '15.2.0.10', 'allcategories', '2020-09-27 20:45:33', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('528', 'pq3jt9liiwjd3rn9my6uxzpx8uesmmn5', '15.2.0.10', 'getallproducts', '2020-09-27 20:45:33', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('529', 'etilrug6b7ftz--1dr661c4xctl5j0w4', '15.2.0.10', 'getallproducts', '2020-09-27 20:45:33', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('530', 'b-9wb1e51xnao2s0fpz8m7hjl3yg-hb6', '15.2.0.10', 'getallproducts', '2020-09-27 20:45:33', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('531', '42pxblsakwlfjvx39a82yd9eqhjvbz1n', '15.2.0.10', 'getallproducts', '2020-09-27 20:45:33', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('532', '-becmu2xtizgxo24rcpo73q7spii3jo4', '15.2.0.10', 'getfilters', '2020-09-27 20:45:33', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('533', '0ei3bepblxv1d1f19wtmezzr3fokyni-', '15.2.0.10', 'getallproducts', '2020-09-27 20:45:46', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('534', 'tc0leek6koxhp8pguoke8m1ydkr7e03w', '15.2.0.10', 'sitesetting', '2020-09-27 20:46:18', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('535', 'qo04giihfphq--3-geo-gjrvmwojdkkb', '15.2.0.10', 'getallpages', '2020-09-27 20:46:18', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('536', 'lgi86xpn3otnbunab3xo6ikh61k-xwuf', '15.2.0.10', 'getbanners', '2020-09-27 20:46:18', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('537', '3wrnhdlax7cq0te0o9ffz3i551qay6mj', '15.2.0.10', 'allcategories', '2020-09-27 20:46:18', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('538', 'ui2boiefjmtfq5wms6enjt2na25-hsnl', '15.2.0.10', 'getallproducts', '2020-09-27 20:46:18', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('539', 'an1nq7gdae5f5p9v9qa6zlq7p6no3z07', '15.2.0.10', 'getallproducts', '2020-09-27 20:46:19', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('540', 'j7kemw1u343562wljff9q4egpfhfgtsa', '15.2.0.10', 'getallproducts', '2020-09-27 20:46:19', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('541', 'uj60lwnf4o4b2gcuhm33k0gedb3aglmc', '15.2.0.10', 'getfilters', '2020-09-27 20:46:19', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('542', 'jz1z01z-lp6bo72uagv7rh2l-fc0rb7b', '15.2.0.10', 'getallproducts', '2020-09-27 20:46:19', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('543', 'lbmuk1bgc0fybgb4frgx959l06454sys', '15.2.0.10', 'sitesetting', '2020-09-27 20:46:19', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('544', 'dgbrn2iu7tmye7ugiwvq7g8hzio2jfcf', '15.2.0.10', 'getallpages', '2020-09-27 20:46:19', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('545', 'jyirvatkfear775dgzocozveizkqtmmd', '15.2.0.10', 'sitesetting', '2020-09-27 20:48:05', '2000-01-06 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('546', 'q24pg0vmp50c38-7g9391kj-k226260v', '15.2.0.10', 'getallpages', '2020-09-27 20:48:05', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('547', 'ru-m705x6ke7cywgmuifl5l9eq3l8wh9', '15.2.0.10', 'getbanners', '2020-09-27 20:48:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('548', 'nlmp-0x05jy4f471suhi--qjevttj4ec', '15.2.0.10', 'allcategories', '2020-09-27 20:48:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('549', 'xmenbxxvlb8ex52ts7k441m-qjui33xe', '15.2.0.10', 'getallproducts', '2020-09-27 20:48:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('550', 'bpb9mn4pu9hp4alxf23p0stbw1nd0x1t', '15.2.0.10', 'getallproducts', '2020-09-27 20:48:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('551', 'ezkhvmq8cbe5al77pn60wpekwhueds5i', '15.2.0.10', 'getallproducts', '2020-09-27 20:48:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('552', 'b17x6f2-s5xizxoan0v9c6f2x1b-meki', '15.2.0.10', 'getallproducts', '2020-09-27 20:48:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('553', 'mkg0dr0wr4a3473n2wlfj2ta8dn7l6en', '15.2.0.10', 'sitesetting', '2020-09-27 20:48:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('554', 'ivpt8jhalvhzfokxsgzp06amsj8dx9i1', '15.2.0.10', 'getfilters', '2020-09-27 20:48:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('555', 'qunjf2inr88uv4jf75nfqg--eyfmjmkr', '15.2.0.10', 'getallpages', '2020-09-27 20:48:06', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('556', 'r52i-k3q215ghu3fcktxs6y7e7vzvs2z', '15.2.0.10', 'getallproducts', '2020-09-27 20:48:08', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('557', 'xqst9z012joizn705qimvpylmqsjsiam', '15.2.0.10', 'getfilters', '2020-09-27 20:48:08', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('558', '40iyg3hzb9tcqh0646wlt6xkmm0spbq9', '15.2.0.10', 'getfilters', '2020-09-27 20:48:08', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('559', 'o66pmv5ubagtzhpa8vvb2-k182q3u1dc', '15.2.0.10', 'getallproducts', '2020-09-27 20:48:08', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('560', '5s1f9lub9y82j4hsevhj4in1rwfon9cb', '15.2.0.10', 'getallproducts', '2020-09-27 20:48:08', '0000-00-00 00:00:00');


INSERT INTO http_call_record (`id`, `device_id`, `ip`, `url`, `ping_time`, `difference_from_previous`); VALUES ('561', '23b-l-ptrku9cj8r73f-rsnfgbhygytt', '15.2.0.10', 'getfilters', '2020-09-27 20:48:09', '0000-00-00 00:00:00');


TRUNCATE image_categories; INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('84', '83', 'ACTUAL', '277', '370', 'images/media/2019/10/JqYfZ11207.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('85', '83', 'THUMBNAIL', '112', '150', 'images/media/2019/10/thumbnail1570778231JqYfZ11207.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('86', '84', 'ACTUAL', '301', '770', 'images/media/2019/10/6Q4Qy11507.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('87', '85', 'ACTUAL', '550', '368', 'images/media/2019/10/jOVnc11207.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('88', '85', 'THUMBNAIL', '150', '100', 'images/media/2019/10/thumbnail1570778446jOVnc11207.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('89', '85', 'MEDIUM', '400', '268', 'images/media/2019/10/medium1570778446jOVnc11207.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('90', '86', 'ACTUAL', '220', '370', 'images/media/2019/10/Ake4A11107.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('91', '86', 'THUMBNAIL', '89', '150', 'images/media/2019/10/thumbnail1570778447Ake4A11107.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('96', '89', 'ACTUAL', '229', '270', 'images/media/2019/10/nDQtA11407.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('97', '89', 'THUMBNAIL', '127', '150', 'images/media/2019/10/thumbnail1570778680nDQtA11407.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('98', '90', 'ACTUAL', '298', '568', 'images/media/2019/10/ueyod11407.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('99', '90', 'THUMBNAIL', '79', '150', 'images/media/2019/10/thumbnail1570778749ueyod11407.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('100', '90', 'MEDIUM', '210', '400', 'images/media/2019/10/medium1570778749ueyod11407.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('101', '91', 'ACTUAL', '490', '570', 'images/media/2019/10/xD6MF11207.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('102', '91', 'THUMBNAIL', '129', '150', 'images/media/2019/10/thumbnail1570778967xD6MF11207.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('103', '91', 'MEDIUM', '344', '400', 'images/media/2019/10/medium1570778967xD6MF11207.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('104', '92', 'ACTUAL', '229', '270', 'images/media/2019/10/YZyoU11507.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('105', '92', 'THUMBNAIL', '127', '150', 'images/media/2019/10/thumbnail1570778968YZyoU11507.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('106', '93', 'ACTUAL', '301', '770', 'images/media/2019/10/RLshK11309.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('107', '93', 'THUMBNAIL', '59', '150', 'images/media/2019/10/thumbnail1570787475RLshK11309.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('108', '93', 'MEDIUM', '156', '400', 'images/media/2019/10/medium1570787476RLshK11309.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('109', '94', 'ACTUAL', '211', '570', 'images/media/2019/10/pTZdI11309.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('110', '94', 'THUMBNAIL', '56', '150', 'images/media/2019/10/thumbnail1570787731pTZdI11309.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('111', '94', 'MEDIUM', '148', '400', 'images/media/2019/10/medium1570787731pTZdI11309.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('112', '95', 'ACTUAL', '451', '570', 'images/media/2019/10/2t7BU11909.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('113', '95', 'THUMBNAIL', '119', '150', 'images/media/2019/10/thumbnail15707877532t7BU11909.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('114', '95', 'MEDIUM', '316', '400', 'images/media/2019/10/medium15707877542t7BU11909.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('115', '96', 'ACTUAL', '211', '270', 'images/media/2019/10/O0cLp11909.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('116', '96', 'THUMBNAIL', '117', '150', 'images/media/2019/10/thumbnail1570787792O0cLp11909.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('117', '97', 'ACTUAL', '298', '568', 'images/media/2019/10/ncXhn11709.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('118', '97', 'THUMBNAIL', '79', '150', 'images/media/2019/10/thumbnail1570787936ncXhn11709.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('119', '97', 'MEDIUM', '210', '400', 'images/media/2019/10/medium1570787936ncXhn11709.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('120', '98', 'ACTUAL', '452', '569', 'images/media/2019/10/3876V11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('121', '98', 'THUMBNAIL', '119', '150', 'images/media/2019/10/thumbnail15707880203876V11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('122', '98', 'MEDIUM', '318', '400', 'images/media/2019/10/medium15707880213876V11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('123', '99', 'ACTUAL', '451', '271', 'images/media/2019/10/80IGj11510.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('124', '99', 'THUMBNAIL', '150', '90', 'images/media/2019/10/thumbnail157078802180IGj11510.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('125', '99', 'MEDIUM', '400', '240', 'images/media/2019/10/medium157078802180IGj11510.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('126', '100', 'ACTUAL', '493', '370', 'images/media/2019/10/ueeqM11410.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('127', '100', 'THUMBNAIL', '150', '113', 'images/media/2019/10/thumbnail1570788170ueeqM11410.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('128', '100', 'MEDIUM', '400', '300', 'images/media/2019/10/medium1570788171ueeqM11410.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('129', '101', 'ACTUAL', '230', '370', 'images/media/2019/10/UrgVW11410.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('130', '101', 'THUMBNAIL', '93', '150', 'images/media/2019/10/thumbnail1570788171UrgVW11410.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('131', '102', 'ACTUAL', '230', '370', 'images/media/2019/10/a18kN11510.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('132', '102', 'THUMBNAIL', '93', '150', 'images/media/2019/10/thumbnail1570788301a18kN11510.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('133', '103', 'ACTUAL', '493', '370', 'images/media/2019/10/qQM0R11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('134', '103', 'THUMBNAIL', '150', '113', 'images/media/2019/10/thumbnail1570788302qQM0R11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('135', '103', 'MEDIUM', '400', '300', 'images/media/2019/10/medium1570788302qQM0R11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('136', '104', 'ACTUAL', '259', '770', 'images/media/2019/10/VrhhT11510.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('137', '104', 'THUMBNAIL', '50', '150', 'images/media/2019/10/thumbnail1570788382VrhhT11510.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('138', '104', 'MEDIUM', '135', '400', 'images/media/2019/10/medium1570788382VrhhT11510.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('139', '105', 'ACTUAL', '546', '372', 'images/media/2019/10/gSkR011310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('140', '105', 'THUMBNAIL', '150', '102', 'images/media/2019/10/thumbnail1570788383gSkR011310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('141', '105', 'MEDIUM', '400', '273', 'images/media/2019/10/medium1570788383gSkR011310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('142', '106', 'ACTUAL', '430', '1599', 'images/media/2019/10/DXoxt11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('143', '106', 'THUMBNAIL', '40', '150', 'images/media/2019/10/thumbnail1570789393DXoxt11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('144', '106', 'MEDIUM', '108', '400', 'images/media/2019/10/medium1570789394DXoxt11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('145', '106', 'LARGE', '242', '900', 'images/media/2019/10/large1570789394DXoxt11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('146', '107', 'ACTUAL', '236', '1169', 'images/media/2019/10/N4WSZ11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('147', '107', 'THUMBNAIL', '30', '150', 'images/media/2019/10/thumbnail1570789395N4WSZ11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('148', '107', 'MEDIUM', '81', '400', 'images/media/2019/10/medium1570789395N4WSZ11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('149', '107', 'LARGE', '182', '900', 'images/media/2019/10/large1570789395N4WSZ11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('150', '108', 'ACTUAL', '421', '1170', 'images/media/2019/10/z9MLR11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('151', '108', 'THUMBNAIL', '54', '150', 'images/media/2019/10/thumbnail1570789643z9MLR11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('152', '108', 'MEDIUM', '144', '400', 'images/media/2019/10/medium1570789643z9MLR11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('153', '108', 'LARGE', '324', '900', 'images/media/2019/10/large1570789644z9MLR11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('154', '109', 'ACTUAL', '418', '885', 'images/media/2019/10/YNVyV11410.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('155', '109', 'THUMBNAIL', '71', '150', 'images/media/2019/10/thumbnail1570789935YNVyV11410.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('156', '109', 'MEDIUM', '189', '400', 'images/media/2019/10/medium1570789935YNVyV11410.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('157', '110', 'ACTUAL', '387', '770', 'images/media/2019/10/YinE411810.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('158', '110', 'THUMBNAIL', '75', '150', 'images/media/2019/10/thumbnail1570790072YinE411810.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('159', '110', 'MEDIUM', '201', '400', 'images/media/2019/10/medium1570790072YinE411810.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('160', '111', 'ACTUAL', '421', '1600', 'images/media/2019/10/97VNC11210.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('161', '111', 'THUMBNAIL', '39', '150', 'images/media/2019/10/thumbnail157079031897VNC11210.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('162', '111', 'MEDIUM', '105', '400', 'images/media/2019/10/medium157079031997VNC11210.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('163', '111', 'LARGE', '237', '900', 'images/media/2019/10/large157079031997VNC11210.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('168', '114', 'ACTUAL', '179', '370', 'images/media/2019/10/zZZ2n11710.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('169', '114', 'THUMBNAIL', '73', '150', 'images/media/2019/10/thumbnail1570790472zZZ2n11710.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('170', '115', 'ACTUAL', '211', '370', 'images/media/2019/10/vMNsa11710.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('171', '115', 'THUMBNAIL', '86', '150', 'images/media/2019/10/thumbnail1570790553vMNsa11710.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('172', '116', 'ACTUAL', '208', '465', 'images/media/2019/10/qujIz11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('173', '116', 'THUMBNAIL', '67', '150', 'images/media/2019/10/thumbnail1570790554qujIz11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('174', '116', 'MEDIUM', '179', '400', 'images/media/2019/10/medium1570790554qujIz11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('176', '118', 'ACTUAL', '20', '30', 'images/media/2019/10/PJG0C11511.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('177', '119', 'ACTUAL', '20', '30', 'images/media/2019/10/SKOMJ11512.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('178', '120', 'ACTUAL', '20', '30', 'images/media/2019/10/newsletter.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('179', '121', 'ACTUAL', '820', '820', 'images/media/2020/07/RhCsh20105.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('180', '122', 'ACTUAL', '820', '820', 'images/media/2020/07/VRPoJ20105.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('181', '121', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595264483RhCsh20105.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('182', '122', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595264483VRPoJ20105.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('183', '121', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595264483RhCsh20105.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('184', '122', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595264483VRPoJ20105.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('185', '123', 'ACTUAL', '78', '300', 'images/media/2020/07/FQrzt20605.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('186', '123', 'THUMBNAIL', '39', '150', 'images/media/2020/07/thumbnail1595264483FQrzt20605.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('187', '124', 'ACTUAL', '721', '722', 'images/media/2020/07/KkzHg20705.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('188', '124', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595264605KkzHg20705.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('189', '124', 'MEDIUM', '399', '400', 'images/media/2020/07/medium1595264605KkzHg20705.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('190', '125', 'ACTUAL', '721', '722', 'images/media/2020/07/H7dnV20905.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('191', '125', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595264606H7dnV20905.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('192', '125', 'MEDIUM', '399', '400', 'images/media/2020/07/medium1595264606H7dnV20905.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('193', '126', 'ACTUAL', '721', '722', 'images/media/2020/07/GHcz420405.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('194', '126', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595264606GHcz420405.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('195', '126', 'MEDIUM', '399', '400', 'images/media/2020/07/medium1595264607GHcz420405.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('196', '127', 'ACTUAL', '721', '722', 'images/media/2020/07/1wxrC20705.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('197', '127', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail15952646071wxrC20705.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('198', '127', 'MEDIUM', '399', '400', 'images/media/2020/07/medium15952646071wxrC20705.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('199', '128', 'ACTUAL', '721', '722', 'images/media/2020/07/Onm1R20705.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('200', '128', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595264608Onm1R20705.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('201', '128', 'MEDIUM', '399', '400', 'images/media/2020/07/medium1595264608Onm1R20705.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('202', '129', 'ACTUAL', '721', '722', 'images/media/2020/07/dtoGy20805.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('203', '129', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595264609dtoGy20805.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('204', '129', 'MEDIUM', '399', '400', 'images/media/2020/07/medium1595264609dtoGy20805.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('205', '130', 'ACTUAL', '721', '722', 'images/media/2020/07/JX9AD20105.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('206', '130', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595264609JX9AD20105.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('207', '130', 'MEDIUM', '399', '400', 'images/media/2020/07/medium1595264609JX9AD20105.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('208', '131', 'ACTUAL', '721', '722', 'images/media/2020/07/ewGO120605.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('209', '131', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595264610ewGO120605.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('210', '132', 'ACTUAL', '721', '722', 'images/media/2020/07/NdPna20505.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('211', '132', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595264611NdPna20505.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('212', '132', 'MEDIUM', '399', '400', 'images/media/2020/07/medium1595264611NdPna20505.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('213', '133', 'ACTUAL', '721', '722', 'images/media/2020/07/D7wSD20105.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('214', '133', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595264625D7wSD20105.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('215', '133', 'MEDIUM', '399', '400', 'images/media/2020/07/medium1595264625D7wSD20105.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('216', '134', 'ACTUAL', '600', '600', 'images/media/2020/07/n55cl20805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('217', '134', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265462n55cl20805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('218', '134', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265462n55cl20805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('219', '135', 'ACTUAL', '600', '600', 'images/media/2020/07/AA7k520605.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('220', '135', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265462AA7k520605.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('221', '136', 'ACTUAL', '1024', '1024', 'images/media/2020/07/NOO0i20305.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('222', '135', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265462AA7k520605.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('223', '136', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265463NOO0i20305.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('224', '136', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265463NOO0i20305.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('225', '137', 'ACTUAL', '600', '600', 'images/media/2020/07/5tQWQ20105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('226', '137', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail15952654635tQWQ20105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('227', '136', 'LARGE', '900', '900', 'images/media/2020/07/large1595265463NOO0i20305.jpg', '', '2020-07-20 05:17:43');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('228', '137', 'MEDIUM', '400', '400', 'images/media/2020/07/medium15952654635tQWQ20105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('229', '138', 'ACTUAL', '600', '600', 'images/media/2020/07/hQZdF20905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('230', '138', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265463hQZdF20905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('231', '138', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265463hQZdF20905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('232', '139', 'ACTUAL', '600', '600', 'images/media/2020/07/1UYHj20905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('233', '139', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail15952654631UYHj20905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('234', '139', 'MEDIUM', '400', '400', 'images/media/2020/07/medium15952654631UYHj20905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('235', '140', 'ACTUAL', '600', '600', 'images/media/2020/07/TzZFS20205.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('236', '140', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265463TzZFS20205.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('237', '140', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265463TzZFS20205.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('238', '141', 'ACTUAL', '700', '900', 'images/media/2020/07/HXaPn20305.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('239', '141', 'THUMBNAIL', '117', '150', 'images/media/2020/07/thumbnail1595265464HXaPn20305.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('240', '141', 'MEDIUM', '311', '400', 'images/media/2020/07/medium1595265464HXaPn20305.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('241', '141', 'LARGE', '700', '900', 'images/media/2020/07/large1595265464HXaPn20305.jpg', '', '2020-07-20 05:17:44');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('242', '142', 'ACTUAL', '600', '600', 'images/media/2020/07/hIsS820805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('243', '142', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265464hIsS820805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('244', '142', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265464hIsS820805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('245', '143', 'ACTUAL', '1024', '1024', 'images/media/2020/07/wBece20805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('246', '143', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265465wBece20805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('247', '143', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265465wBece20805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('248', '143', 'LARGE', '900', '900', 'images/media/2020/07/large1595265465wBece20805.jpg', '', '2020-07-20 05:17:45');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('249', '144', 'ACTUAL', '600', '600', 'images/media/2020/07/gNoJs20205.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('250', '144', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265473gNoJs20205.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('251', '145', 'ACTUAL', '600', '600', 'images/media/2020/07/6svCC20405.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('252', '145', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail15952654736svCC20405.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('253', '144', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265473gNoJs20205.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('254', '145', 'MEDIUM', '400', '400', 'images/media/2020/07/medium15952654736svCC20405.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('255', '146', 'ACTUAL', '600', '600', 'images/media/2020/07/Zo9NW20405.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('256', '146', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265474Zo9NW20405.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('257', '146', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265474Zo9NW20405.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('258', '147', 'ACTUAL', '600', '600', 'images/media/2020/07/BmKll20305.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('259', '147', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265476BmKll20305.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('260', '148', 'ACTUAL', '600', '600', 'images/media/2020/07/2ljt220805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('261', '148', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail15952654762ljt220805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('262', '147', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265476BmKll20305.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('263', '148', 'MEDIUM', '400', '400', 'images/media/2020/07/medium15952654762ljt220805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('264', '149', 'ACTUAL', '600', '600', 'images/media/2020/07/6VhYU20605.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('265', '149', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail15952654766VhYU20605.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('266', '149', 'MEDIUM', '400', '400', 'images/media/2020/07/medium15952654766VhYU20605.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('267', '150', 'ACTUAL', '600', '600', 'images/media/2020/07/pegC720105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('268', '150', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265477pegC720105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('269', '150', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265477pegC720105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('270', '151', 'ACTUAL', '600', '600', 'images/media/2020/07/OPH7P20905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('271', '151', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265477OPH7P20905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('272', '152', 'ACTUAL', '600', '600', 'images/media/2020/07/FWJOF20605.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('273', '152', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265477FWJOF20605.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('274', '151', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265477OPH7P20905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('275', '152', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265477FWJOF20605.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('276', '153', 'ACTUAL', '600', '600', 'images/media/2020/07/EC3BR20705.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('277', '153', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265478EC3BR20705.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('278', '153', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265478EC3BR20705.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('279', '154', 'ACTUAL', '178', '283', 'images/media/2020/07/HsfVS20405.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('280', '154', 'THUMBNAIL', '94', '150', 'images/media/2020/07/thumbnail1595265488HsfVS20405.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('281', '155', 'ACTUAL', '600', '600', 'images/media/2020/07/TX3GN20805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('282', '155', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265488TX3GN20805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('283', '155', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265488TX3GN20805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('284', '156', 'ACTUAL', '600', '600', 'images/media/2020/07/2jwG820505.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('285', '156', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail15952654892jwG820505.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('286', '156', 'MEDIUM', '400', '400', 'images/media/2020/07/medium15952654892jwG820505.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('287', '157', 'ACTUAL', '600', '600', 'images/media/2020/07/CQjTW20105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('288', '157', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265489CQjTW20105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('289', '157', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265489CQjTW20105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('290', '158', 'ACTUAL', '600', '600', 'images/media/2020/07/x2wzK20105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('291', '159', 'ACTUAL', '600', '600', 'images/media/2020/07/9NAY520105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('292', '158', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265490x2wzK20105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('293', '159', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail15952654909NAY520105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('294', '158', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265490x2wzK20105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('295', '159', 'MEDIUM', '400', '400', 'images/media/2020/07/medium15952654909NAY520105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('296', '160', 'ACTUAL', '600', '600', 'images/media/2020/07/EUKHc20105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('297', '161', 'ACTUAL', '600', '600', 'images/media/2020/07/HUqXZ20905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('298', '160', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265491EUKHc20105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('299', '161', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265491HUqXZ20905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('300', '160', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265491EUKHc20105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('301', '161', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265491HUqXZ20905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('302', '162', 'ACTUAL', '700', '700', 'images/media/2020/07/EH7iD20105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('303', '163', 'ACTUAL', '240', '360', 'images/media/2020/07/SCpas20605.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('304', '162', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265491EH7iD20105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('305', '163', 'THUMBNAIL', '100', '150', 'images/media/2020/07/thumbnail1595265491SCpas20605.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('306', '162', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265491EH7iD20105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('307', '164', 'ACTUAL', '600', '600', 'images/media/2020/07/hHci420805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('308', '164', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265511hHci420805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('309', '164', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265511hHci420805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('310', '165', 'ACTUAL', '600', '600', 'images/media/2020/07/kMHBL20105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('311', '165', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265512kMHBL20105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('312', '165', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265512kMHBL20105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('313', '166', 'ACTUAL', '600', '600', 'images/media/2020/07/JaSX220305.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('314', '166', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265512JaSX220305.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('315', '166', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265512JaSX220305.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('316', '167', 'ACTUAL', '600', '600', 'images/media/2020/07/DvD9Y20505.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('317', '167', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265512DvD9Y20505.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('318', '167', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265512DvD9Y20505.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('319', '168', 'ACTUAL', '201', '251', 'images/media/2020/07/dvb2E20205.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('320', '168', 'THUMBNAIL', '120', '150', 'images/media/2020/07/thumbnail1595265513dvb2E20205.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('321', '169', 'ACTUAL', '121', '206', 'images/media/2020/07/KlTwk20305.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('322', '169', 'THUMBNAIL', '88', '150', 'images/media/2020/07/thumbnail1595265513KlTwk20305.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('323', '170', 'ACTUAL', '600', '600', 'images/media/2020/07/kxpB920305.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('324', '170', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265514kxpB920305.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('325', '170', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265514kxpB920305.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('326', '171', 'ACTUAL', '600', '600', 'images/media/2020/07/xsLss20905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('327', '171', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265515xsLss20905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('328', '171', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265515xsLss20905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('329', '172', 'ACTUAL', '208', '243', 'images/media/2020/07/Wi5kr20105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('330', '172', 'THUMBNAIL', '128', '150', 'images/media/2020/07/thumbnail1595265515Wi5kr20105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('331', '173', 'ACTUAL', '700', '700', 'images/media/2020/07/ILRpF20105.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('332', '173', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265516ILRpF20105.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('333', '173', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265516ILRpF20105.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('334', '174', 'ACTUAL', '600', '600', 'images/media/2020/07/OiGgP20105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('335', '174', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265549OiGgP20105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('336', '174', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265549OiGgP20105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('337', '175', 'ACTUAL', '600', '600', 'images/media/2020/07/emJyU20305.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('338', '175', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265549emJyU20305.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('339', '175', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265549emJyU20305.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('340', '176', 'ACTUAL', '600', '600', 'images/media/2020/07/ZBvp620805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('341', '176', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265549ZBvp620805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('342', '176', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265549ZBvp620805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('343', '177', 'ACTUAL', '694', '1140', 'images/media/2020/07/3hUzT20605.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('344', '178', 'ACTUAL', '600', '600', 'images/media/2020/07/v6dhb20405.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('345', '178', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265551v6dhb20405.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('346', '177', 'THUMBNAIL', '91', '150', 'images/media/2020/07/thumbnail15952655513hUzT20605.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('347', '178', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265551v6dhb20405.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('348', '177', 'MEDIUM', '244', '400', 'images/media/2020/07/medium15952655513hUzT20605.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('349', '177', 'LARGE', '548', '900', 'images/media/2020/07/large15952655513hUzT20605.png', '', '2020-07-20 05:19:11');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('350', '179', 'ACTUAL', '600', '600', 'images/media/2020/07/Wde0g20805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('351', '179', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265552Wde0g20805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('352', '179', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265552Wde0g20805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('353', '180', 'ACTUAL', '167', '301', 'images/media/2020/07/hzHK320105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('354', '180', 'THUMBNAIL', '83', '150', 'images/media/2020/07/thumbnail1595265552hzHK320105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('355', '181', 'ACTUAL', '600', '600', 'images/media/2020/07/K4KTH20405.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('356', '181', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265552K4KTH20405.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('357', '181', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265552K4KTH20405.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('358', '182', 'ACTUAL', '600', '600', 'images/media/2020/07/8g0lC20905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('359', '182', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail15952655538g0lC20905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('360', '182', 'MEDIUM', '400', '400', 'images/media/2020/07/medium15952655538g0lC20905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('361', '183', 'ACTUAL', '600', '600', 'images/media/2020/07/OhfXC20505.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('362', '183', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265553OhfXC20505.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('363', '183', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265553OhfXC20505.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('364', '184', 'ACTUAL', '190', '266', 'images/media/2020/07/0HAwo20305.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('365', '184', 'THUMBNAIL', '107', '150', 'images/media/2020/07/thumbnail15952655640HAwo20305.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('366', '185', 'ACTUAL', '600', '600', 'images/media/2020/07/1UCWk20905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('367', '185', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail15952655651UCWk20905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('368', '185', 'MEDIUM', '400', '400', 'images/media/2020/07/medium15952655651UCWk20905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('369', '186', 'ACTUAL', '600', '600', 'images/media/2020/07/XiEpV20805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('370', '186', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265566XiEpV20805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('371', '186', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265566XiEpV20805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('372', '187', 'ACTUAL', '600', '600', 'images/media/2020/07/EA3Gm20905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('373', '187', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265567EA3Gm20905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('374', '187', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265568EA3Gm20905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('375', '188', 'ACTUAL', '183', '275', 'images/media/2020/07/AyAyq20105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('376', '188', 'THUMBNAIL', '100', '150', 'images/media/2020/07/thumbnail1595265568AyAyq20105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('377', '189', 'ACTUAL', '1024', '1024', 'images/media/2020/07/JzMkU20205.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('378', '189', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265568JzMkU20205.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('379', '190', 'ACTUAL', '600', '600', 'images/media/2020/07/9789Q20505.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('380', '190', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail15952655689789Q20505.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('381', '190', 'MEDIUM', '400', '400', 'images/media/2020/07/medium15952655689789Q20505.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('382', '189', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265568JzMkU20205.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('383', '189', 'LARGE', '900', '900', 'images/media/2020/07/large1595265568JzMkU20205.jpg', '', '2020-07-20 05:19:28');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('384', '191', 'ACTUAL', '600', '600', 'images/media/2020/07/NwNFe20905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('385', '192', 'ACTUAL', '588', '578', 'images/media/2020/07/hWmJ020205.jpeg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('386', '191', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265568NwNFe20905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('387', '192', 'THUMBNAIL', '150', '147', 'images/media/2020/07/thumbnail1595265568hWmJ020205.jpeg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('388', '191', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265569NwNFe20905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('389', '192', 'MEDIUM', '400', '393', 'images/media/2020/07/medium1595265569hWmJ020205.jpeg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('390', '193', 'ACTUAL', '600', '600', 'images/media/2020/07/I1Wt120805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('391', '193', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265569I1Wt120805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('392', '193', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265569I1Wt120805.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('393', '194', 'ACTUAL', '600', '600', 'images/media/2020/07/PFbtA20605.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('394', '194', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265579PFbtA20605.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('395', '194', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265579PFbtA20605.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('396', '195', 'ACTUAL', '600', '600', 'images/media/2020/07/eqiJq20505.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('397', '195', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265580eqiJq20505.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('398', '195', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265580eqiJq20505.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('399', '196', 'ACTUAL', '800', '800', 'images/media/2020/07/YvW3W20105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('400', '196', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265581YvW3W20105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('401', '196', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265581YvW3W20105.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('402', '197', 'ACTUAL', '600', '600', 'images/media/2020/07/yOaAu20505.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('403', '197', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265581yOaAu20505.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('404', '197', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265581yOaAu20505.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('405', '198', 'ACTUAL', '600', '600', 'images/media/2020/07/u8oe020505.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('406', '198', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265582u8oe020505.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('407', '198', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265582u8oe020505.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('408', '199', 'ACTUAL', '188', '268', 'images/media/2020/07/mfMAL20905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('409', '199', 'THUMBNAIL', '105', '150', 'images/media/2020/07/thumbnail1595265582mfMAL20905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('410', '200', 'ACTUAL', '600', '600', 'images/media/2020/07/uTNlg20505.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('411', '200', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265582uTNlg20505.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('412', '200', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265582uTNlg20505.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('413', '201', 'ACTUAL', '600', '600', 'images/media/2020/07/s0Nto20505.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('414', '201', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265582s0Nto20505.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('415', '201', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265582s0Nto20505.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('416', '202', 'ACTUAL', '600', '600', 'images/media/2020/07/eJ6M720205.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('417', '203', 'ACTUAL', '174', '289', 'images/media/2020/07/toNBD20705.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('418', '202', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595265583eJ6M720205.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('419', '203', 'THUMBNAIL', '90', '150', 'images/media/2020/07/thumbnail1595265583toNBD20705.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('420', '202', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595265583eJ6M720205.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('421', '204', 'ACTUAL', '700', '700', 'images/media/2020/07/tDBKt20405.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('422', '204', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595266077tDBKt20405.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('423', '204', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595266078tDBKt20405.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('424', '205', 'ACTUAL', '600', '600', 'images/media/2020/07/0Pxjv20306.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('425', '206', 'ACTUAL', '1280', '1040', 'images/media/2020/07/XbMwF20706.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('426', '205', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail15952702830Pxjv20306.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('427', '205', 'MEDIUM', '400', '400', 'images/media/2020/07/medium15952702830Pxjv20306.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('428', '206', 'THUMBNAIL', '150', '122', 'images/media/2020/07/thumbnail1595270283XbMwF20706.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('429', '206', 'MEDIUM', '400', '325', 'images/media/2020/07/medium1595270283XbMwF20706.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('430', '206', 'LARGE', '900', '731', 'images/media/2020/07/large1595270283XbMwF20706.jpg', '', '2020-07-20 06:38:03');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('431', '207', 'ACTUAL', '565', '902', 'images/media/2020/07/cB2E020706.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('432', '207', 'THUMBNAIL', '94', '150', 'images/media/2020/07/thumbnail1595270283cB2E020706.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('433', '207', 'MEDIUM', '251', '400', 'images/media/2020/07/medium1595270284cB2E020706.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('434', '208', 'ACTUAL', '600', '930', 'images/media/2020/07/8esqh20106.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('435', '207', 'LARGE', '564', '900', 'images/media/2020/07/large1595270284cB2E020706.jpg', '', '2020-07-20 06:38:04');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('436', '208', 'THUMBNAIL', '97', '150', 'images/media/2020/07/thumbnail15952702848esqh20106.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('437', '208', 'MEDIUM', '258', '400', 'images/media/2020/07/medium15952702848esqh20106.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('438', '208', 'LARGE', '581', '900', 'images/media/2020/07/large15952702848esqh20106.jpg', '', '2020-07-20 06:38:04');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('439', '209', 'ACTUAL', '742', '1114', 'images/media/2020/07/10LIR20606.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('440', '209', 'THUMBNAIL', '100', '150', 'images/media/2020/07/thumbnail159527028410LIR20606.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('441', '210', 'ACTUAL', '600', '600', 'images/media/2020/07/W5inB20406.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('442', '209', 'MEDIUM', '266', '400', 'images/media/2020/07/medium159527028410LIR20606.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('443', '210', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270284W5inB20406.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('444', '210', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270284W5inB20406.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('445', '209', 'LARGE', '599', '900', 'images/media/2020/07/large159527028410LIR20606.jpg', '', '2020-07-20 06:38:04');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('446', '211', 'ACTUAL', '777', '1166', 'images/media/2020/07/VQdfH20606.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('447', '212', 'ACTUAL', '1024', '1024', 'images/media/2020/07/GXClG20406.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('448', '211', 'THUMBNAIL', '100', '150', 'images/media/2020/07/thumbnail1595270285VQdfH20606.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('449', '212', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270285GXClG20406.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('450', '211', 'MEDIUM', '267', '400', 'images/media/2020/07/medium1595270285VQdfH20606.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('451', '212', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270285GXClG20406.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('452', '211', 'LARGE', '600', '900', 'images/media/2020/07/large1595270285VQdfH20606.jpg', '', '2020-07-20 06:38:05');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('453', '212', 'LARGE', '900', '900', 'images/media/2020/07/large1595270285GXClG20406.jpg', '', '2020-07-20 06:38:05');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('454', '213', 'ACTUAL', '398', '600', 'images/media/2020/07/IoTgM20506.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('455', '213', 'THUMBNAIL', '100', '150', 'images/media/2020/07/thumbnail1595270286IoTgM20506.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('456', '213', 'MEDIUM', '265', '400', 'images/media/2020/07/medium1595270286IoTgM20506.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('457', '214', 'ACTUAL', '600', '600', 'images/media/2020/07/IQ1SU20606.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('458', '214', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270286IQ1SU20606.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('459', '214', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270286IQ1SU20606.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('460', '215', 'ACTUAL', '600', '600', 'images/media/2020/07/xbdz120806.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('461', '215', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270295xbdz120806.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('462', '215', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270295xbdz120806.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('463', '216', 'ACTUAL', '849', '1276', 'images/media/2020/07/nfk7g20606.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('464', '216', 'THUMBNAIL', '100', '150', 'images/media/2020/07/thumbnail1595270298nfk7g20606.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('465', '216', 'MEDIUM', '266', '400', 'images/media/2020/07/medium1595270298nfk7g20606.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('466', '216', 'LARGE', '599', '900', 'images/media/2020/07/large1595270299nfk7g20606.jpg', '', '2020-07-20 06:38:19');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('467', '217', 'ACTUAL', '900', '700', 'images/media/2020/07/ZSC9x20406.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('468', '217', 'THUMBNAIL', '150', '117', 'images/media/2020/07/thumbnail1595270300ZSC9x20406.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('469', '217', 'MEDIUM', '400', '311', 'images/media/2020/07/medium1595270300ZSC9x20406.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('470', '218', 'ACTUAL', '600', '902', 'images/media/2020/07/x8NwB20806.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('471', '218', 'THUMBNAIL', '100', '150', 'images/media/2020/07/thumbnail1595270300x8NwB20806.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('472', '218', 'MEDIUM', '266', '400', 'images/media/2020/07/medium1595270300x8NwB20806.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('473', '218', 'LARGE', '599', '900', 'images/media/2020/07/large1595270300x8NwB20806.jpg', '', '2020-07-20 06:38:20');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('474', '217', 'LARGE', '900', '700', 'images/media/2020/07/large1595270300ZSC9x20406.png', '', '2020-07-20 06:38:20');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('475', '219', 'ACTUAL', '600', '600', 'images/media/2020/07/td04I20106.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('476', '219', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270301td04I20106.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('477', '219', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270301td04I20106.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('478', '220', 'ACTUAL', '183', '275', 'images/media/2020/07/4PiF820706.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('479', '220', 'THUMBNAIL', '100', '150', 'images/media/2020/07/thumbnail15952703014PiF820706.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('480', '221', 'ACTUAL', '1346', '1346', 'images/media/2020/07/WVq8G20806.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('481', '222', 'ACTUAL', '800', '800', 'images/media/2020/07/EgfBD20506.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('482', '222', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270301EgfBD20506.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('483', '221', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270301WVq8G20806.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('484', '222', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270301EgfBD20506.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('485', '221', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270301WVq8G20806.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('486', '221', 'LARGE', '900', '900', 'images/media/2020/07/large1595270302WVq8G20806.jpg', '', '2020-07-20 06:38:22');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('487', '223', 'ACTUAL', '311', '356', 'images/media/2020/07/kBLNv20806.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('488', '223', 'THUMBNAIL', '131', '150', 'images/media/2020/07/thumbnail1595270302kBLNv20806.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('489', '224', 'ACTUAL', '1024', '1024', 'images/media/2020/07/xQMD620606.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('490', '224', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270302xQMD620606.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('491', '224', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270302xQMD620606.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('492', '224', 'LARGE', '900', '900', 'images/media/2020/07/large1595270303xQMD620606.jpg', '', '2020-07-20 06:38:23');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('493', '225', 'ACTUAL', '806', '1042', 'images/media/2020/07/TANkU20506.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('494', '226', 'ACTUAL', '921', '1382', 'images/media/2020/07/JVuPT20406.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('495', '225', 'THUMBNAIL', '116', '150', 'images/media/2020/07/thumbnail1595270318TANkU20506.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('496', '225', 'MEDIUM', '309', '400', 'images/media/2020/07/medium1595270318TANkU20506.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('497', '226', 'THUMBNAIL', '100', '150', 'images/media/2020/07/thumbnail1595270318JVuPT20406.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('498', '226', 'MEDIUM', '267', '400', 'images/media/2020/07/medium1595270318JVuPT20406.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('499', '225', 'LARGE', '696', '900', 'images/media/2020/07/large1595270318TANkU20506.jpg', '', '2020-07-20 06:38:38');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('500', '226', 'LARGE', '600', '900', 'images/media/2020/07/large1595270318JVuPT20406.jpg', '', '2020-07-20 06:38:38');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('501', '227', 'ACTUAL', '600', '600', 'images/media/2020/07/t8Nsy20706.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('502', '227', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270319t8Nsy20706.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('503', '227', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270319t8Nsy20706.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('504', '228', 'ACTUAL', '600', '600', 'images/media/2020/07/vi4fg20406.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('505', '228', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270319vi4fg20406.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('506', '228', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270319vi4fg20406.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('507', '229', 'ACTUAL', '600', '600', 'images/media/2020/07/2pJv920606.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('508', '229', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail15952703202pJv920606.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('509', '229', 'MEDIUM', '400', '400', 'images/media/2020/07/medium15952703202pJv920606.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('510', '230', 'ACTUAL', '600', '600', 'images/media/2020/07/y3KOy20406.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('511', '230', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270320y3KOy20406.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('512', '230', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270320y3KOy20406.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('513', '231', 'ACTUAL', '982', '1105', 'images/media/2020/07/sPQyG20506.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('514', '231', 'THUMBNAIL', '133', '150', 'images/media/2020/07/thumbnail1595270320sPQyG20506.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('515', '231', 'MEDIUM', '355', '400', 'images/media/2020/07/medium1595270320sPQyG20506.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('516', '232', 'ACTUAL', '800', '968', 'images/media/2020/07/YwmTW20706.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('517', '232', 'THUMBNAIL', '124', '150', 'images/media/2020/07/thumbnail1595270320YwmTW20706.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('518', '232', 'MEDIUM', '331', '400', 'images/media/2020/07/medium1595270320YwmTW20706.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('519', '231', 'LARGE', '800', '900', 'images/media/2020/07/large1595270320sPQyG20506.jpg', '', '2020-07-20 06:38:40');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('520', '232', 'LARGE', '744', '900', 'images/media/2020/07/large1595270320YwmTW20706.jpg', '', '2020-07-20 06:38:40');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('521', '233', 'ACTUAL', '600', '600', 'images/media/2020/07/RrKk420106.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('522', '233', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270321RrKk420106.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('523', '233', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270321RrKk420106.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('524', '234', 'ACTUAL', '332', '600', 'images/media/2020/07/F13oy20506.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('525', '234', 'THUMBNAIL', '83', '150', 'images/media/2020/07/thumbnail1595270321F13oy20506.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('526', '234', 'MEDIUM', '221', '400', 'images/media/2020/07/medium1595270321F13oy20506.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('527', '235', 'ACTUAL', '600', '600', 'images/media/2020/07/bMTMA20306.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('528', '235', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270339bMTMA20306.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('529', '235', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270339bMTMA20306.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('530', '236', 'ACTUAL', '819', '1228', 'images/media/2020/07/36Gg220406.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('531', '236', 'THUMBNAIL', '100', '150', 'images/media/2020/07/thumbnail159527033936Gg220406.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('532', '236', 'MEDIUM', '267', '400', 'images/media/2020/07/medium159527033936Gg220406.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('533', '236', 'LARGE', '600', '900', 'images/media/2020/07/large159527033936Gg220406.jpg', '', '2020-07-20 06:38:59');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('534', '237', 'ACTUAL', '600', '600', 'images/media/2020/07/sGyRZ20106.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('535', '237', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270340sGyRZ20106.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('536', '237', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270340sGyRZ20106.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('537', '238', 'ACTUAL', '600', '600', 'images/media/2020/07/jl01M20806.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('538', '238', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270340jl01M20806.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('539', '238', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270340jl01M20806.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('540', '239', 'ACTUAL', '600', '600', 'images/media/2020/07/urR2I20706.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('541', '239', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270340urR2I20706.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('542', '239', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270340urR2I20706.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('543', '240', 'ACTUAL', '777', '1166', 'images/media/2020/07/zWEz320206.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('544', '240', 'THUMBNAIL', '100', '150', 'images/media/2020/07/thumbnail1595270341zWEz320206.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('545', '240', 'MEDIUM', '267', '400', 'images/media/2020/07/medium1595270341zWEz320206.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('546', '240', 'LARGE', '600', '900', 'images/media/2020/07/large1595270341zWEz320206.jpg', '', '2020-07-20 06:39:01');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('547', '241', 'ACTUAL', '1024', '1024', 'images/media/2020/07/LWb5920206.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('548', '241', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270341LWb5920206.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('549', '242', 'ACTUAL', '600', '600', 'images/media/2020/07/m9JdC20606.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('550', '242', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270341m9JdC20606.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('551', '242', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270341m9JdC20606.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('552', '241', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270341LWb5920206.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('553', '241', 'LARGE', '900', '900', 'images/media/2020/07/large1595270342LWb5920206.jpg', '', '2020-07-20 06:39:02');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('554', '243', 'ACTUAL', '600', '600', 'images/media/2020/07/SAyKo20706.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('555', '243', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270342SAyKo20706.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('556', '243', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270342SAyKo20706.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('557', '244', 'ACTUAL', '1374', '916', 'images/media/2020/07/cNyR720706.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('558', '244', 'THUMBNAIL', '150', '100', 'images/media/2020/07/thumbnail1595270342cNyR720706.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('559', '244', 'MEDIUM', '400', '267', 'images/media/2020/07/medium1595270343cNyR720706.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('560', '244', 'LARGE', '900', '600', 'images/media/2020/07/large1595270343cNyR720706.jpg', '', '2020-07-20 06:39:03');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('561', '245', 'ACTUAL', '600', '600', 'images/media/2020/07/CpCLN20506.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('562', '245', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270370CpCLN20506.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('563', '245', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270370CpCLN20506.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('564', '246', 'ACTUAL', '1092', '1092', 'images/media/2020/07/tzJGu20506.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('565', '246', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270370tzJGu20506.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('566', '246', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270370tzJGu20506.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('567', '246', 'LARGE', '900', '900', 'images/media/2020/07/large1595270370tzJGu20506.jpg', '', '2020-07-20 06:39:30');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('568', '247', 'ACTUAL', '426', '640', 'images/media/2020/07/nI0dQ20906.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('569', '247', 'THUMBNAIL', '100', '150', 'images/media/2020/07/thumbnail1595270372nI0dQ20906.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('570', '247', 'MEDIUM', '266', '400', 'images/media/2020/07/medium1595270372nI0dQ20906.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('571', '248', 'ACTUAL', '1024', '1024', 'images/media/2020/07/oxhaU20406.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('572', '248', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270373oxhaU20406.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('573', '249', 'ACTUAL', '600', '600', 'images/media/2020/07/niLHL20806.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('574', '249', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270373niLHL20806.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('575', '249', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270373niLHL20806.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('576', '248', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270373oxhaU20406.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('577', '248', 'LARGE', '900', '900', 'images/media/2020/07/large1595270373oxhaU20406.jpg', '', '2020-07-20 06:39:33');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('578', '250', 'ACTUAL', '500', '750', 'images/media/2020/07/PFPfh20706.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('579', '250', 'THUMBNAIL', '100', '150', 'images/media/2020/07/thumbnail1595270374PFPfh20706.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('580', '250', 'MEDIUM', '267', '400', 'images/media/2020/07/medium1595270374PFPfh20706.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('581', '251', 'ACTUAL', '432', '650', 'images/media/2020/07/OKBZy20106.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('582', '251', 'THUMBNAIL', '100', '150', 'images/media/2020/07/thumbnail1595270374OKBZy20106.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('583', '251', 'MEDIUM', '266', '400', 'images/media/2020/07/medium1595270374OKBZy20106.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('584', '252', 'ACTUAL', '700', '700', 'images/media/2020/07/74uNe20206.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('585', '252', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail159527037574uNe20206.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('586', '252', 'MEDIUM', '400', '400', 'images/media/2020/07/medium159527037574uNe20206.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('587', '253', 'ACTUAL', '600', '600', 'images/media/2020/07/MbYqn20306.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('588', '253', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270513MbYqn20306.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('589', '253', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270513MbYqn20306.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('590', '254', 'ACTUAL', '393', '700', 'images/media/2020/07/Imavp20206.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('591', '254', 'THUMBNAIL', '84', '150', 'images/media/2020/07/thumbnail1595270513Imavp20206.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('592', '254', 'MEDIUM', '225', '400', 'images/media/2020/07/medium1595270513Imavp20206.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('593', '255', 'ACTUAL', '720', '1280', 'images/media/2020/07/uxqXH20206.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('594', '255', 'THUMBNAIL', '84', '150', 'images/media/2020/07/thumbnail1595270514uxqXH20206.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('595', '256', 'ACTUAL', '600', '600', 'images/media/2020/07/vgzXZ20806.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('596', '255', 'MEDIUM', '225', '400', 'images/media/2020/07/medium1595270514uxqXH20206.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('597', '256', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270514vgzXZ20806.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('598', '256', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270514vgzXZ20806.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('599', '255', 'LARGE', '506', '900', 'images/media/2020/07/large1595270514uxqXH20206.jpg', '', '2020-07-20 06:41:54');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('600', '257', 'ACTUAL', '600', '600', 'images/media/2020/07/a3C1u20306.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('601', '257', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270514a3C1u20306.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('602', '257', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270514a3C1u20306.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('603', '258', 'ACTUAL', '600', '600', 'images/media/2020/07/xNRv420506.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('604', '258', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270515xNRv420506.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('605', '258', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270515xNRv420506.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('606', '259', 'ACTUAL', '600', '600', 'images/media/2020/07/OUwz120306.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('607', '259', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270515OUwz120306.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('608', '260', 'ACTUAL', '600', '600', 'images/media/2020/07/PImij20706.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('609', '259', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270515OUwz120306.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('610', '260', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270515PImij20706.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('611', '260', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270515PImij20706.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('612', '261', 'ACTUAL', '600', '600', 'images/media/2020/07/i53qt20506.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('613', '261', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270515i53qt20506.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('614', '261', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270515i53qt20506.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('615', '262', 'ACTUAL', '600', '600', 'images/media/2020/07/ZeYB720306.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('616', '262', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270516ZeYB720306.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('617', '262', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270516ZeYB720306.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('618', '263', 'ACTUAL', '600', '600', 'images/media/2020/07/lBJA320106.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('619', '263', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270516lBJA320106.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('620', '263', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270516lBJA320106.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('621', '264', 'ACTUAL', '600', '600', 'images/media/2020/07/51nWY20206.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('622', '264', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail159527051651nWY20206.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('623', '264', 'MEDIUM', '400', '400', 'images/media/2020/07/medium159527051651nWY20206.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('624', '265', 'ACTUAL', '600', '600', 'images/media/2020/07/BVWoe20206.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('625', '265', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270517BVWoe20206.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('626', '265', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270517BVWoe20206.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('627', '266', 'ACTUAL', '600', '600', 'images/media/2020/07/paNK420606.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('628', '267', 'ACTUAL', '600', '600', 'images/media/2020/07/XYv9f20206.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('629', '266', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270517paNK420606.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('630', '267', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595270517XYv9f20206.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('631', '266', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270517paNK420606.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('632', '267', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595270517XYv9f20206.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('633', '268', 'ACTUAL', '600', '600', 'images/media/2020/07/L3R3F20106.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('634', '268', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595271092L3R3F20106.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('635', '268', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595271092L3R3F20106.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('636', '269', 'ACTUAL', '600', '600', 'images/media/2020/07/C0Kqs20606.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('637', '269', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595271447C0Kqs20606.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('638', '269', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595271447C0Kqs20606.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('641', '271', 'ACTUAL', '550', '673', 'images/media/2020/07/oDGvd20407.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('642', '271', 'THUMBNAIL', '123', '150', 'images/media/2020/07/thumbnail1595271886oDGvd20407.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('643', '271', 'MEDIUM', '327', '400', 'images/media/2020/07/medium1595271886oDGvd20407.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('644', '272', 'ACTUAL', '500', '500', 'images/media/2020/07/wLCTW20607.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('645', '272', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595272196wLCTW20607.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('646', '272', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595272196wLCTW20607.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('649', '274', 'ACTUAL', '510', '649', 'images/media/2020/07/Q4TpM20607.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('650', '274', 'THUMBNAIL', '118', '150', 'images/media/2020/07/thumbnail1595272733Q4TpM20607.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('651', '274', 'MEDIUM', '314', '400', 'images/media/2020/07/medium1595272733Q4TpM20607.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('652', '275', 'ACTUAL', '523', '669', 'images/media/2020/07/jJE8U20307.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('653', '275', 'THUMBNAIL', '117', '150', 'images/media/2020/07/thumbnail1595272829jJE8U20307.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('654', '275', 'MEDIUM', '313', '400', 'images/media/2020/07/medium1595272829jJE8U20307.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('655', '276', 'ACTUAL', '375', '500', 'images/media/2020/07/FroMu20907.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('656', '276', 'THUMBNAIL', '113', '150', 'images/media/2020/07/thumbnail1595272951FroMu20907.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('657', '276', 'MEDIUM', '300', '400', 'images/media/2020/07/medium1595272951FroMu20907.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('658', '277', 'ACTUAL', '800', '800', 'images/media/2020/07/2mDFY20807.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('659', '277', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail15952734872mDFY20807.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('660', '277', 'MEDIUM', '400', '400', 'images/media/2020/07/medium15952734882mDFY20807.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('661', '278', 'ACTUAL', '640', '640', 'images/media/2020/07/ZuGI821403.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('662', '278', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595344153ZuGI821403.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('663', '278', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595344153ZuGI821403.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('664', '279', 'ACTUAL', '421', '1600', 'images/media/2020/07/8DuYo22704.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('665', '279', 'THUMBNAIL', '39', '150', 'images/media/2020/07/thumbnail15954351108DuYo22704.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('666', '279', 'MEDIUM', '105', '400', 'images/media/2020/07/medium15954351108DuYo22704.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('667', '279', 'LARGE', '237', '900', 'images/media/2020/07/large15954351108DuYo22704.jpg', '', '2020-07-22 04:25:10');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('668', '280', 'ACTUAL', '1133', '1700', 'images/media/2020/07/SCe7t22904.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('669', '280', 'THUMBNAIL', '100', '150', 'images/media/2020/07/thumbnail1595435739SCe7t22904.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('670', '280', 'MEDIUM', '267', '400', 'images/media/2020/07/medium1595435739SCe7t22904.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('671', '280', 'LARGE', '600', '900', 'images/media/2020/07/large1595435739SCe7t22904.jpg', '', '2020-07-22 04:35:39');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('672', '281', 'ACTUAL', '1133', '1700', 'images/media/2020/07/nRyJs22904.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('673', '281', 'THUMBNAIL', '100', '150', 'images/media/2020/07/thumbnail1595435800nRyJs22904.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('674', '281', 'MEDIUM', '267', '400', 'images/media/2020/07/medium1595435800nRyJs22904.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('675', '281', 'LARGE', '600', '900', 'images/media/2020/07/large1595435800nRyJs22904.jpg', '', '2020-07-22 04:36:40');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('676', '282', 'ACTUAL', '1135', '1700', 'images/media/2020/07/6Hk5N22204.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('677', '282', 'THUMBNAIL', '100', '150', 'images/media/2020/07/thumbnail15954358676Hk5N22204.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('678', '282', 'MEDIUM', '267', '400', 'images/media/2020/07/medium15954358676Hk5N22204.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('679', '282', 'LARGE', '601', '900', 'images/media/2020/07/large15954358676Hk5N22204.jpg', '', '2020-07-22 04:37:47');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('680', '283', 'ACTUAL', '493', '370', 'images/media/2020/07/4IhlA22905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('681', '283', 'THUMBNAIL', '150', '113', 'images/media/2020/07/thumbnail15954399804IhlA22905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('682', '283', 'MEDIUM', '400', '300', 'images/media/2020/07/medium15954399804IhlA22905.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('683', '284', 'ACTUAL', '230', '370', 'images/media/2020/07/5jCJv22605.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('684', '284', 'THUMBNAIL', '93', '150', 'images/media/2020/07/thumbnail15954404195jCJv22605.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('685', '285', 'ACTUAL', '417', '626', 'images/media/2020/07/NboYg22406.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('686', '285', 'THUMBNAIL', '100', '150', 'images/media/2020/07/thumbnail1595440978NboYg22406.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('687', '285', 'MEDIUM', '266', '400', 'images/media/2020/07/medium1595440979NboYg22406.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('692', '287', 'ACTUAL', '720', '1280', 'images/media/2020/07/z5u6D22206.jpeg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('693', '287', 'THUMBNAIL', '84', '150', 'images/media/2020/07/thumbnail1595441260z5u6D22206.jpeg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('694', '287', 'MEDIUM', '225', '400', 'images/media/2020/07/medium1595441260z5u6D22206.jpeg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('695', '287', 'LARGE', '506', '900', 'images/media/2020/07/large1595441260z5u6D22206.jpeg', '', '2020-07-22 06:07:40');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('696', '288', 'ACTUAL', '600', '600', 'images/media/2020/07/tu0s824701.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('697', '288', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595554589tu0s824701.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('698', '288', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595554589tu0s824701.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('699', '289', 'ACTUAL', '225', '224', 'images/media/2020/07/OgLFb24101.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('700', '289', 'THUMBNAIL', '150', '149', 'images/media/2020/07/thumbnail1595554591OgLFb24101.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('701', '290', 'ACTUAL', '225', '225', 'images/media/2020/07/mAuV324401.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('702', '290', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595554592mAuV324401.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('703', '291', 'ACTUAL', '700', '700', 'images/media/2020/07/HEyS124801.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('704', '291', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595554592HEyS124801.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('705', '292', 'ACTUAL', '561', '697', 'images/media/2020/07/jJ8tN24501.jpeg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('706', '291', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595554592HEyS124801.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('707', '292', 'THUMBNAIL', '121', '150', 'images/media/2020/07/thumbnail1595554592jJ8tN24501.jpeg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('708', '292', 'MEDIUM', '322', '400', 'images/media/2020/07/medium1595554592jJ8tN24501.jpeg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('709', '293', 'ACTUAL', '600', '600', 'images/media/2020/07/7GYVJ24601.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('710', '293', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail15955545937GYVJ24601.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('711', '293', 'MEDIUM', '400', '400', 'images/media/2020/07/medium15955545937GYVJ24601.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('712', '294', 'ACTUAL', '600', '600', 'images/media/2020/07/XK4tk24401.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('713', '294', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595554595XK4tk24401.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('714', '294', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595554595XK4tk24401.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('715', '295', 'ACTUAL', '800', '800', 'images/media/2020/07/FquQ624301.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('716', '295', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595554595FquQ624301.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('717', '295', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595554595FquQ624301.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('718', '296', 'ACTUAL', '600', '600', 'images/media/2020/07/OYDGE24101.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('719', '296', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595554596OYDGE24101.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('720', '296', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595554596OYDGE24101.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('721', '297', 'ACTUAL', '225', '225', 'images/media/2020/07/miSm924201.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('722', '297', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595554598miSm924201.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('723', '298', 'ACTUAL', '721', '722', 'images/media/2020/07/pM4Fx24701.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('724', '298', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595554598pM4Fx24701.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('725', '298', 'MEDIUM', '399', '400', 'images/media/2020/07/medium1595554598pM4Fx24701.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('726', '299', 'ACTUAL', '480', '480', 'images/media/2020/07/os4GU24701.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('727', '299', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595554598os4GU24701.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('728', '299', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595554598os4GU24701.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('729', '300', 'ACTUAL', '600', '600', 'images/media/2020/07/4JJP024501.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('730', '300', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail15955546014JJP024501.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('731', '300', 'MEDIUM', '400', '400', 'images/media/2020/07/medium15955546014JJP024501.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('732', '301', 'ACTUAL', '159', '318', 'images/media/2020/07/spUbC24401.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('733', '301', 'THUMBNAIL', '75', '150', 'images/media/2020/07/thumbnail1595554603spUbC24401.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('734', '302', 'ACTUAL', '1024', '1024', 'images/media/2020/07/VN3Hw24301.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('735', '302', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595554604VN3Hw24301.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('736', '302', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595554604VN3Hw24301.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('737', '302', 'LARGE', '900', '900', 'images/media/2020/07/large1595554604VN3Hw24301.jpg', '', '2020-07-24 01:36:44');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('738', '303', 'ACTUAL', '500', '500', 'images/media/2020/07/CIjA424501.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('739', '303', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595554604CIjA424501.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('740', '303', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595554605CIjA424501.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('741', '304', 'ACTUAL', '500', '500', 'images/media/2020/07/BCHYs24801.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('742', '304', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595554606BCHYs24801.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('743', '304', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595554606BCHYs24801.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('744', '305', 'ACTUAL', '600', '600', 'images/media/2020/07/MHRNi24501.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('745', '305', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595554606MHRNi24501.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('746', '305', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595554606MHRNi24501.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('747', '306', 'ACTUAL', '600', '600', 'images/media/2020/07/5ydaL24101.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('748', '306', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail15955546085ydaL24101.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('749', '306', 'MEDIUM', '400', '400', 'images/media/2020/07/medium15955546085ydaL24101.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('750', '307', 'ACTUAL', '372', '476', 'images/media/2020/07/6bQFH24901.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('751', '307', 'THUMBNAIL', '117', '150', 'images/media/2020/07/thumbnail15955549006bQFH24901.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('752', '307', 'MEDIUM', '313', '400', 'images/media/2020/07/medium15955549006bQFH24901.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('753', '308', 'ACTUAL', '1024', '1024', 'images/media/2020/07/0kkR624601.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('754', '308', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail15955549900kkR624601.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('755', '308', 'MEDIUM', '400', '400', 'images/media/2020/07/medium15955549900kkR624601.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('756', '308', 'LARGE', '900', '900', 'images/media/2020/07/large15955549900kkR624601.jpg', '', '2020-07-24 01:43:10');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('757', '309', 'ACTUAL', '640', '640', 'images/media/2020/07/Qmcve24401.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('758', '309', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595555155Qmcve24401.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('759', '309', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595555155Qmcve24401.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('760', '310', 'ACTUAL', '600', '600', 'images/media/2020/07/raHcA24501.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('761', '310', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595555264raHcA24501.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('762', '310', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595555264raHcA24501.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('763', '311', 'ACTUAL', '600', '799', 'images/media/2020/07/QTuKC24801.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('764', '311', 'THUMBNAIL', '113', '150', 'images/media/2020/07/thumbnail1595555338QTuKC24801.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('765', '311', 'MEDIUM', '300', '400', 'images/media/2020/07/medium1595555338QTuKC24801.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('766', '312', 'ACTUAL', '466', '700', 'images/media/2020/07/ilTh724401.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('767', '312', 'THUMBNAIL', '100', '150', 'images/media/2020/07/thumbnail1595555919ilTh724401.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('768', '312', 'MEDIUM', '266', '400', 'images/media/2020/07/medium1595555919ilTh724401.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('769', '313', 'ACTUAL', '600', '600', 'images/media/2020/07/Dbj1n24301.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('770', '313', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595555993Dbj1n24301.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('771', '313', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595555993Dbj1n24301.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('772', '314', 'ACTUAL', '800', '800', 'images/media/2020/07/mkS7Z24402.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('773', '314', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595556156mkS7Z24402.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('774', '314', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595556156mkS7Z24402.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('775', '315', 'ACTUAL', '382', '507', 'images/media/2020/07/oUAfC24202.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('776', '315', 'THUMBNAIL', '113', '150', 'images/media/2020/07/thumbnail1595556265oUAfC24202.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('777', '315', 'MEDIUM', '301', '400', 'images/media/2020/07/medium1595556265oUAfC24202.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('778', '316', 'ACTUAL', '700', '700', 'images/media/2020/07/FzEMk24402.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('779', '316', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595556536FzEMk24402.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('780', '316', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595556536FzEMk24402.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('781', '317', 'ACTUAL', '721', '722', 'images/media/2020/07/rtSf124902.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('782', '317', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595556611rtSf124902.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('783', '317', 'MEDIUM', '399', '400', 'images/media/2020/07/medium1595556611rtSf124902.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('784', '318', 'ACTUAL', '288', '500', 'images/media/2020/07/A8zXa24902.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('785', '318', 'THUMBNAIL', '86', '150', 'images/media/2020/07/thumbnail1595556729A8zXa24902.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('786', '318', 'MEDIUM', '230', '400', 'images/media/2020/07/medium1595556729A8zXa24902.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('787', '319', 'ACTUAL', '489', '800', 'images/media/2020/07/LuRMc24602.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('788', '319', 'THUMBNAIL', '92', '150', 'images/media/2020/07/thumbnail1595556911LuRMc24602.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('789', '319', 'MEDIUM', '245', '400', 'images/media/2020/07/medium1595556911LuRMc24602.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('790', '320', 'ACTUAL', '352', '582', 'images/media/2020/07/HOF3k24802.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('791', '320', 'THUMBNAIL', '91', '150', 'images/media/2020/07/thumbnail1595556969HOF3k24802.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('792', '320', 'MEDIUM', '242', '400', 'images/media/2020/07/medium1595556969HOF3k24802.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('793', '321', 'ACTUAL', '600', '600', 'images/media/2020/07/cHJrS24102.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('794', '321', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595556971cHJrS24102.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('795', '321', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595556971cHJrS24102.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('796', '322', 'ACTUAL', '785', '600', 'images/media/2020/07/MELdt24302.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('797', '322', 'THUMBNAIL', '150', '115', 'images/media/2020/07/thumbnail1595557082MELdt24302.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('798', '322', 'MEDIUM', '400', '306', 'images/media/2020/07/medium1595557082MELdt24302.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('799', '323', 'ACTUAL', '600', '600', 'images/media/2020/07/C2vIE24707.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('800', '323', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595574431C2vIE24707.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('801', '323', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595574431C2vIE24707.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('802', '324', 'ACTUAL', '164', '308', 'images/media/2020/07/IJqRi24207.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('803', '324', 'THUMBNAIL', '80', '150', 'images/media/2020/07/thumbnail1595574479IJqRi24207.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('804', '325', 'ACTUAL', '600', '600', 'images/media/2020/07/NtQrk24307.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('805', '325', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595574537NtQrk24307.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('806', '325', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595574537NtQrk24307.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('807', '326', 'ACTUAL', '600', '600', 'images/media/2020/07/2Vy3I24407.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('808', '326', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail15955748112Vy3I24407.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('809', '326', 'MEDIUM', '400', '400', 'images/media/2020/07/medium15955748112Vy3I24407.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('810', '327', 'ACTUAL', '548', '800', 'images/media/2020/07/8CVJZ24407.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('811', '327', 'THUMBNAIL', '103', '150', 'images/media/2020/07/thumbnail15955748678CVJZ24407.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('812', '328', 'ACTUAL', '600', '600', 'images/media/2020/07/mHQJv24207.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('813', '328', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595574867mHQJv24207.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('814', '327', 'MEDIUM', '274', '400', 'images/media/2020/07/medium15955748678CVJZ24407.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('815', '328', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595574867mHQJv24207.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('816', '329', 'ACTUAL', '600', '600', 'images/media/2020/07/M5sXC24907.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('817', '329', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595575082M5sXC24907.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('818', '329', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595575082M5sXC24907.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('819', '330', 'ACTUAL', '600', '600', 'images/media/2020/07/CSkDj24707.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('820', '330', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595575174CSkDj24707.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('821', '330', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595575174CSkDj24707.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('822', '331', 'ACTUAL', '600', '600', 'images/media/2020/07/8upkL24807.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('823', '331', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail15955751828upkL24807.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('824', '331', 'MEDIUM', '400', '400', 'images/media/2020/07/medium15955751828upkL24807.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('825', '332', 'ACTUAL', '600', '600', 'images/media/2020/07/EpCKm24507.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('826', '332', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595575183EpCKm24507.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('827', '332', 'MEDIUM', '400', '400', 'images/media/2020/07/medium1595575183EpCKm24507.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('828', '333', 'ACTUAL', '554', '553', 'images/media/2020/07/jmkAP24307.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('829', '333', 'THUMBNAIL', '150', '150', 'images/media/2020/07/thumbnail1595575326jmkAP24307.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('830', '333', 'MEDIUM', '400', '399', 'images/media/2020/07/medium1595575326jmkAP24307.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('831', '334', 'ACTUAL', '240', '304', 'images/media/2020/07/k5no324102.jpeg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('832', '334', 'THUMBNAIL', '118', '150', 'images/media/2020/07/thumbnail1595600567k5no324102.jpeg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('833', '335', 'ACTUAL', '421', '1600', 'images/media/2020/08/0BK6227611.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('834', '335', 'THUMBNAIL', '39', '150', 'images/media/2020/08/thumbnail15985263090BK6227611.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('835', '335', 'MEDIUM', '105', '400', 'images/media/2020/08/medium15985263090BK6227611.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('836', '335', 'LARGE', '237', '900', 'images/media/2020/08/large15985263090BK6227611.png', '', '2020-08-27 11:05:09');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('837', '336', 'ACTUAL', '516', '900', 'images/media/2020/09/ypy4B07707.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('838', '336', 'THUMBNAIL', '86', '150', 'images/media/2020/09/thumbnail1599464913ypy4B07707.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('839', '336', 'MEDIUM', '229', '400', 'images/media/2020/09/medium1599464913ypy4B07707.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('840', '336', 'LARGE', '516', '900', 'images/media/2020/09/large1599464913ypy4B07707.jpg', '', '2020-09-07 07:48:33');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('841', '337', 'ACTUAL', '230', '370', 'images/media/2020/09/gLdhb14707.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('842', '337', 'THUMBNAIL', '93', '150', 'images/media/2020/09/thumbnail1600067569gLdhb14707.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('843', '338', 'ACTUAL', '230', '370', 'images/media/2020/09/BkB4N14707.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('844', '338', 'THUMBNAIL', '93', '150', 'images/media/2020/09/thumbnail1600068638BkB4N14707.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('845', '339', 'ACTUAL', '230', '370', 'images/media/2020/09/ljsuC14307.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('846', '339', 'THUMBNAIL', '93', '150', 'images/media/2020/09/thumbnail1600068641ljsuC14307.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('847', '340', 'ACTUAL', '230', '370', 'images/media/2020/09/r1IQQ14707.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('848', '340', 'THUMBNAIL', '93', '150', 'images/media/2020/09/thumbnail1600068645r1IQQ14707.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('849', '341', 'ACTUAL', '230', '370', 'images/media/2020/09/9lPw914209.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('850', '341', 'THUMBNAIL', '93', '150', 'images/media/2020/09/thumbnail16000747549lPw914209.png', '', '');


TRUNCATE images; INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('3', 'XUF1110211.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('4', '0S9Uj10711.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('5', '49YbL10411.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('83', 'JqYfZ11207.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('84', '6Q4Qy11507.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('85', 'jOVnc11207.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('86', 'Ake4A11107.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('89', 'nDQtA11407.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('90', 'ueyod11407.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('91', 'xD6MF11207.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('92', 'YZyoU11507.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('93', 'RLshK11309.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('94', 'pTZdI11309.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('95', '2t7BU11909.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('96', 'O0cLp11909.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('97', 'ncXhn11709.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('98', '3876V11310.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('99', '80IGj11510.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('100', 'ueeqM11410.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('101', 'UrgVW11410.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('102', 'a18kN11510.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('103', 'qQM0R11310.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('104', 'VrhhT11510.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('105', 'gSkR011310.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('106', 'DXoxt11610.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('107', 'N4WSZ11310.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('108', 'z9MLR11610.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('109', 'YNVyV11410.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('110', 'YinE411810.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('111', '97VNC11210.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('114', 'zZZ2n11710.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('115', 'vMNsa11710.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('116', 'qujIz11610.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('118', 'PJG0C11511.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('119', 'SKOMJ11512.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('120', 'newsletter.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('121', 'RhCsh20105.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('122', 'VRPoJ20105.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('123', 'FQrzt20605.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('124', 'KkzHg20705.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('125', 'H7dnV20905.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('126', 'GHcz420405.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('127', '1wxrC20705.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('128', 'Onm1R20705.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('129', 'dtoGy20805.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('130', 'JX9AD20105.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('131', 'ewGO120605.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('132', 'NdPna20505.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('133', 'D7wSD20105.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('134', 'n55cl20805.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('135', 'AA7k520605.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('136', 'NOO0i20305.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('137', '5tQWQ20105.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('138', 'hQZdF20905.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('139', '1UYHj20905.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('140', 'TzZFS20205.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('141', 'HXaPn20305.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('142', 'hIsS820805.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('143', 'wBece20805.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('144', 'gNoJs20205.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('145', '6svCC20405.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('146', 'Zo9NW20405.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('147', 'BmKll20305.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('148', '2ljt220805.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('149', '6VhYU20605.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('150', 'pegC720105.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('151', 'OPH7P20905.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('152', 'FWJOF20605.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('153', 'EC3BR20705.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('154', 'HsfVS20405.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('155', 'TX3GN20805.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('156', '2jwG820505.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('157', 'CQjTW20105.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('158', 'x2wzK20105.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('159', '9NAY520105.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('160', 'EUKHc20105.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('161', 'HUqXZ20905.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('162', 'EH7iD20105.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('163', 'SCpas20605.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('164', 'hHci420805.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('165', 'kMHBL20105.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('166', 'JaSX220305.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('167', 'DvD9Y20505.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('168', 'dvb2E20205.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('169', 'KlTwk20305.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('170', 'kxpB920305.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('171', 'xsLss20905.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('172', 'Wi5kr20105.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('173', 'ILRpF20105.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('174', 'OiGgP20105.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('175', 'emJyU20305.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('176', 'ZBvp620805.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('177', '3hUzT20605.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('178', 'v6dhb20405.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('179', 'Wde0g20805.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('180', 'hzHK320105.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('181', 'K4KTH20405.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('182', '8g0lC20905.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('183', 'OhfXC20505.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('184', '0HAwo20305.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('185', '1UCWk20905.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('186', 'XiEpV20805.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('187', 'EA3Gm20905.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('188', 'AyAyq20105.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('189', 'JzMkU20205.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('190', '9789Q20505.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('191', 'NwNFe20905.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('192', 'hWmJ020205.jpeg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('193', 'I1Wt120805.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('194', 'PFbtA20605.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('195', 'eqiJq20505.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('196', 'YvW3W20105.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('197', 'yOaAu20505.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('198', 'u8oe020505.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('199', 'mfMAL20905.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('200', 'uTNlg20505.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('201', 's0Nto20505.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('202', 'eJ6M720205.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('203', 'toNBD20705.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('204', 'tDBKt20405.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('205', '0Pxjv20306.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('206', 'XbMwF20706.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('207', 'cB2E020706.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('208', '8esqh20106.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('209', '10LIR20606.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('210', 'W5inB20406.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('211', 'VQdfH20606.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('212', 'GXClG20406.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('213', 'IoTgM20506.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('214', 'IQ1SU20606.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('215', 'xbdz120806.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('216', 'nfk7g20606.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('217', 'ZSC9x20406.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('218', 'x8NwB20806.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('219', 'td04I20106.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('220', '4PiF820706.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('221', 'WVq8G20806.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('222', 'EgfBD20506.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('223', 'kBLNv20806.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('224', 'xQMD620606.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('225', 'TANkU20506.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('226', 'JVuPT20406.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('227', 't8Nsy20706.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('228', 'vi4fg20406.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('229', '2pJv920606.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('230', 'y3KOy20406.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('231', 'sPQyG20506.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('232', 'YwmTW20706.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('233', 'RrKk420106.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('234', 'F13oy20506.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('235', 'bMTMA20306.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('236', '36Gg220406.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('237', 'sGyRZ20106.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('238', 'jl01M20806.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('239', 'urR2I20706.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('240', 'zWEz320206.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('241', 'LWb5920206.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('242', 'm9JdC20606.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('243', 'SAyKo20706.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('244', 'cNyR720706.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('245', 'CpCLN20506.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('246', 'tzJGu20506.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('247', 'nI0dQ20906.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('248', 'oxhaU20406.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('249', 'niLHL20806.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('250', 'PFPfh20706.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('251', 'OKBZy20106.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('252', '74uNe20206.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('253', 'MbYqn20306.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('254', 'Imavp20206.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('255', 'uxqXH20206.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('256', 'vgzXZ20806.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('257', 'a3C1u20306.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('258', 'xNRv420506.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('259', 'OUwz120306.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('260', 'PImij20706.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('261', 'i53qt20506.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('262', 'ZeYB720306.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('263', 'lBJA320106.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('264', '51nWY20206.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('265', 'BVWoe20206.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('266', 'paNK420606.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('267', 'XYv9f20206.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('268', 'L3R3F20106.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('269', 'C0Kqs20606.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('271', 'oDGvd20407.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('272', 'wLCTW20607.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('274', 'Q4TpM20607.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('275', 'jJE8U20307.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('276', 'FroMu20907.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('277', '2mDFY20807.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('278', 'ZuGI821403.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('279', '8DuYo22704.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('280', 'SCe7t22904.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('281', 'nRyJs22904.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('282', '6Hk5N22204.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('283', '4IhlA22905.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('284', '5jCJv22605.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('285', 'NboYg22406.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('287', 'z5u6D22206.jpeg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('288', 'tu0s824701.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('289', 'OgLFb24101.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('290', 'mAuV324401.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('291', 'HEyS124801.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('292', 'jJ8tN24501.jpeg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('293', '7GYVJ24601.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('294', 'XK4tk24401.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('295', 'FquQ624301.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('296', 'OYDGE24101.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('297', 'miSm924201.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('298', 'pM4Fx24701.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('299', 'os4GU24701.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('300', '4JJP024501.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('301', 'spUbC24401.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('302', 'VN3Hw24301.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('303', 'CIjA424501.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('304', 'BCHYs24801.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('305', 'MHRNi24501.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('306', '5ydaL24101.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('307', '6bQFH24901.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('308', '0kkR624601.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('309', 'Qmcve24401.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('310', 'raHcA24501.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('311', 'QTuKC24801.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('312', 'ilTh724401.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('313', 'Dbj1n24301.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('314', 'mkS7Z24402.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('315', 'oUAfC24202.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('316', 'FzEMk24402.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('317', 'rtSf124902.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('318', 'A8zXa24902.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('319', 'LuRMc24602.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('320', 'HOF3k24802.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('321', 'cHJrS24102.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('322', 'MELdt24302.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('323', 'C2vIE24707.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('324', 'IJqRi24207.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('325', 'NtQrk24307.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('326', '2Vy3I24407.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('327', '8CVJZ24407.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('328', 'mHQJv24207.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('329', 'M5sXC24907.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('330', 'CSkDj24707.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('331', '8upkL24807.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('332', 'EpCKm24507.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('333', 'jmkAP24307.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('334', 'k5no324102.jpeg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('335', '0BK6227611.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('336', 'ypy4B07707.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('337', 'gLdhb14707.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('338', 'BkB4N14707.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('339', 'ljsuC14307.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('340', 'r1IQQ14707.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('341', '9lPw914209.png', '1', '', '', '');


TRUNCATE inventory; INSERT INTO inventory (`inventory_ref_id`, `admin_id`, `added_date`, `reference_code`, `stock`, `products_id`, `purchase_price`, `stock_type`, `created_at`, `updated_at`); VALUES ('1', '1', '0', '', '50', '1', '5000.00', 'in', '2020-08-31 04:24:56', '');


INSERT INTO inventory (`inventory_ref_id`, `admin_id`, `added_date`, `reference_code`, `stock`, `products_id`, `purchase_price`, `stock_type`, `created_at`, `updated_at`); VALUES ('2', '0', '1598891278', '', '1', '1', '0.00', 'out', '', '');


INSERT INTO inventory (`inventory_ref_id`, `admin_id`, `added_date`, `reference_code`, `stock`, `products_id`, `purchase_price`, `stock_type`, `created_at`, `updated_at`); VALUES ('3', '1', '0', '', '19', '1', '5000.00', 'in', '2020-08-31 04:33:59', '');


INSERT INTO inventory (`inventory_ref_id`, `admin_id`, `added_date`, `reference_code`, `stock`, `products_id`, `purchase_price`, `stock_type`, `created_at`, `updated_at`); VALUES ('4', '1', '0', '', '1', '1', '0.00', 'in', '2020-08-31 04:40:58', '');


TRUNCATE inventory_detail; TRUNCATE label_value; INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1297', 'Home', '1', '1031');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1298', 'Menu', '1', '1030');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1299', 'Clear', '1', '1029');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1300', 'Apply', '1', '1028');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1301', 'Close', '1', '1027');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1302', 'Price Range', '1', '1026');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1303', 'Filters', '1', '1025');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1304', 'My Wish List', '1', '1024');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1305', 'Log Out', '1', '1023');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1306', 'Please login or create an account for free', '1', '1022');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1307', 'login & Register', '1', '1021');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1308', 'Save Address', '1', '1020');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1309', 'State', '1', '1018');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1310', 'Update Address', '1', '1019');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1311', 'Post code', '1', '1017');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1312', 'City', '1', '1016');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1313', 'Zone', '1', '1015');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1314', 'other', '1', '1014');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1315', 'Country', '1', '1013');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1316', 'Shipping Address', '1', '1012');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1317', 'Proceed', '1', '1011');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1318', 'Remove', '1', '1010');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1319', 'by', '1', '1008');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1320', 'View', '1', '1009');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1321', 'Quantity', '1', '1007');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1322', 'Price', '1', '1006');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1323', 'continue shopping', '1', '1005');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1324', 'Your cart is empty', '1', '1004');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1325', 'My Cart', '1', '1003');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1326', 'Continue', '1', '1002');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1327', 'Error: invalid cvc number!', '1', '1001');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1328', 'Error: invalid expiry date!', '1', '1000');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1329', 'Error: invalid card number!', '1', '999');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1330', 'Expiration', '1', '998');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1331', 'Expiration Date', '1', '997');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1332', 'Card Number', '1', '996');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1333', 'Payment', '1', '995');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1334', 'Order Notes', '1', '994');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1335', 'Shipping Cost', '1', '993');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1336', 'Tax', '1', '992');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1337', 'Products Price', '1', '991');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1338', 'SubTotal', '1', '990');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1339', 'Products', '1', '989');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1340', 'Shipping Method', '1', '988');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1341', 'Billing Address', '1', '987');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1342', 'Order', '1', '986');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1343', 'Next', '1', '985');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1344', 'Same as Shipping Address', '1', '984');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1345', 'Billing Info', '1', '981');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1346', 'Address', '1', '982');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1347', 'Phone', '1', '983');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1348', 'Already Memeber?', '1', '980');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1349', 'Last Name', '1', '979');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1350', 'First Name', '1', '978');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1351', 'Create an Account', '1', '977');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1352', 'Add new Address', '1', '976');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1353', 'Please add your new shipping address for the futher processing of the your order', '1', '975');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1354', 'Order Status', '1', '969');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1355', 'Orders ID', '1', '970');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1356', 'Product Price', '1', '971');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1357', 'No. of Products', '1', '972');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1358', 'Date', '1', '973');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1359', 'Customer Address', '1', '974');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1360', 'Customer Orders', '1', '968');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1361', 'Change Password', '1', '967');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1362', 'New Password', '1', '966');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1363', 'Current Password', '1', '965');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1364', 'Update', '1', '964');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1365', 'Date of Birth', '1', '963');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1366', 'Mobile', '1', '962');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1367', 'My Account', '1', '961');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1368', 'Likes', '1', '960');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1369', 'Newest', '1', '959');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1370', 'Top Seller', '1', '958');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1371', 'Special', '1', '957');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1372', 'Most Liked', '1', '956');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1373', 'Cancel', '1', '955');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1374', 'Sort Products', '1', '954');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1375', 'Special Products', '1', '953');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1376', 'Price : low - high', '1', '952');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1377', 'Price : high - low', '1', '951');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1378', 'Z - A', '1', '950');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1379', 'A - Z', '1', '949');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1380', 'All', '1', '948');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1381', 'Explore More', '1', '947');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1382', 'Note to the buyer', '1', '946');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1383', 'Coupon', '1', '945');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1384', 'coupon code', '1', '944');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1385', 'Coupon Amount', '1', '943');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1386', 'Coupon Code', '1', '942');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1387', 'Food Categories', '1', '941');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1388', 'Recipe of Day', '1', '940');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1389', 'Top Dishes', '1', '939');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1390', 'Skip', '1', '938');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1391', 'Term and Services', '1', '937');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1392', 'Privacy Policy', '1', '936');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1393', 'Refund Policy', '1', '935');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1394', 'Newest', '1', '934');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1395', 'OUT OF STOCK', '1', '933');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1396', 'Select Language', '1', '932');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1397', 'Reset', '1', '931');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1398', 'Shop', '1', '930');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1399', 'Settings', '1', '929');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1400', 'Enter keyword', '1', '928');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1401', 'News', '1', '927');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1402', 'Top Sellers', '1', '926');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1403', 'Go Back', '1', '925');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1404', 'Word Press Post Detail', '1', '924');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1405', 'Explore', '1', '923');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1406', 'Continue Adding', '1', '922');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1407', 'Your wish List is empty', '1', '921');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1408', 'Favourite', '1', '920');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1409', 'Lanjut Berbelanja', '1', '919');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1410', 'Order Saya', '1', '918');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1411', 'Terimakasih Berbelanja di Kami', '1', '917');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1412', 'Terimakasih', '1', '916');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1413', 'Shipping method', '1', '915');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1414', 'Sub Categories', '1', '914');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1415', 'Main Categories', '1', '913');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1416', 'Cari', '1', '912');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1417', 'Reset Filters', '1', '911');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1418', 'No Products Found', '1', '910');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1419', 'OFF', '1', '909');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1420', 'Techincal details', '1', '908');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1421', 'Deskripsi Produk', '1', '907');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1422', 'TAMBAHKAN', '1', '906');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1423', 'Tambahkan', '1', '905');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1424', 'In Stock', '1', '904');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1425', 'stock Kosong', '1', '903');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1426', 'Baru', '1', '902');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1427', 'Product Details', '1', '901');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1428', 'Pengiriman', '1', '900');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1429', 'Sub Total', '1', '899');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1430', 'Total', '1', '898');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1431', 'Detail Harga', '1', '897');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1432', 'Detail Order', '1', '896');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1433', 'Dapatkan!', '1', '895');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1434', 'Skip Intro', '1', '894');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1435', 'Intro', '1', '893');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1436', 'HAPUS', '1', '892');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1437', 'Deals', '1', '891');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1438', 'Semua Kategori', '1', '890');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1439', 'Most Liked', '1', '889');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1440', 'Special Deals', '1', '888');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1441', 'Top Seller', '1', '887');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1442', 'Produk Tersedia', '1', '886');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1443', 'Recently Viewed', '1', '885');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1444', 'Mohon Sambungkan internet Anda', '1', '884');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1445', 'Contact Us', '1', '881');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1446', 'Nama', '1', '882');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1447', 'Pesan Anda', '1', '883');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1448', 'Kategori', '1', '880');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1449', 'Tentang', '1', '879');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1450', 'Kirim', '1', '878');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1451', 'Lupa Password', '1', '877');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1452', 'Daftar', '1', '876');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1453', 'Password', '1', '875');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1454', 'Email', '1', '874');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1455', 'Atau', '1', '873');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1456', 'Masuk Dengan', '1', '872');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1457', 'Creating an account means you\'re okay with shopify\'s Terms of Service, Privacy Policy', '1', '2');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1458', 'Lupa Password ?', '1', '1');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1459', '', '1', '');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1462', 'Creating an account means you’re okay with our', '1', '1033');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1465', 'Login', '1', '1034');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1468', 'Turn on/off Local Notifications', '1', '1035');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1471', 'Turn on/off Notifications', '1', '1036');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1474', 'Change Language', '1', '1037');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1477', 'Official Website', '1', '1038');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1480', 'Rate Us', '1', '1039');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1483', 'Share', '1', '1040');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1486', 'Edit Profile', '1', '1041');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1489', 'A percentage discount for the entire cart', '1', '1042');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1492', 'A fixed total discount for the entire cart', '1', '1043');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1495', 'A fixed total discount for selected products only', '1', '1044');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1498', 'A percentage discount for selected products only', '1', '1045');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1501', 'Network Connected Reloading Data', '1', '1047');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1503', 'Sort by', '1', '1048');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1505', 'Flash Sale', '1', '1049');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1507', 'ok', '1', '1050');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1509', 'Number', '1', '1051');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1511', 'Expire Month', '1', '1052');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1513', 'Expire Year', '1', '1053');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1515', 'Payment Method', '1', '1054');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1517', 'Status', '1', '1055');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1519', 'And', '1', '1056');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1520', 'نسيت كلمة المرور الخاصة بي؟', '4', '1');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1521', 'إن إنشاء حساب يعني موافقتك على شروط الخدمة وسياسة الخصوصية', '4', '2');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1522', 'تسجيل الدخول مع', '4', '872');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1523', 'أو', '4', '873');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1524', 'البريد الإلكتروني', '4', '874');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1525', 'كلمه السر', '4', '875');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1526', 'تسجيل', '4', '876');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1527', 'هل نسيت كلمة المرور', '4', '877');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1528', 'إرسال', '4', '878');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1529', 'معلومات عنا', '4', '879');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1530', 'التصنيفات', '4', '880');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1531', 'اتصل بنا', '4', '881');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1532', 'اسم', '4', '882');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1533', 'رسالتك', '4', '883');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1534', 'يرجى الاتصال بالإنترنت', '4', '884');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1535', 'شوهدت مؤخرا', '4', '885');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1536', 'المنتجات المتاحة.', '4', '886');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1537', 'أعلى بائع', '4', '887');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1538', 'صفقة خاصة', '4', '888');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1539', 'الأكثر إعجابا', '4', '889');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1540', 'جميع الفئات', '4', '890');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1541', 'صفقات', '4', '891');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1542', 'إزالة', '4', '892');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1543', 'مقدمة', '4', '893');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1544', 'تخطي المقدمة', '4', '894');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1545', 'فهمتك!', '4', '895');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1546', 'تفاصيل الطلب', '4', '896');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1547', 'سعر التفاصيل', '4', '897');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1548', 'مجموع', '4', '898');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1549', 'المجموع الفرعي', '4', '899');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1550', 'الشحن', '4', '900');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1551', 'تفاصيل المنتج', '4', '901');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1552', 'جديد', '4', '902');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1553', 'إنتهى من المخزن', '4', '903');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1554', 'في المخزن', '4', '904');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1555', 'أضف إلى السلة', '4', '905');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1556', 'أضف إلى السلة', '4', '906');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1557', 'وصف المنتج', '4', '907');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1558', 'تفاصيل تقنية', '4', '908');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1559', 'إيقاف', '4', '909');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1560', 'لا توجد منتجات', '4', '910');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1561', 'إعادة تعيين المرشحات', '4', '911');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1562', 'بحث', '4', '912');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1563', 'الفئات الرئيسية', '4', '913');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1564', 'الفئات الفرعية', '4', '914');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1565', 'طريقة الشحن', '4', '915');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1566', 'شكرا جزيلا', '4', '916');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1567', 'شكرا للتسوق معنا.', '4', '917');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1568', 'طلباتي', '4', '918');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1569', 'مواصلة التسوق', '4', '919');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1570', '', '4', '');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1571', 'مفضل', '4', '920');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1572', 'قائمة رغباتك فارغة', '4', '921');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1573', 'متابعة الإضافة', '4', '922');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1574', 'يكتشف', '4', '923');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1575', 'وورد بوست التفاصيل', '4', '924');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1576', 'عد', '4', '925');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1577', 'أفضل البائعين', '4', '926');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1578', 'أخبار', '4', '927');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1579', 'أدخل الكلمة المفتاحية', '4', '928');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1580', 'الإعدادات', '4', '929');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1581', 'متجر', '4', '930');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1582', 'إعادة تعيين', '4', '931');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1583', 'اختار اللغة', '4', '932');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1584', 'إنتهى من المخزن', '4', '933');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1585', 'الأحدث', '4', '934');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1586', 'سياسة الاسترجاع', '4', '935');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1587', 'سياسة خاصة', '4', '936');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1588', 'مصطلح والخدمات', '4', '937');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1589', 'تخطى', '4', '938');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1590', 'أطباق الأعلى', '4', '939');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1591', 'وصفة اليوم', '4', '940');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1592', 'فئات الغذاء', '4', '941');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1593', 'رمز الكوبون', '4', '942');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1594', 'مبلغ القسيمة', '4', '943');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1595', 'رمز الكوبون', '4', '944');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1596', 'كوبون', '4', '945');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1597', 'ملاحظة للمشتري', '4', '946');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1598', 'استكشاف المزيد', '4', '947');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1599', 'الكل', '4', '948');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1600', 'أ - ي', '4', '949');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1601', 'ي - أ', '4', '950');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1602', 'السعر مرتفع منخفض', '4', '951');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1603', 'سعر منخفض مرتفع', '4', '952');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1604', 'المنتجات الخاصة', '4', '953');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1605', 'فرز المنتجات', '4', '954');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1606', 'إلغاء', '4', '955');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1607', 'الأكثر إعجابا', '4', '956');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1608', 'خاص', '4', '957');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1609', 'أعلى بائع', '4', '958');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1610', 'الأحدث', '4', '959');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1611', 'الإعجابات', '4', '960');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1612', 'حسابي', '4', '961');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1613', 'التليفون المحمول', '4', '962');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1614', 'تاريخ الولادة', '4', '963');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1615', 'تحديث', '4', '964');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1616', 'كلمة المرور الحالية', '4', '965');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1617', 'كلمة سر جديدة', '4', '966');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1618', 'تغيير كلمة المرور', '4', '967');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1619', 'طلبات العملاء', '4', '968');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1620', 'حالة الطلب', '4', '969');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1621', 'معرف الطلبات', '4', '970');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1622', 'سعر المنتج', '4', '971');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1623', 'عدد المنتجات', '4', '972');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1624', 'تاريخ', '4', '973');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1625', 'عنوان العميل', '4', '974');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1626', 'يرجى إضافة عنوان الشحن الجديد لمزيد من المعالجة لطلبك', '4', '975');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1627', 'إضافة عنوان جديد', '4', '976');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1628', 'انشئ حساب', '4', '977');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1629', 'الاسم الاول', '4', '978');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1630', 'الكنية', '4', '979');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1631', 'هل أنت عضو بالفعل؟', '4', '980');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1632', 'معلومات الفواتير', '4', '981');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1633', 'عنوان', '4', '982');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1634', 'هاتف', '4', '983');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1635', 'نفس عنوان الشحن', '4', '984');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1636', 'التالى', '4', '985');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1637', 'طلب', '4', '986');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1638', 'عنوان وصول الفواتير', '4', '987');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1639', 'طريقة الشحن', '4', '988');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1640', 'منتجات', '4', '989');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1641', 'حاصل الجمع', '4', '990');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1642', 'سعر المنتجات', '4', '991');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1643', 'ضريبة', '4', '992');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1644', 'تكلفة الشحن', '4', '993');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1645', 'ترتيب ملاحظات', '4', '994');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1646', 'دفع', '4', '995');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1647', 'رقم البطاقة', '4', '996');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1648', 'تاريخ الإنتهاء', '4', '997');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1649', 'انتهاء الصلاحية', '4', '998');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1650', 'خطأ: رقم البطاقة غير صالح!', '4', '999');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1651', 'خطأ: تاريخ انتهاء الصلاحية غير صحيح!', '4', '1000');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1652', 'خطأ: رقم cvc غير صالح!', '4', '1001');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1653', 'استمر', '4', '1002');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1654', 'سلتي', '4', '1003');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1655', 'عربة التسوق فارغة', '4', '1004');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1656', 'مواصلة التسوق', '4', '1005');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1657', 'السعر', '4', '1006');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1658', 'كمية', '4', '1007');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1659', 'بواسطة', '4', '1008');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1660', 'رأي', '4', '1009');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1661', 'إزالة', '4', '1010');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1662', 'تقدم', '4', '1011');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1663', 'عنوان الشحن', '4', '1012');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1664', 'بلد', '4', '1013');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1665', 'آخر', '4', '1014');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1666', 'منطقة', '4', '1015');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1667', 'مدينة', '4', '1016');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1668', 'الرمز البريدي', '4', '1017');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1669', 'حالة', '4', '1018');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1670', 'تحديث العنوان', '4', '1019');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1671', 'حفظ العنوان', '4', '1020');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1672', 'دخولتسجيل', '4', '1021');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1673', 'يرجى تسجيل الدخول أو إنشاء حساب مجانا', '4', '1022');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1674', 'تسجيل خروج', '4', '1023');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1675', 'قائمة امنياتي', '4', '1024');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1676', 'مرشحات', '4', '1025');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1677', 'نطاق السعر', '4', '1026');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1678', 'قريب', '4', '1027');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1679', 'تطبيق', '4', '1028');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1680', 'واضح', '4', '1029');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1681', 'قائمة طعام', '4', '1030');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1682', 'الصفحة الرئيسية', '4', '1031');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1683', 'إن إنشاء حساب يعني أنك بخير من خلال موقعنا', '4', '1033');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1684', 'تسجيل الدخول', '4', '1034');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1685', 'تشغيل / إيقاف الإشعارات', '4', '1035');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1686', 'تشغيل / إيقاف الإشعارات', '4', '1036');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1687', 'تغيير اللغة', '4', '1037');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1688', 'الموقع الرسمي', '4', '1038');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1689', 'قيمنا', '4', '1039');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1690', 'شارك', '4', '1040');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1691', 'تعديل الملف الشخصي', '4', '1041');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1692', 'خصم النسبة المئوية للسلة بأكملها', '4', '1042');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1693', 'خصم إجمالي ثابت للعربة بأكملها', '4', '1043');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1694', 'خصم إجمالي ثابت للمنتجات المحددة فقط', '4', '1044');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1695', 'خصم النسبة المئوية للمنتجات المختارة فقط', '4', '1045');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1696', 'شبكة متصلة إعادة تحميل البيانات', '4', '1047');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1697', 'صنف حسب', '4', '1048');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1698', 'بيع مفاجئ', '4', '1049');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1699', 'حسنا', '4', '1050');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1700', 'رقم', '4', '1051');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1701', 'انتهاء الشهر', '4', '1052');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1702', 'انتهاء السنة', '4', '1053');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1703', 'طريقة الدفع او السداد', '4', '1054');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1704', 'الحالة', '4', '1055');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1705', 'و', '4', '1056');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1706', 'cccc', '1', '1057');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1707', 'cccc', '4', '1057');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1708', 'Shop More', '1', '1058');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1709', 'عربي', '4', '1058');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1710', 'Discount', '1', '1072');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1711', 'خصم', '4', '1072');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1712', 'Error in initialization, maybe PayPal isnt supported or something else', '1', '1073');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1713', 'خطأ في التهيئة ، ربما لا يتم دعم PayPal أو أي شيء آخر', '4', '1073');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1714', 'Alert', '1', '1074');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1715', 'إنذار', '4', '1074');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1716', 'Your Wishlist is Empty', '1', '1075');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1717', 'قائمة رغباتك فارغة', '4', '1075');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1718', 'Press heart icon on products to add them in wishlist', '1', '1076');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1719', 'اضغط على أيقونة القلب على المنتجات لإضافتها إلى قائمة الرغبات', '4', '1076');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1720', 'Wishlist', '1', '1077');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1721', 'قائمة الرغبات', '4', '1077');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1722', 'All Items', '1', '1078');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1723', 'كل الاشياء', '4', '1078');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1724', 'Account Info', '1', '1079');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1725', 'معلومات الحساب', '4', '1079');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1726', 'You Must Be Logged in to use this Feature!', '1', '1080');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1727', 'يجب عليك تسجيل الدخول لاستخدام هذه الميزة!', '4', '1080');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1728', 'Remove from Wishlist', '1', '1081');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1729', 'إزالة من قائمة الرغبات', '4', '1081');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1730', 'Sign Up', '1', '1082');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1731', 'سجل', '4', '1082');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1732', 'Reset Password', '1', '1083');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1733', 'إعادة تعيين كلمة المرور', '4', '1083');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1734', 'Invalid email or password', '1', '1084');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1735', 'البريد الإلكتروني أو كلمة السر خاطئة', '4', '1084');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1736', 'Recent Searches', '1', '1085');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1737', 'عمليات البحث الأخيرة', '4', '1085');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1738', 'Add to Wishlist', '1', '1086');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1739', 'أضف إلى قائمة الامنيات', '4', '1086');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1740', 'Discover Latest Trends', '1', '1087');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1741', 'اكتشف أحدث الاتجاهات', '4', '1087');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1742', 'Add To My Wishlist', '1', '1088');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1743', 'أضف إلى قائمة أمنياتي', '4', '1088');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1744', 'Start Shoping', '1', '1089');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1745', 'ابدأ التسوق', '4', '1089');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1746', 'A Smart Shopping Experience', '1', '1090');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1747', 'تجربة تسوق ذكية', '4', '1090');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1748', 'Addresses', '1', '1091');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1749', 'عناوين', '4', '1091');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1750', 'Account', '1', '1092');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1751', 'الحساب', '4', '1092');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1752', 'DETAILS', '1', '1093');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1753', 'تفاصيل', '4', '1093');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1754', 'Dark Mode', '1', '1094');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1755', 'الوضع الداكن', '4', '1094');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1756', 'Enter a description', '1', '1095');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1757', 'أدخل وصفًا', '4', '1095');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1758', 'Grocery Store', '1', '1096');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1759', 'بقالة', '4', '1096');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1760', 'Post Comment', '1', '1097');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1761', 'أضف تعليقا', '4', '1097');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1762', 'Rate and write a review', '1', '1098');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1763', 'تقييم وكتابة مراجعة', '4', '1098');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1764', 'Ratings & Reviews', '1', '1099');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1765', 'التقييمات والمراجعات', '4', '1099');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1766', 'Write a review', '1', '1100');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1767', 'أكتب مراجعة', '4', '1100');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1768', 'Your Rating', '1', '1101');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1769', 'تقييمك', '4', '1101');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1770', 'rating', '1', '1102');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1771', 'تقييم', '4', '1102');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1772', 'rating and review', '1', '1103');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1773', 'تصنيف ومراجعة', '4', '1103');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1774', 'Coupon Codes List', '1', '1104');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1775', 'قائمة رموز القسيمة', '4', '1104');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1776', 'Custom Orders', '1', '1105');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1777', 'أوامر مخصصة', '4', '1105');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1778', 'Ecommerce', '1', '1106');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1779', 'التجارة الإلكترونية', '4', '1106');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1780', 'Featured Products', '1', '1107');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1781', 'منتجات مميزة', '4', '1107');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1782', 'House Hold 1', '1', '1108');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1783', 'المنزل عقد 1', '4', '1108');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1784', 'Newest Products', '1', '1109');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1785', 'أحدث المنتجات', '4', '1109');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1786', 'On Sale Products', '1', '1110');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1787', 'المنتجات المعروضة للبيع', '4', '1110');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1788', 'Braintree', '1', '1111');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1789', 'برينتري', '4', '1111');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1790', 'Hyperpay', '1', '1112');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1791', 'Hyperpay', '4', '1112');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1792', 'Instamojo', '1', '1113');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1793', 'Instamojo', '4', '1113');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1794', 'PayTm', '1', '1114');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1795', 'PayTm', '4', '1114');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1796', 'Paypal', '1', '1115');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1797', 'باي بال', '4', '1115');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1798', 'Razor Pay', '1', '1116');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1799', 'الحلاقة الدفع', '4', '1116');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1800', 'Stripe', '1', '1117');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1801', 'شريط', '4', '1117');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1802', 'Me', '1', '1059');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1803', 'أنا', '4', '1059');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1804', 'View All', '1', '1060');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1805', 'عرض الكل', '4', '1060');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1806', 'Featured', '1', '1061');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1807', 'متميز', '4', '1061');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1808', 'Shop Now', '1', '1062');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1809', 'تسوق الآن', '4', '1062');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1810', 'New Arrivals', '1', '1063');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1811', 'الوافدون الجدد', '4', '1063');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1812', 'Sort', '1', '1064');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1813', 'فرز', '4', '1064');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1814', 'Help & Support', '1', '1065');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1815', 'ساعد لدعم', '4', '1065');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1816', 'Select Currency', '1', '1066');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1817', 'اختر العملة', '4', '1066');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1818', 'Your Price', '1', '1067');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1819', 'السعر الخاص', '4', '1067');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1820', 'Billing', '1', '1068');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1821', 'الفواتير', '4', '1068');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1822', 'Ship to a different address?', '1', '1069');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1823', 'هل تريد الشحن إلى عنوان مختلف؟', '4', '1069');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1824', 'Method', '1', '1070');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1825', 'طريقة', '4', '1070');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1826', 'Summary', '1', '1071');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1827', 'ملخص', '4', '1071');


TRUNCATE labels; INSERT INTO labels (`label_id`, `label_name`); VALUES ('1', 'I\'ve forgotten my password?');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('2', 'Creating an account means you’re okay with shopify\'s Terms of Service, Privacy Policy');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('872', 'Login with');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('873', 'or');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('874', 'Email');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('875', 'Password');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('876', 'Register');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('877', 'Forgot Password');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('878', 'Send');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('879', 'About Us');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('880', 'Categories');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('881', 'Contact Us');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('882', 'Name');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('883', 'Your Messsage');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('884', 'Please connect to the internet');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('885', 'Recently Viewed');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('886', 'Products are available.');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('887', 'Top Seller');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('888', 'Special Deals');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('889', 'Most Liked');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('890', 'All Categories');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('891', 'Deals');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('892', 'REMOVE');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('893', 'Intro');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('894', 'Skip Intro');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('895', 'Got It!');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('896', 'Order Detail');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('897', 'Price Detail');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('898', 'Total');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('899', 'Sub Total');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('900', 'Shipping');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('901', 'Product Details');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('902', 'New');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('903', 'Out of Stock');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('904', 'In Stock');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('905', 'Add to Cart');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('906', 'ADD TO CART');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('907', 'Product Description');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('908', 'Techincal details');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('909', 'OFF');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('910', 'No Products Found');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('911', 'Reset Filters');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('912', 'Search');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('913', 'Main Categories');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('914', 'Sub Categories');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('915', 'Shipping method');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('916', 'Thank You');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('917', 'Thank you for shopping with us.');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('918', 'My Orders');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('919', 'Continue Shopping');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('920', 'Favourite');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('921', 'Your wish List is empty');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('922', 'Continue Adding');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('923', 'Explore');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('924', 'Word Press Post Detail');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('925', 'Go Back');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('926', 'Top Sellers');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('927', 'News');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('928', 'Enter keyword');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('929', 'Settings');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('930', 'Shop');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('931', 'Reset');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('932', 'Select Language');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('933', 'OUT OF STOCK');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('934', 'Newest');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('935', 'Refund Policy');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('936', 'Privacy Policy');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('937', 'Term and Services');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('938', 'Skip');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('939', 'Top Dishes');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('940', 'Recipe of Day');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('941', 'Food Categories');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('942', 'Coupon Code');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('943', 'Coupon Amount');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('944', 'coupon code');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('945', 'Coupon');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('946', 'Note to the buyer');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('947', 'Explore More');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('948', 'All');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('949', 'A - Z');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('950', 'Z - A');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('951', 'Price : high - low');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('952', 'Price : low - high');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('953', 'Special Products');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('954', 'Sort Products');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('955', 'Cancel');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('956', 'most liked');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('957', 'special');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('958', 'top seller');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('959', 'newest');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('960', 'Likes');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('961', 'My Account');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('962', 'Mobile');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('963', 'Date of Birth');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('964', 'Update');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('965', 'Current Password');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('966', 'New Password');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('967', 'Change Password');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('968', 'Customer Orders');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('969', 'Order Status');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('970', 'Orders ID');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('971', 'Product Price');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('972', 'No. of Products');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('973', 'Date');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('974', 'Customer Address');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('975', 'Please add your new shipping address for the futher processing of the your order');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('976', 'Add new Address');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('977', 'Create an Account');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('978', 'First Name');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('979', 'Last Name');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('980', 'Already Memeber?');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('981', 'Billing Info');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('982', 'Address');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('983', 'Phone');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('984', 'Same as Shipping Address');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('985', 'Next');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('986', 'Order');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('987', 'Billing Address');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('988', 'Shipping Method');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('989', 'Products');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('990', 'SubTotal');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('991', 'Products Price');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('992', 'Tax');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('993', 'Shipping Cost');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('994', 'Order Notes');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('995', 'Payment');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('996', 'Card Number');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('997', 'Expiration Date');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('998', 'Expiration');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('999', 'Error: invalid card number!');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1000', 'Error: invalid expiry date!');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1001', 'Error: invalid cvc number!');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1002', 'Continue');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1003', 'My Cart');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1004', 'Your cart is empty');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1005', 'continue shopping');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1006', 'Price');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1007', 'Quantity');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1008', 'by');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1009', 'View');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1010', 'Remove');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1011', 'Proceed');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1012', 'Shipping Address');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1013', 'Country');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1014', 'other');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1015', 'Zone');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1016', 'City');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1017', 'Post code');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1018', 'State');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1019', 'Update Address');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1020', 'Save Address');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1021', 'Login & Register');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1022', 'Please login or create an account for free');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1023', 'Log Out');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1024', 'My Wish List');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1025', 'Filters');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1026', 'Price Range');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1027', 'Close');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1028', 'Apply');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1029', 'Clear');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1030', 'Menu');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1031', 'Home');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1033', 'Creating an account means you’re okay with our');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1034', 'Login');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1035', 'Turn on/off Local Notifications');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1036', 'Turn on/off Notifications');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1037', 'Change Language');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1038', 'Official Website');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1039', 'Rate Us');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1040', 'Share');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1041', 'Edit Profile');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1042', 'A percentage discount for the entire cart');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1043', 'A fixed total discount for the entire cart');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1044', 'A fixed total discount for selected products only');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1045', 'A percentage discount for selected products only');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1047', 'Network Connected Reloading Data');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1048', 'Sort by');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1049', 'Flash Sale');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1050', 'ok');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1051', 'Number');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1052', 'Expire Month');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1053', 'Expire Year');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1054', 'Payment Method');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1055', 'Status');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1056', 'And');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1057', 'cccc');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1058', 'Shop More');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1059', 'Me');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1060', 'View All');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1061', 'Featured');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1062', 'Shop Now');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1063', 'New Arrivals');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1064', 'Sort');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1065', 'Help & Support');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1066', 'Select Currency');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1067', 'Your Price');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1068', 'Billing');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1069', 'Ship to a different address?');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1070', 'Method');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1071', 'Summary');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1072', 'Discount');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1073', 'Error in initialization, maybe PayPal isnt supported or something else');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1074', 'Alert');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1075', 'Your Wishlist is Empty');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1076', 'Press heart icon on products to add them in wishlist');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1077', 'Wishlist');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1078', 'All Items');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1079', 'Account Info');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1080', 'You Must Be Logged in to use this Feature!');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1081', 'Remove from Wishlist');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1082', 'Sign Up');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1083', 'Reset Password');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1084', 'Invalid email or password');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1085', 'Recent Searches');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1086', 'Add to Wishlist');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1087', 'Discover Latest Trends');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1088', 'Add To My Wishlist');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1089', 'Start Shoping');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1090', 'A Smart Shopping Experience');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1091', 'Addresses');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1092', 'Account');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1093', 'DETAILS');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1094', 'Dark Mode');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1095', 'Enter a description');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1096', 'Grocery Store');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1097', 'Post Comment');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1098', 'Rate and write a review');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1099', 'Ratings & Reviews');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1100', 'Write a review');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1101', 'Your Rating');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1102', 'rating');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1103', 'rating and review');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1104', 'Coupon Codes List');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1105', 'Custom Orders');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1106', 'Ecommerce');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1107', 'Featured Products');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1108', 'House Hold 1');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1109', 'Newest Products');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1110', 'On Sale Products');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1111', 'Braintree');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1112', 'Hyperpay');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1113', 'Instamojo');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1114', 'PayTm');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1115', 'Paypal');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1116', 'Razor Pay');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1117', 'Stripe');


TRUNCATE languages; INSERT INTO languages (`languages_id`, `name`, `code`, `image`, `directory`, `sort_order`, `direction`, `status`, `is_default`); VALUES ('1', 'English', 'en', '118', '', '1', 'ltr', '1', '1');


TRUNCATE liked_products; TRUNCATE manage_min_max; TRUNCATE manage_role; INSERT INTO manage_role (`manage_role_id`, `user_types_id`, `dashboard_view`, `manufacturer_view`, `manufacturer_create`, `manufacturer_update`, `manufacturer_delete`, `categories_view`, `categories_create`, `categories_update`, `categories_delete`, `products_view`, `products_create`, `products_update`, `products_delete`, `news_view`, `news_create`, `news_update`, `news_delete`, `customers_view`, `customers_create`, `customers_update`, `customers_delete`, `tax_location_view`, `tax_location_create`, `tax_location_update`, `tax_location_delete`, `coupons_view`, `coupons_create`, `coupons_update`, `coupons_delete`, `notifications_view`, `notifications_send`, `orders_view`, `orders_confirm`, `shipping_methods_view`, `shipping_methods_update`, `payment_methods_view`, `payment_methods_update`, `reports_view`, `website_setting_view`, `website_setting_update`, `application_setting_view`, `application_setting_update`, `general_setting_view`, `general_setting_update`, `manage_admins_view`, `manage_admins_create`, `manage_admins_update`, `manage_admins_delete`, `language_view`, `language_create`, `language_update`, `language_delete`, `profile_view`, `profile_update`, `admintype_view`, `admintype_create`, `admintype_update`, `admintype_delete`, `manage_admins_role`, `add_media`, `edit_media`, `view_media`, `delete_media`, `edit_management`, `reviews_view`, `reviews_update`, `deliveryboy_view`, `deliveryboy_create`, `deliveryboy_update`, `deliveryboy_delete`, `finance_view`); VALUES ('1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1');


INSERT INTO manage_role (`manage_role_id`, `user_types_id`, `dashboard_view`, `manufacturer_view`, `manufacturer_create`, `manufacturer_update`, `manufacturer_delete`, `categories_view`, `categories_create`, `categories_update`, `categories_delete`, `products_view`, `products_create`, `products_update`, `products_delete`, `news_view`, `news_create`, `news_update`, `news_delete`, `customers_view`, `customers_create`, `customers_update`, `customers_delete`, `tax_location_view`, `tax_location_create`, `tax_location_update`, `tax_location_delete`, `coupons_view`, `coupons_create`, `coupons_update`, `coupons_delete`, `notifications_view`, `notifications_send`, `orders_view`, `orders_confirm`, `shipping_methods_view`, `shipping_methods_update`, `payment_methods_view`, `payment_methods_update`, `reports_view`, `website_setting_view`, `website_setting_update`, `application_setting_view`, `application_setting_update`, `general_setting_view`, `general_setting_update`, `manage_admins_view`, `manage_admins_create`, `manage_admins_update`, `manage_admins_delete`, `language_view`, `language_create`, `language_update`, `language_delete`, `profile_view`, `profile_update`, `admintype_view`, `admintype_create`, `admintype_update`, `admintype_delete`, `manage_admins_role`, `add_media`, `edit_media`, `view_media`, `delete_media`, `edit_management`, `reviews_view`, `reviews_update`, `deliveryboy_view`, `deliveryboy_create`, `deliveryboy_update`, `deliveryboy_delete`, `finance_view`); VALUES ('2', '11', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1');


INSERT INTO manage_role (`manage_role_id`, `user_types_id`, `dashboard_view`, `manufacturer_view`, `manufacturer_create`, `manufacturer_update`, `manufacturer_delete`, `categories_view`, `categories_create`, `categories_update`, `categories_delete`, `products_view`, `products_create`, `products_update`, `products_delete`, `news_view`, `news_create`, `news_update`, `news_delete`, `customers_view`, `customers_create`, `customers_update`, `customers_delete`, `tax_location_view`, `tax_location_create`, `tax_location_update`, `tax_location_delete`, `coupons_view`, `coupons_create`, `coupons_update`, `coupons_delete`, `notifications_view`, `notifications_send`, `orders_view`, `orders_confirm`, `shipping_methods_view`, `shipping_methods_update`, `payment_methods_view`, `payment_methods_update`, `reports_view`, `website_setting_view`, `website_setting_update`, `application_setting_view`, `application_setting_update`, `general_setting_view`, `general_setting_update`, `manage_admins_view`, `manage_admins_create`, `manage_admins_update`, `manage_admins_delete`, `language_view`, `language_create`, `language_update`, `language_delete`, `profile_view`, `profile_update`, `admintype_view`, `admintype_create`, `admintype_update`, `admintype_delete`, `manage_admins_role`, `add_media`, `edit_media`, `view_media`, `delete_media`, `edit_management`, `reviews_view`, `reviews_update`, `deliveryboy_view`, `deliveryboy_create`, `deliveryboy_update`, `deliveryboy_delete`, `finance_view`); VALUES ('3', '12', '0', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '0', '0', '0', '0', '1', '1', '1', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '1', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '1', '1', '1', '1', '1', '1');


INSERT INTO manage_role (`manage_role_id`, `user_types_id`, `dashboard_view`, `manufacturer_view`, `manufacturer_create`, `manufacturer_update`, `manufacturer_delete`, `categories_view`, `categories_create`, `categories_update`, `categories_delete`, `products_view`, `products_create`, `products_update`, `products_delete`, `news_view`, `news_create`, `news_update`, `news_delete`, `customers_view`, `customers_create`, `customers_update`, `customers_delete`, `tax_location_view`, `tax_location_create`, `tax_location_update`, `tax_location_delete`, `coupons_view`, `coupons_create`, `coupons_update`, `coupons_delete`, `notifications_view`, `notifications_send`, `orders_view`, `orders_confirm`, `shipping_methods_view`, `shipping_methods_update`, `payment_methods_view`, `payment_methods_update`, `reports_view`, `website_setting_view`, `website_setting_update`, `application_setting_view`, `application_setting_update`, `general_setting_view`, `general_setting_update`, `manage_admins_view`, `manage_admins_create`, `manage_admins_update`, `manage_admins_delete`, `language_view`, `language_create`, `language_update`, `language_delete`, `profile_view`, `profile_update`, `admintype_view`, `admintype_create`, `admintype_update`, `admintype_delete`, `manage_admins_role`, `add_media`, `edit_media`, `view_media`, `delete_media`, `edit_management`, `reviews_view`, `reviews_update`, `deliveryboy_view`, `deliveryboy_create`, `deliveryboy_update`, `deliveryboy_delete`, `finance_view`); VALUES ('4', '13', '0', '1', '1', '1', '0', '1', '1', '1', '0', '1', '1', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0');


TRUNCATE manufacturers; TRUNCATE manufacturers_info; TRUNCATE menu_translation; INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('2', '1', '1', 'Home');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('3', '1', '2', 'Homee');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('39', '21', '1', 'Demo');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('40', '21', '2', 'Demo');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('41', '22', '1', 'Contact');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('42', '22', '2', 'Contact Us');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('43', '23', '1', 'LAINNYA');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('44', '24', '1', 'SAYURAN');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('45', '25', '1', 'DAGING');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('46', '26', '1', 'BUAH');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('47', '27', '1', 'IKAN');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('48', '28', '1', 'BUMBU DAPUR');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('49', '29', '1', 'FROZEN FOOD');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('50', '30', '1', 'IKAN KERING & ASIN');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('51', '31', '1', 'SEMBAKO');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('52', '32', '1', 'KEPERLUAN RUMAH TANGGA');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('53', '33', '1', 'NEWS');


TRUNCATE menus; INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('1', '1', '', '0', '1', '', '/', '', '1', '', '');


INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('22', '12', '', '0', '1', 'contact', 'contact', '', '1', '', '');


INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('23', '6', '', '0', '3', 'sayuran', 'sayuran', '', '1', '', '');


INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('24', '2', '', '0', '3', '', 'sayuran', '0', '1', '', '');


INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('25', '3', '', '0', '3', 'daging-ayam-segar', 'daging-ayam-segar', '', '1', '', '');


INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('26', '4', '', '0', '3', '', 'buah', '0', '1', '', '');


INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('27', '5', '', '0', '3', 'ikan-segar', 'ikan-segar', '', '1', '', '');


INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('28', '7', '', '23', '3', '', 'bumbu-dapur', '0', '1', '', '');


INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('29', '8', '', '23', '3', '', 'frozen-food', '0', '1', '', '');


INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('30', '9', '', '23', '3', '', 'ikan-kering-asin', '0', '1', '', '');


INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('31', '10', '', '23', '3', '', 'sembako', '0', '1', '', '');


INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('32', '11', '', '23', '3', '', 'keperluan-rumah-tangga', '0', '1', '', '');


INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('33', '13', '', '0', '5', '/news', '/news', '', '1', '', '');


TRUNCATE migrations; INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('1', '2020_05_19_085447_create_address_book_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('2', '2020_05_19_085447_create_alert_settings_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('3', '2020_05_19_085447_create_api_calls_list_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('4', '2020_05_19_085447_create_bank_detail_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('5', '2020_05_19_085447_create_banners_history_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('6', '2020_05_19_085447_create_banners_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('7', '2020_05_19_085447_create_block_ips_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('8', '2020_05_19_085447_create_categories_description_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('9', '2020_05_19_085447_create_categories_role_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('10', '2020_05_19_085447_create_categories_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('11', '2020_05_19_085447_create_compare_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('12', '2020_05_19_085447_create_constant_banners_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('13', '2020_05_19_085447_create_countries_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('14', '2020_05_19_085447_create_coupons_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('15', '2020_05_19_085447_create_currencies_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('16', '2020_05_19_085447_create_currency_record_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('17', '2020_05_19_085447_create_current_theme_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('18', '2020_05_19_085447_create_customers_basket_attributes_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('19', '2020_05_19_085447_create_customers_basket_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('20', '2020_05_19_085447_create_customers_info_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('21', '2020_05_19_085447_create_customers_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('22', '2020_05_19_085447_create_delievery_time_slot_with_zone_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('23', '2020_05_19_085447_create_delievery_time_slots_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('24', '2020_05_19_085447_create_deliveryboy_info_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('25', '2020_05_19_085447_create_devices_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('26', '2020_05_19_085447_create_flash_sale_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('27', '2020_05_19_085447_create_flate_rate_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('28', '2020_05_19_085447_create_floating_cash_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('29', '2020_05_19_085447_create_front_end_theme_content_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('30', '2020_05_19_085447_create_geo_zones_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('31', '2020_05_19_085447_create_home_banners_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('32', '2020_05_19_085447_create_http_call_record_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('33', '2020_05_19_085447_create_image_categories_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('34', '2020_05_19_085447_create_images_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('35', '2020_05_19_085447_create_inventory_detail_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('36', '2020_05_19_085447_create_inventory_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('37', '2020_05_19_085447_create_label_value_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('38', '2020_05_19_085447_create_labels_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('39', '2020_05_19_085447_create_languages_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('40', '2020_05_19_085447_create_liked_products_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('41', '2020_05_19_085447_create_manage_min_max_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('42', '2020_05_19_085447_create_manage_role_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('43', '2020_05_19_085447_create_manufacturers_info_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('44', '2020_05_19_085447_create_manufacturers_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('45', '2020_05_19_085447_create_menu_translation_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('46', '2020_05_19_085447_create_menus_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('47', '2020_05_19_085447_create_news_categories_description_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('48', '2020_05_19_085447_create_news_categories_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('49', '2020_05_19_085447_create_news_description_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('50', '2020_05_19_085447_create_news_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('51', '2020_05_19_085447_create_news_to_news_categories_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('52', '2020_05_19_085447_create_orders_products_attributes_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('53', '2020_05_19_085447_create_orders_products_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('54', '2020_05_19_085447_create_orders_status_description_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('55', '2020_05_19_085447_create_orders_status_history_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('56', '2020_05_19_085447_create_orders_status_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('57', '2020_05_19_085447_create_orders_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('58', '2020_05_19_085447_create_orders_to_delivery_boy_history_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('59', '2020_05_19_085447_create_orders_to_delivery_boy_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('60', '2020_05_19_085447_create_orders_total_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('61', '2020_05_19_085447_create_pages_description_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('62', '2020_05_19_085447_create_pages_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('63', '2020_05_19_085447_create_payment_description_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('64', '2020_05_19_085447_create_payment_methods_detail_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('65', '2020_05_19_085447_create_payment_methods_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('66', '2020_05_19_085447_create_payment_withdraw_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('67', '2020_05_19_085447_create_permissions_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('68', '2020_05_19_085447_create_products_attributes_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('69', '2020_05_19_085447_create_products_description_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('70', '2020_05_19_085447_create_products_images_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('71', '2020_05_19_085447_create_products_options_descriptions_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('72', '2020_05_19_085447_create_products_options_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('73', '2020_05_19_085447_create_products_options_values_descriptions_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('74', '2020_05_19_085447_create_products_options_values_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('75', '2020_05_19_085447_create_products_shipping_rates_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('76', '2020_05_19_085447_create_products_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('77', '2020_05_19_085447_create_products_to_categories_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('78', '2020_05_19_085447_create_reviews_description_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('79', '2020_05_19_085447_create_reviews_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('80', '2020_05_19_085447_create_sessions_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('81', '2020_05_19_085447_create_settings_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('82', '2020_05_19_085447_create_shipping_description_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('83', '2020_05_19_085447_create_shipping_methods_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('84', '2020_05_19_085447_create_sliders_images_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('85', '2020_05_19_085447_create_specials_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('86', '2020_05_19_085447_create_tax_class_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('87', '2020_05_19_085447_create_tax_rates_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('88', '2020_05_19_085447_create_top_offers_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('89', '2020_05_19_085447_create_units_descriptions_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('90', '2020_05_19_085447_create_units_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('91', '2020_05_19_085447_create_ups_shipping_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('92', '2020_05_19_085447_create_user_to_address_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('93', '2020_05_19_085447_create_user_types_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('94', '2020_05_19_085447_create_users_balance_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('95', '2020_05_19_085447_create_users_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('96', '2020_05_19_085447_create_whos_online_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('97', '2020_05_19_085447_create_zones_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('98', '2020_05_19_085447_create_zones_to_geo_zones_table', '1');


TRUNCATE news; INSERT INTO news (`news_id`, `news_image`, `news_date_added`, `news_last_modified`, `news_status`, `is_feature`, `news_slug`, `created_at`, `updated_at`); VALUES ('1', '287', '0000-00-00 00:00:00', '', '1', '1', 'mengunjungi-mitra-binaan-rumah-sayur-kita', '2020-07-22 06:07:50', '');


TRUNCATE news_categories; INSERT INTO news_categories (`categories_id`, `categories_image`, `categories_icon`, `parent_id`, `sort_order`, `date_added`, `last_modified`, `news_categories_slug`, `categories_status`, `created_at`, `updated_at`); VALUES ('1', '285', '', '0', '1', '', '', 'mitra-sayur', '1', '2020-07-22 06:03:06', '');


TRUNCATE news_categories_description; INSERT INTO news_categories_description (`categories_description_id`, `categories_id`, `language_id`, `categories_name`); VALUES ('1', '1', '1', 'MITRA SAYUR');


TRUNCATE news_description; INSERT INTO news_description (`language_id`, `news_name`, `news_id`, `news_description`, `news_url`, `news_viewed`); VALUES ('1', 'Mengunjungi Mitra Binaan RUMAH SAYUR KITA', '1', '<p>Dalam rangka pembukaan RUMAH SAYUR KITA, kami memberikan kualitas terbaik dengan harga yang sangat murah bagi mitra sayur kita.</p>', '0', '0');


TRUNCATE news_to_news_categories; INSERT INTO news_to_news_categories (`news_id`, `categories_id`, `created_at`, `updated_at`); VALUES ('1', '1', '2020-07-22 06:07:50', '');


TRUNCATE orders; TRUNCATE orders_products; TRUNCATE orders_products_attributes; TRUNCATE orders_status; INSERT INTO orders_status (`orders_status_id`, `public_flag`, `downloads_flag`, `role_id`); VALUES ('1', '1', '1', '2');


INSERT INTO orders_status (`orders_status_id`, `public_flag`, `downloads_flag`, `role_id`); VALUES ('2', '0', '0', '2');


INSERT INTO orders_status (`orders_status_id`, `public_flag`, `downloads_flag`, `role_id`); VALUES ('3', '0', '0', '2');


INSERT INTO orders_status (`orders_status_id`, `public_flag`, `downloads_flag`, `role_id`); VALUES ('4', '0', '0', '2');


INSERT INTO orders_status (`orders_status_id`, `public_flag`, `downloads_flag`, `role_id`); VALUES ('5', '0', '0', '2');


INSERT INTO orders_status (`orders_status_id`, `public_flag`, `downloads_flag`, `role_id`); VALUES ('6', '0', '0', '2');


INSERT INTO orders_status (`orders_status_id`, `public_flag`, `downloads_flag`, `role_id`); VALUES ('7', '0', '0', '2');


INSERT INTO orders_status (`orders_status_id`, `public_flag`, `downloads_flag`, `role_id`); VALUES ('8', '0', '0', '3');


INSERT INTO orders_status (`orders_status_id`, `public_flag`, `downloads_flag`, `role_id`); VALUES ('9', '0', '0', '3');


INSERT INTO orders_status (`orders_status_id`, `public_flag`, `downloads_flag`, `role_id`); VALUES ('10', '0', '0', '3');


INSERT INTO orders_status (`orders_status_id`, `public_flag`, `downloads_flag`, `role_id`); VALUES ('11', '0', '0', '3');


TRUNCATE orders_status_description; INSERT INTO orders_status_description (`orders_status_description_id`, `orders_status_id`, `orders_status_name`, `language_id`); VALUES ('1', '1', 'Pending', '1');


INSERT INTO orders_status_description (`orders_status_description_id`, `orders_status_id`, `orders_status_name`, `language_id`); VALUES ('2', '2', 'Completed', '1');


INSERT INTO orders_status_description (`orders_status_description_id`, `orders_status_id`, `orders_status_name`, `language_id`); VALUES ('3', '3', 'Cancel', '1');


INSERT INTO orders_status_description (`orders_status_description_id`, `orders_status_id`, `orders_status_name`, `language_id`); VALUES ('4', '4', 'Return', '1');


INSERT INTO orders_status_description (`orders_status_description_id`, `orders_status_id`, `orders_status_name`, `language_id`); VALUES ('5', '5', 'Inprocess', '1');


INSERT INTO orders_status_description (`orders_status_description_id`, `orders_status_id`, `orders_status_name`, `language_id`); VALUES ('6', '8', 'Online', '1');


INSERT INTO orders_status_description (`orders_status_description_id`, `orders_status_id`, `orders_status_name`, `language_id`); VALUES ('7', '9', 'Free for Delivery', '1');


INSERT INTO orders_status_description (`orders_status_description_id`, `orders_status_id`, `orders_status_name`, `language_id`); VALUES ('8', '10', 'Online Busy With Delivery', '1');


INSERT INTO orders_status_description (`orders_status_description_id`, `orders_status_id`, `orders_status_name`, `language_id`); VALUES ('9', '11', 'Offline', '1');


INSERT INTO orders_status_description (`orders_status_description_id`, `orders_status_id`, `orders_status_name`, `language_id`); VALUES ('10', '6', 'Delivered', '1');


INSERT INTO orders_status_description (`orders_status_description_id`, `orders_status_id`, `orders_status_name`, `language_id`); VALUES ('11', '7', 'Dispatched', '1');


TRUNCATE orders_status_history; INSERT INTO orders_status_history (`orders_status_history_id`, `orders_id`, `orders_status_id`, `date_added`, `customer_notified`, `comments`, `role_id`); VALUES ('1', '1', '1', '2020-08-31 04:27:58', '1', '', '1');


INSERT INTO orders_status_history (`orders_status_history_id`, `orders_id`, `orders_status_id`, `date_added`, `customer_notified`, `comments`, `role_id`); VALUES ('2', '1', '3', '2020-08-31 04:34:42', '1', '', '1');


INSERT INTO orders_status_history (`orders_status_history_id`, `orders_id`, `orders_status_id`, `date_added`, `customer_notified`, `comments`, `role_id`); VALUES ('3', '1', '5', '2020-08-31 04:39:20', '1', 'Pembayaran di Tempat', '1');


TRUNCATE orders_to_delivery_boy; TRUNCATE orders_to_delivery_boy_history; TRUNCATE orders_total; TRUNCATE pages; TRUNCATE pages_description; TRUNCATE payment_description; INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('1', '1', 'Braintree', '1', 'Credit Card', 'Paypal');


INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('4', '2', 'Stripe', '1', '', '');


INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('5', '3', 'Paypal', '1', '', '');


INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('6', '4', 'Cash on Delivery', '1', '', '');


INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('7', '5', 'Instamojo', '1', '', '');


INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('8', '0', 'Cybersoure', '1', '', '');


INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('9', '6', 'Hyperpay', '1', '', '');


INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('10', '7', 'Razor Pay', '1', '', '');


INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('11', '8', 'PayTm', '1', '', '');


TRUNCATE payment_methods; INSERT INTO payment_methods (`payment_methods_id`, `payment_method`, `status`, `environment`, `created_at`, `updated_at`); VALUES ('1', 'braintree', '0', '0', '2019-09-18 16:40:13', '0000-00-00 00:00:00');


INSERT INTO payment_methods (`payment_methods_id`, `payment_method`, `status`, `environment`, `created_at`, `updated_at`); VALUES ('2', 'stripe', '0', '0', '2019-09-18 16:56:17', '0000-00-00 00:00:00');


INSERT INTO payment_methods (`payment_methods_id`, `payment_method`, `status`, `environment`, `created_at`, `updated_at`); VALUES ('3', 'paypal', '0', '0', '2019-09-18 16:56:04', '0000-00-00 00:00:00');


INSERT INTO payment_methods (`payment_methods_id`, `payment_method`, `status`, `environment`, `created_at`, `updated_at`); VALUES ('4', 'cash_on_delivery', '1', '0', '2019-09-18 16:56:37', '0000-00-00 00:00:00');


INSERT INTO payment_methods (`payment_methods_id`, `payment_method`, `status`, `environment`, `created_at`, `updated_at`); VALUES ('5', 'instamojo', '0', '0', '2019-09-18 16:57:23', '0000-00-00 00:00:00');


INSERT INTO payment_methods (`payment_methods_id`, `payment_method`, `status`, `environment`, `created_at`, `updated_at`); VALUES ('6', 'hyperpay', '0', '0', '2019-09-18 16:56:44', '0000-00-00 00:00:00');


INSERT INTO payment_methods (`payment_methods_id`, `payment_method`, `status`, `environment`, `created_at`, `updated_at`); VALUES ('7', 'razor_pay', '0', '0', '2019-09-18 16:56:44', '0000-00-00 00:00:00');


INSERT INTO payment_methods (`payment_methods_id`, `payment_method`, `status`, `environment`, `created_at`, `updated_at`); VALUES ('8', 'pay_tm', '0', '0', '2019-09-18 16:56:44', '0000-00-00 00:00:00');


TRUNCATE payment_methods_detail; INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('3', '1', 'merchant_id', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('4', '1', 'public_key', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('5', '1', 'private_key', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('9', '2', 'secret_key', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('10', '2', 'publishable_key', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('15', '3', 'id', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('18', '3', 'payment_currency', 'USD');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('21', '5', 'api_key', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('22', '5', 'auth_token', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('23', '5', 'client_id', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('24', '5', 'client_secret', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('32', '6', 'userid', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('33', '6', 'password', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('34', '6', 'entityid', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('35', '7', 'RAZORPAY_KEY', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('36', '7', 'RAZORPAY_SECRET', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('37', '8', 'paytm_mid', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('39', '8', 'paytm_key', 'w#');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('40', '8', 'current_domain_name', '');


TRUNCATE payment_withdraw; TRUNCATE permissions; TRUNCATE products; INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('2', '0', '', '166', '', '10000', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'bawang-putih-kating-500gr', '0', '1', '', '2020-07-20 05:21:32', '2020-07-21 05:32:15');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('3', '0', '', '138', '', '15000', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'bawang-merah-brebes-500gr', '0', '1', '', '2020-07-20 05:22:28', '2020-07-21 05:31:55');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('4', '0', '', '141', '', '8000', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'bawang-bombay-500gr', '0', '1', '', '2020-07-20 05:23:02', '2020-07-21 05:32:55');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('5', '0', '', '143', '', '22500', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'brokoli-1kg', '0', '1', '', '2020-07-20 05:23:39', '2020-07-21 05:31:48');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('6', '0', '', '142', '', '5500', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'buncis-500gr', '0', '1', '', '2020-07-20 05:25:13', '2020-07-21 05:31:09');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('7', '0', '', '142', '', '12000', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'buncis-baby-500gr', '0', '1', '', '2020-07-20 05:26:12', '2020-07-21 05:33:12');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('8', '0', '', '145', '', '6500', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'cabe-hijau-besar-500gr', '0', '1', '', '2020-07-20 05:26:48', '2020-07-21 05:30:44');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('9', '0', '', '204', '', '6500', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'cabe-hijau-keriting-500gr', '0', '1', '', '2020-07-20 05:28:14', '2020-07-21 05:25:55');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('10', '0', '', '148', '', '10800', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'cabe-merah-besar-500gr', '0', '1', '', '2020-07-20 05:29:22', '2020-07-21 05:25:27');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('11', '0', '', '144', '', '9200', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'cabe-merah-keriting-500gr', '0', '1', '', '2020-07-20 05:29:57', '2020-07-21 05:25:25');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('12', '0', '', '147', '', '11250', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'cabe-rawit-merah-500gr', '0', '1', '', '2020-07-20 05:30:26', '2020-07-21 05:25:24');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('13', '0', '', '190', '', '12000', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'cabe-rawit-hijau-500gr', '0', '1', '', '2020-07-20 05:31:18', '2020-07-21 05:25:03');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('14', '0', '', '152', '', '15000', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'daun-bawang-sledri-1kg', '0', '1', '', '2020-07-20 05:31:57', '2020-07-21 05:25:02');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('15', '0', '', '156', '', '8200', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'jagung-manis-1kg', '0', '1', '', '2020-07-20 06:37:26', '2020-07-21 05:26:00');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('16', '0', '', '219', '', '4000', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'jeruk-nipis-500gr', '0', '1', '', '2020-07-20 06:40:05', '2020-07-21 05:25:02');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('17', '0', '', '163', '', '6900', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'kacang-panjang-500gr', '0', '1', '', '2020-07-20 06:40:39', '2020-07-21 05:24:52');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('18', '0', '', '168', '', '18800', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'kembang-kol-1kg', '0', '1', '', '2020-07-20 06:41:14', '2020-07-21 05:27:37');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('19', '0', '', '261', '', '21000', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'kemiri-500gr', '0', '1', '', '2020-07-20 06:42:15', '2020-07-21 05:25:56');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('21', '0', '', '171', '', '15000', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'kentang-dieng-grade-a-1kg-1', '0', '1', '', '2020-07-20 06:42:53', '2020-07-21 05:23:51');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('22', '0', '', '169', '', '15000', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'kentang-dieng-grade-b-1kg', '0', '1', '', '2020-07-20 06:43:32', '2020-07-21 05:23:42');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('23', '0', '', '169', '', '12500', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'kentang-dieng-grade-c-1kg', '0', '1', '', '2020-07-20 06:44:37', '2020-07-21 05:23:41');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('24', '0', '', '172', '', '4700', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'kol-1kg', '0', '1', '', '2020-07-20 06:45:43', '2020-07-21 05:24:02');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('25', '0', '', '178', '', '2750', '0000-00-00 00:00:00', '', '', '1', 'Pcs', '1', '1', '0', '', '0', '0', '0', '0', 'labu-siam-besar-pcs', '0', '1', '', '2020-07-20 06:46:18', '2020-07-21 05:22:30');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('26', '0', '', '174', '', '4700', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'labu-siam-kecil-500gr', '0', '1', '', '2020-07-20 06:46:59', '2020-07-21 05:22:32');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('27', '0', '', '180', '', '8800', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'oyong-1kg', '0', '1', '', '2020-07-20 06:47:48', '2020-07-21 05:21:50');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('28', '0', '', '184', '', '6500', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'pare-500gr', '0', '1', '', '2020-07-20 06:48:15', '2020-07-21 05:21:14');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('29', '0', '', '187', '', '6500', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'pokcoy-500gr', '0', '1', '', '2020-07-20 06:48:46', '2020-07-21 05:20:55');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('30', '0', '', '188', '', '6500', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'jagung-putren-500gr', '0', '1', '', '2020-07-20 06:49:25', '2020-07-21 05:19:43');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('31', '0', '', '164', '', '6500', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'sawi-hijau-1kg', '0', '1', '', '2020-07-20 06:50:05', '2020-07-21 05:19:34');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('32', '0', '', '192', '', '6500', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'sawi-putih-500gr', '0', '1', '', '2020-07-20 06:50:38', '2020-07-21 05:19:25');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('33', '0', '', '268', '', '6250', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'terong-ungu-500gr', '0', '1', '', '2020-07-20 06:51:54', '2020-07-21 05:19:17');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('34', '0', '', '197', '', '3500', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'timun-500gr', '0', '1', '', '2020-07-20 06:52:24', '2020-07-21 05:19:09');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('35', '0', '', '202', '', '4400', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'wortel-lokal-500gr', '0', '1', '', '2020-07-20 06:53:02', '2020-07-21 05:19:00');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('36', '0', '', '165', '', '3000', '0000-00-00 00:00:00', '', '', '1', 'Ikat', '1', '1', '0', '', '0', '0', '0', '0', 'kangkung-darat-ikat', '0', '1', '', '2020-07-20 06:54:15', '2020-07-21 05:18:34');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('37', '0', '', '140', '', '3500', '0000-00-00 00:00:00', '', '', '1', 'Ikat', '1', '1', '0', '', '0', '0', '0', '0', 'bayam-ikat', '0', '1', '', '2020-07-20 06:55:05', '2020-07-21 05:18:07');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('38', '0', '', '153', '', '2500', '0000-00-00 00:00:00', '', '', '1', 'Ikat', '1', '1', '0', '', '0', '0', '0', '0', 'daun-singkong-jepang-ikat', '0', '1', '', '2020-07-20 06:56:38', '2020-07-21 05:17:43');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('39', '0', '', '269', '', '4500', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'singkong-1kg', '0', '1', '', '2020-07-20 06:58:17', '2020-07-21 05:17:23');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('40', '0', '', '196', '', '3500', '0000-00-00 00:00:00', '', '', '1', 'Pcs', '1', '1', '0', '', '0', '0', '0', '0', 'paket-sayur-sop', '0', '1', '', '2020-07-20 06:59:39', '2020-07-21 05:17:01');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('41', '0', '', '271', '', '3500', '0000-00-00 00:00:00', '', '', '1', 'Pcs', '1', '1', '0', '', '0', '0', '0', '0', 'paket-sayur-asem', '0', '1', '', '2020-07-20 07:05:10', '2020-07-21 05:16:43');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('42', '0', '', '250', '', '6000', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'ubi-merah-1kg', '0', '1', '', '2020-07-20 07:06:00', '2020-07-21 05:16:21');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('43', '0', '', '251', '', '6000', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'ubi-ungu-1kg', '0', '1', '', '2020-07-20 07:06:38', '2020-07-21 05:16:05');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('44', '0', '', '252', '', '6000', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'ubi-putih-1kg', '0', '1', '', '2020-07-20 07:07:28', '2020-07-21 05:15:50');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('45', '0', '', '198', '', '4750', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'tauge-500gr', '0', '1', '', '2020-07-20 07:08:03', '2020-07-21 05:15:27');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('46', '0', '', '194', '', '5300', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'terong-bulat-500gr', '0', '1', '', '2020-07-20 07:08:56', '2020-07-21 05:12:25');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('47', '0', '', '272', '', '8000', '0000-00-00 00:00:00', '', '', '1', 'Ikat', '1', '1', '0', '', '0', '0', '0', '0', 'daun-kemangi-10-tangkai', '0', '1', '', '2020-07-20 07:10:30', '2020-07-21 05:12:09');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('48', '0', '', '177', '', '8500', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'lobak-1kg', '0', '1', '', '2020-07-20 07:11:02', '2020-07-21 05:11:49');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('49', '0', '', '265', '', '8000', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'lengkuas-500gr', '0', '1', '', '2020-07-20 07:11:50', '2020-07-21 05:11:32');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('50', '0', '', '134', '', '32000', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'bawang-merah-brebes-super-1kg', '0', '1', '', '2020-07-20 07:13:39', '2020-07-22 04:01:26');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('51', '0', '', '199', '', '6500', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'tomat-500gr', '0', '1', '', '2020-07-20 07:15:21', '2020-07-23 06:06:09');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('52', '0', '', '274', '', '10000', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'jagung-manis-kupas-1kg', '0', '1', '', '2020-07-20 07:19:32', '2020-07-21 05:09:57');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('53', '0', '', '275', '', '20000', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'kacang-kapri-500gr', '0', '1', '', '2020-07-20 07:20:54', '2020-07-21 05:09:36');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('54', '0', '', '193', '', '8000', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'selada-keriting-500gr', '0', '1', '', '2020-07-20 07:21:34', '2020-07-21 05:09:17');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('55', '0', '', '276', '', '16000', '0000-00-00 00:00:00', '', '', '250', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'kacang-merah-250gr', '0', '1', '', '2020-07-20 07:23:18', '2020-07-21 05:09:01');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('56', '0', '', '181', '', '6000', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'melinjo-kulit-500gr', '0', '1', '', '2020-07-20 07:24:57', '2020-07-21 05:08:50');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('57', '0', '', '154', '', '2000', '0000-00-00 00:00:00', '', '', '1', 'Ikat', '1', '1', '0', '', '0', '0', '0', '0', 'daun-pepaya-jepang-ikat', '0', '1', '', '2020-07-20 07:25:49', '2020-07-21 05:08:17');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('58', '0', '', '179', '', '4500', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'nangka-muda-500gr', '0', '1', '', '2020-07-20 07:27:04', '2020-07-21 05:08:28');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('59', '0', '', '183', '', '49000', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'paprika-hijau-1kg', '0', '1', '', '2020-07-20 07:27:51', '2020-07-21 05:07:55');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('60', '0', '', '189', '', '59000', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'paprika-merah-1kg', '0', '1', '', '2020-07-20 07:28:26', '2020-07-21 05:07:40');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('61', '0', '', '272', '', '4500', '0000-00-00 00:00:00', '', '', '1', 'Ikat', '1', '1', '0', '', '0', '0', '0', '0', 'daun-kemangi-5-tangkai', '0', '1', '', '2020-07-20 07:29:54', '2020-07-21 05:07:24');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('62', '0', '', '167', '', '1200', '0000-00-00 00:00:00', '', '', '1', 'Ikat', '1', '1', '0', '', '0', '0', '0', '0', 'kembang-genjer-ikat', '0', '1', '', '2020-07-20 07:30:41', '2020-07-21 05:07:03');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('63', '0', '', '277', '', '5250', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'tomat-hijau-500gr', '0', '1', '', '2020-07-20 07:32:02', '2020-07-21 05:06:42');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('64', '0', '', '149', '', '4000', '0000-00-00 00:00:00', '', '', '100', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'daun-jeruk-100gr', '0', '1', '', '2020-07-20 07:32:40', '2020-07-21 05:03:38');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('65', '0', '', '170', '', '5750', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'kentang-baby-1kg', '0', '1', '', '2020-07-20 07:33:46', '2020-07-21 05:06:21');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('66', '0', '', '334', '', '65500', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'jahe-merah-1kg', '0', '1', '', '2020-07-20 07:35:01', '2020-07-24 02:22:56');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('68', '0', '', '259', '', '50000', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'jahe-putih-1kg-1', '0', '1', '', '2020-07-20 07:35:47', '2020-07-21 05:05:28');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('69', '0', '', '257', '', '38000', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'jahe-gajah-1kg', '0', '1', '', '2020-07-20 07:36:33', '2020-07-21 05:04:55');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('70', '0', '', '278', '', '1000', '0000-00-00 00:00:00', '', '', '1', 'Pcs', '1', '1', '0', '', '0', '0', '0', '0', 'asem-jawa-pcs', '0', '1', '', '2020-07-20 07:37:09', '2020-07-21 03:09:22');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('71', '0', '', '291', '', '37500', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'ati-sapi-500gr', '0', '1', '', '2020-07-24 01:37:49', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('72', '0', '', '301', '', '75000', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'iga-sapi-panjang-1kg', '0', '1', '', '2020-07-24 01:38:25', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('73', '0', '', '302', '', '55700', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'daging-rendang-segar-500gr', '0', '1', '', '2020-07-24 01:39:12', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('74', '0', '', '303', '', '15000', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'iga-kerongkongan-ayam-1kg', '0', '1', '', '2020-07-24 01:40:01', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('75', '0', '', '307', '', '13000', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'kepala-ayam-1kg', '0', '1', '', '2020-07-24 01:42:21', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('76', '0', '', '308', '', '16500', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'drumstick-500gr-isi-4-5pcs', '0', '1', '', '2020-07-24 01:43:49', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('77', '0', '', '309', '', '10000', '0000-00-00 00:00:00', '', '', '1', 'Bungkus', '1', '1', '0', '', '0', '0', '0', '0', 'ati-ampela-ayam-isi-5pcs', '0', '1', '', '2020-07-24 01:46:22', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('78', '0', '', '297', '', '15000', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'ceker-ayam-500gr', '0', '1', '', '2020-07-24 01:47:08', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('79', '0', '', '310', '', '15000', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'sayap-ayam-500gr', '0', '1', '', '2020-07-24 01:48:18', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('80', '0', '', '311', '', '55000', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'paru-sapi-500gr', '0', '1', '', '2020-07-24 01:49:27', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('81', '0', '', '300', '', '55700', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'daging-sengkel-500gr', '0', '1', '', '2020-07-24 01:50:21', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('82', '0', '', '290', '', '27000', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '1', 'ayam-negri-utuh-1kg', '0', '1', '', '2020-07-24 01:51:08', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('83', '0', '', '312', '', '22000', '0000-00-00 00:00:00', '', '', '700', 'Gram', '1', '1', '0', '', '0', '0', '0', '1', 'ayam-negri-utuh-700-800gr', '0', '1', '', '2020-07-24 01:59:18', '2020-07-24 02:00:44');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('84', '0', '', '313', '', '92000', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'tetelan-sapi-segar-1kg', '0', '1', '', '2020-07-24 02:00:23', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('85', '0', '', '314', '', '13000', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'kikil-sapi-500gr', '0', '1', '', '2020-07-24 02:02:57', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('86', '0', '', '315', '', '45000', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'daging-sandung-lamur-500gr', '0', '1', '', '2020-07-24 02:05:00', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('87', '0', '', '299', '', '20000', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '1', 'dada-fillet-kulit-500gr', '0', '1', '', '2020-07-24 02:05:42', '2020-07-24 02:19:39');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('88', '0', '', '298', '', '22000', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '1', 'dada-fillet-polos-500gr', '0', '1', '', '2020-07-24 02:07:17', '2020-07-24 02:19:41');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('89', '0', '', '316', '', '17000', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '1', 'paha-fillet-kulit-500gr', '0', '1', '', '2020-07-24 02:09:31', '2020-07-24 02:19:47');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('90', '0', '', '317', '', '20000', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '1', 'paha-fillet-polos-500gr', '0', '1', '', '2020-07-24 02:10:50', '2020-07-24 02:19:50');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('91', '0', '', '310', '', '15000', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'sayap-ayam-500gr-1', '0', '1', '', '2020-07-24 02:11:35', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('92', '0', '', '318', '', '36000', '0000-00-00 00:00:00', '', '', '1.3', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '1', 'ayam-utuh-1-3kg', '0', '1', '', '2020-07-24 02:13:00', '2020-07-24 02:19:07');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('93', '0', '', '319', '', '55700', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'daging-segar-tanpa-lemak-500gr', '0', '1', '', '2020-07-24 02:15:32', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('94', '0', '', '320', '', '9000', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'usus-ayam-500gr', '0', '1', '', '2020-07-24 02:16:38', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('95', '0', '', '321', '', '17500', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'kulit-ayam-500gr', '0', '1', '', '2020-07-24 02:17:13', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('96', '0', '', '322', '', '41000', '0000-00-00 00:00:00', '', '', '1.5', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '1', 'ayam-negri-utuh-1-5kg', '0', '1', '', '2020-07-24 02:18:35', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('97', '0', '', '323', '', '35000', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'ikan-mujair-1kg-isi-4-5', '0', '1', '', '2020-07-24 07:07:41', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('98', '0', '', '324', '', '25000', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'ikan-lele-segar-1kg', '0', '1', '', '2020-07-24 07:08:38', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('99', '0', '', '325', '', '38000', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'ikan-kembung-banjar-1kg', '0', '1', '', '2020-07-24 07:09:28', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('100', '0', '', '328', '', '46000', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'gurame-1kg', '0', '1', '', '2020-07-24 07:15:06', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('101', '0', '', '326', '', '32000', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'patin-1kg', '0', '1', '', '2020-07-24 07:15:48', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('102', '0', '', '327', '', '70000', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'daging-ikan-tuna-1kg', '0', '1', '', '2020-07-24 07:16:44', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('103', '0', '', '329', '', '45000', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'ikan-tongkol-basah-1kg', '0', '1', '', '2020-07-24 07:18:29', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('104', '0', '', '332', '', '45000', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'ikan-ekor-kuning-1kg', '0', '1', '', '2020-07-24 07:22:50', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('105', '0', '', '330', '', '52000', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'ikan-tenggiri-500gr', '0', '1', '', '2020-07-24 07:23:39', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('106', '0', '', '333', '', '25000', '0000-00-00 00:00:00', '', '', '1', 'Kilogram', '1', '1', '0', '', '0', '0', '0', '0', 'ikan-bawal-air-tawar-1kg', '0', '1', '', '2020-07-24 07:24:18', '');


INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('107', '0', '', '331', '', '50000', '0000-00-00 00:00:00', '', '', '500', 'Gram', '1', '1', '0', '', '0', '0', '0', '0', 'udang-pancet-500gr', '0', '1', '', '2020-07-24 07:25:03', '');


TRUNCATE products_attributes; TRUNCATE products_description; INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('2', '2', '1', 'Bawang Putih Kating 500Gr', '<p>Bawang Putih Kating 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('3', '3', '1', 'Bawang Merah Brebes 500Gr', '<p>Bawang Merah Brebes 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('4', '4', '1', 'Bawang Bombay 500Gr', '<p>Bawang Bombay 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('5', '5', '1', 'Brokoli 1Kg', '<p>Brokoli 1Kg</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('6', '6', '1', 'Buncis 500Gr', '<p>Buncis 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('7', '7', '1', 'buncis Baby 500Gr', '<p>buncis Baby 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('8', '8', '1', 'Cabe Hijau Besar 500Gr', '<p>Cabe Hijau Besar 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('9', '9', '1', 'Cabe Hijau Keriting 500Gr', '<p>Cabe Hijau Keriting 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('10', '10', '1', 'Cabe Merah besar 500Gr', '<p>Cabe Merah besar 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('11', '11', '1', 'Cabe Merah Keriting 500Gr', '<p>Cabe Merah Keriting 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('12', '12', '1', 'Cabe Rawit Merah 500Gr', '<p>Cabe Rawit Merah 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('13', '13', '1', 'Cabe Rawit Hijau 500Gr', '<p>Cabe Rawit Hijau 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('14', '14', '1', 'Daun Bawang Sledri 1Kg', '<p>Daun Bawang Sledri 1Kg</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('15', '15', '1', 'Jagung Manis 1Kg', '<p>Jagung Manis 1Kg</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('16', '16', '1', 'Jeruk Nipis 500Gr', '<p>Jeruk Nipis 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('17', '17', '1', 'Kacang Panjang 500Gr', '<p>Kacang Panjang 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('18', '18', '1', 'Kembang Kol 1Kg', '<p>Kembang Kol 1Kg</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('19', '19', '1', 'Kemiri 500Gr', '<p>Kemiri 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('21', '21', '1', 'Kentang Dieng grade A 1Kg', '<p>Kentang Dieng grade A 1Kg</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('22', '22', '1', 'Kentang Dieng grade B 1Kg', '<p>Kentang Dieng grade B 1Kg</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('23', '23', '1', 'Kentang Dieng grade C 1Kg', '<p>Kentang Dieng grade C 1Kg</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('24', '24', '1', 'Kol 1Kg', '<p>Kol 1Kg</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('25', '25', '1', 'Labu Siam Besar Pcs', '<p>Labu Siam Besar Pcs</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('26', '26', '1', 'Labu Siam Kecil 500Gr', '<p>Labu Siam Kecil 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('27', '27', '1', 'Oyong 1Kg', '<p>Oyong 1Kg</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('28', '28', '1', 'Pare 500Gr', '<p>Pare 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('29', '29', '1', 'Pokcoy 500Gr', '<p>Pokcoy 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('30', '30', '1', 'Jagung Putren 500Gr', '<p>Jagung Putren 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('31', '31', '1', 'Sawi Hijau 1Kg', '<p>Sawi Hijau 1Kg</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('32', '32', '1', 'Sawi Putih 500Gr', '<p>Sawi Putih 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('33', '33', '1', 'Terong Ungu 500Gr', '<p>Terong Ungu 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('34', '34', '1', 'Timun 500Gr', '<p>Timun 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('35', '35', '1', 'Wortel Lokal 500Gr', '<p>Wortel Lokal 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('36', '36', '1', 'Kangkung Darat Ikat', '<p>Kangkung Darat Ikat</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('37', '37', '1', 'Bayam Ikat', '<p>Bayam Ikat</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('38', '38', '1', 'Daun Singkong Jepang Ikat', '<p>Daun Singkong Jepang Ikat</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('39', '39', '1', 'Singkong 1Kg', '<p>Singkong 1Kg</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('40', '40', '1', 'Paket Sayur SOP', '<p>Paket Sayur SOP</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('41', '41', '1', 'Paket Sayur Asem', '<p>Paket Sayur Asem</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('42', '42', '1', 'Ubi Merah 1Kg', '<p>Ubi Merah 1Kg</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('43', '43', '1', 'Ubi Ungu 1Kg', '<p>Ubi Ungu 1Kg</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('44', '44', '1', 'Ubi Putih 1Kg', '<p>Ubi Putih 1Kg</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('45', '45', '1', 'Tauge 500Gr', '<p>Tauge 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('46', '46', '1', 'Terong Bulat 500Gr', '<p>Terong Bulat 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('47', '47', '1', 'Daun Kemangi 10 Tangkai', '<p>Daun Kemangi 10 Tangkai</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('48', '48', '1', 'Lobak 1Kg', '<p>Lobak 1Kg</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('49', '49', '1', 'Lengkuas 500Gr', '<p>Lengkuas 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('50', '50', '1', 'Bawang Merah Brebes Super 1Kg', '<p>Bawang Merah Brebes Super 1Kg</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('51', '51', '1', 'Tomat 500Gr', '<p>Tomat 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('52', '52', '1', 'Jagung Manis Kupas 1Kg', '<p>Jagung Manis Kupas 1Kg</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('53', '53', '1', 'Kacang Kapri 500Gr', '<p>Kacang Kapri 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('54', '54', '1', 'Selada Keriting 500Gr', '<p>Selada Keriting 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('55', '55', '1', 'Kacang Merah 250Gr', '<p>Kacang Merah 250Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('56', '56', '1', 'Melinjo (Kulit) 500gr', '<p>Melinjo (Kulit) 500gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('57', '57', '1', 'Daun Pepaya Jepang Ikat', '<p>Daun Pepaya Jepang Ikat</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('58', '58', '1', 'Nangka Muda 500Gr', '<p>Nangka Muda 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('59', '59', '1', 'Paprika Hijau 1Kg', '<p>Paprika Hijau 1Kg</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('60', '60', '1', 'Paprika Merah 1Kg', '<p>Paprika Merah 1Kg</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('61', '61', '1', 'Daun Kemangi 5 Tangkai', '<p>Daun Kemangi 5 Tangkai</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('62', '62', '1', 'Kembang Genjer Ikat', '<p>Kembang Genjer Ikat</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('63', '63', '1', 'Tomat Hijau 500Gr', '<p>Tomat Hijau 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('64', '64', '1', 'Daun Jeruk 100Gr', '<p>Daun Jeruk 100Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('65', '65', '1', 'Kentang Baby 1Kg', '<p>Kentang Baby 1Kg</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('66', '66', '1', 'Jahe Merah 1Kg', '<p>Jahe Merah 1Kg</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('68', '68', '1', 'Jahe Putih 1Kg', '<p>Jahe Putih 1Kg</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('69', '69', '1', 'Jahe Gajah 1Kg', '<p>Jahe Gajah 1Kg</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('70', '70', '1', 'Asem Jawa Pcs', '<p>Asem Jawa Pcs</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('71', '71', '1', 'Ati Sapi 500Gr', '<p>Ati Sapi 500Gr</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('72', '72', '1', 'Iga Sapi Panjang 1Kg', '<p>Iga Sapi Panjang 1Kg</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('73', '73', '1', 'Daging Rendang Segar 500Gr', '<p>Daging Rendang Segar 500Gr</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('74', '74', '1', 'Iga / Kerongkongan Ayam 1Kg', '<p>Iga / Kerongkongan Ayam 1Kg</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('75', '75', '1', 'Kepala Ayam 1Kg', '<p>Kepala Ayam 1Kg</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('76', '76', '1', 'Drumstick 500Gr isi 4-5Pcs', '<p>Drumstick 500Gr isi 4-5Pcs</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('77', '77', '1', 'Ati Ampela Ayam isi 5Pcs', '<p>Ati Ampela Ayam isi 5Pcs</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('78', '78', '1', 'Ceker Ayam 500Gr', '<p>Ceker Ayam 500Gr</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('79', '79', '1', 'Sayap Ayam 500Gr', '<p>Sayap Ayam 500Gr</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('80', '80', '1', 'Paru Sapi 500Gr', '<p>Paru Sapi 500Gr</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('81', '81', '1', 'Daging Sengkel 500Gr', '<p>Daging Sengkel 500Gr</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('82', '82', '1', 'Ayam Negri utuh 1Kg', '<p>Ayam Negri utuh 1Kg</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('83', '83', '1', 'Ayam Negri utuh 700-800Gr', '<p>Ayam Negri utuh 700-800Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('84', '84', '1', 'Tetelan Sapi Segar 1Kg', '<p>Tetelan Sapi Segar 1Kg</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('85', '85', '1', 'Kikil Sapi 500Gr', '<p>Kikil Sapi 500Gr</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('86', '86', '1', 'Daging sandung Lamur 500Gr', '<p>Daging sandung Lamur 500Gr</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('87', '87', '1', 'Dada Fillet Kulit 500Gr', '<p>Dada Fillet Kulit 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('88', '88', '1', 'Dada Fillet Polos 500Gr', '<p>Dada Fillet Polos 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('89', '89', '1', 'Paha fillet Kulit 500Gr', '<p>Paha fillet Kulit 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('90', '90', '1', 'paha Fillet Polos 500Gr', '<p>paha Fillet Polos 500Gr</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('91', '91', '1', 'Sayap Ayam 500Gr', '<p>Sayap Ayam 500Gr</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('92', '92', '1', 'Ayam Utuh 1.3Kg', '<p>Ayam Utuh 1.3Kg</p>', '', '0', '', '0', '0', '', '0', '0');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('93', '93', '1', 'Daging Segar Tanpa Lemak 500Gr', '<p>Daging Segar Tanpa Lemak 500Gr</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('94', '94', '1', 'Usus Ayam 500Gr', '<p>Usus Ayam 500Gr</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('95', '95', '1', 'Kulit Ayam 500Gr', '<p>Kulit Ayam 500Gr</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('96', '96', '1', 'Ayam Negri utuh 1.5Kg', '<p>Ayam Negri utuh 1.5Kg</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('97', '97', '1', 'Ikan Mujair 1Kg isi 4-5', '<p>Ikan Mujair 1Kg isi 4-5</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('98', '98', '1', 'Ikan Lele Segar 1Kg', '<p>Ikan Lele Segar 1Kg</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('99', '99', '1', 'Ikan Kembung Banjar 1Kg', '<p>Ikan Kembung Banjar 1Kg</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('100', '100', '1', 'Gurame 1Kg', '<p>Gurame 1Kg</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('101', '101', '1', 'Patin 1Kg', '<p>Patin 1Kg</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('102', '102', '1', 'Daging Ikan Tuna 1Kg', '<p>Daging Ikan Tuna 1Kg</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('103', '103', '1', 'Ikan Tongkol Basah 1Kg', '<p>Ikan Tongkol Basah 1Kg</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('104', '104', '1', 'Ikan Ekor Kuning 1Kg', '<p>Ikan Ekor Kuning 1Kg</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('105', '105', '1', 'Ikan Tenggiri 500Gr', '<p>Ikan Tenggiri 500Gr</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('106', '106', '1', 'Ikan Bawal Air Tawar 1Kg', '<p>Ikan Bawal Air Tawar 1Kg</p>', '', '0', '', '', '', '', '', '');


INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('107', '107', '1', 'Udang Pancet 500Gr', '<p>Udang Pancet 500Gr</p>', '', '0', '', '', '', '', '', '');


TRUNCATE products_images; TRUNCATE products_options; TRUNCATE products_options_descriptions; TRUNCATE products_options_values; TRUNCATE products_options_values_descriptions; TRUNCATE products_shipping_rates; INSERT INTO products_shipping_rates (`products_shipping_rates_id`, `weight_from`, `weight_to`, `weight_price`, `unit_id`, `products_shipping_status`); VALUES ('1', '0', '10', '10', '1', '1');


INSERT INTO products_shipping_rates (`products_shipping_rates_id`, `weight_from`, `weight_to`, `weight_price`, `unit_id`, `products_shipping_status`); VALUES ('2', '10', '20', '10', '1', '1');


INSERT INTO products_shipping_rates (`products_shipping_rates_id`, `weight_from`, `weight_to`, `weight_price`, `unit_id`, `products_shipping_status`); VALUES ('3', '20', '30', '10', '1', '1');


INSERT INTO products_shipping_rates (`products_shipping_rates_id`, `weight_from`, `weight_to`, `weight_price`, `unit_id`, `products_shipping_status`); VALUES ('4', '30', '50', '50', '1', '1');


INSERT INTO products_shipping_rates (`products_shipping_rates_id`, `weight_from`, `weight_to`, `weight_price`, `unit_id`, `products_shipping_status`); VALUES ('5', '50', '100000', '70', '1', '1');


TRUNCATE products_to_categories; INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('74', '64', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('75', '69', '5');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('76', '68', '5');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('78', '65', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('79', '63', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('80', '62', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('81', '61', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('82', '60', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('83', '59', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('84', '57', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('85', '58', '3');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('86', '56', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('87', '55', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('88', '54', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('89', '53', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('90', '52', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('93', '49', '5');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('94', '48', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('95', '47', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('96', '46', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('97', '45', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('98', '44', '3');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('99', '43', '3');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('100', '42', '3');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('101', '41', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('102', '40', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('103', '39', '3');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('104', '38', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('105', '37', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('106', '36', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('107', '35', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('108', '34', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('109', '33', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('110', '32', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('111', '31', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('112', '30', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('113', '29', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('114', '28', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('115', '27', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('116', '25', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('117', '26', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('118', '23', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('119', '22', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('120', '21', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('121', '24', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('122', '17', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('123', '16', '3');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('124', '14', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('125', '13', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('126', '12', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('127', '11', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('128', '10', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('129', '9', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('130', '19', '5');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('131', '15', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('132', '18', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('133', '8', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('134', '6', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('135', '5', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('136', '3', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('137', '2', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('139', '4', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('140', '7', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('141', '70', '5');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('142', '50', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('144', '51', '1');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('145', '71', '2');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('146', '72', '2');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('147', '73', '2');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('148', '74', '2');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('149', '75', '2');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('150', '76', '2');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('151', '77', '2');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('152', '78', '2');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('153', '79', '2');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('154', '80', '2');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('155', '81', '2');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('156', '82', '2');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('158', '84', '2');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('159', '83', '2');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('160', '85', '2');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('161', '86', '2');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('167', '91', '2');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('169', '93', '2');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('170', '94', '2');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('171', '95', '2');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('172', '96', '2');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('173', '92', '2');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('174', '87', '2');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('175', '88', '2');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('176', '89', '2');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('177', '90', '2');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('178', '97', '4');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('179', '98', '4');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('180', '99', '4');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('181', '100', '4');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('182', '101', '4');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('183', '102', '4');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('184', '103', '4');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('185', '104', '4');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('186', '105', '4');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('187', '106', '4');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('188', '107', '4');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('189', '66', '5');


TRUNCATE reviews; TRUNCATE reviews_description; TRUNCATE sessions; TRUNCATE settings; INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('1', 'facebook_app_id', 'FB_CLIENT_ID', '2018-04-27 00:00:00', '2019-11-01 06:58:53');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('2', 'facebook_secret_id', 'FB_SECRET_KEY', '2018-04-27 00:00:00', '2019-11-01 06:58:53');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('3', 'facebook_login', '0', '2018-04-27 00:00:00', '2019-11-01 06:58:53');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('4', 'contact_us_email', 'support@rumahsayurkita.com', '2018-04-27 00:00:00', '2020-09-14 06:18:12');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('5', 'address', 'Jl. CInta No 35 Pulo Gadung', '2018-04-27 00:00:00', '2020-09-14 06:18:12');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('6', 'city', 'Jakarta Timur', '2018-04-27 00:00:00', '2020-09-14 06:18:12');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('7', 'state', 'DI JAKARTA', '2018-04-27 00:00:00', '2020-09-14 06:18:12');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('8', 'zip', 'Zip', '2018-04-27 00:00:00', '2020-09-14 06:18:12');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('9', 'country', 'indonesia', '2018-04-27 00:00:00', '2020-09-14 06:18:12');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('10', 'latitude', 'Latitude', '2018-04-27 00:00:00', '2020-09-14 06:18:12');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('11', 'longitude', 'Longitude', '2018-04-27 00:00:00', '2020-09-14 06:18:12');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('12', 'phone_no', '08 1212 08 2958', '2018-04-27 00:00:00', '2020-09-14 06:18:12');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('13', 'fcm_android', '', '2018-04-27 00:00:00', '2019-02-05 11:42:15');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('14', 'fcm_ios', '', '2018-04-27 00:00:00', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('15', 'fcm_desktop', '', '2018-04-27 00:00:00', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('16', 'website_logo', 'images/media/2020/07/FQrzt20605.png', '2018-04-27 00:00:00', '2020-07-20 05:01:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('17', 'fcm_android_sender_id', '', '2018-04-27 00:00:00', '2020-08-27 12:41:21');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('18', 'fcm_ios_sender_id', '', '2018-04-27 00:00:00', '2019-02-05 11:42:15');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('19', 'app_name', 'Rumah Sayur Kita', '2018-04-27 00:00:00', '2020-09-14 06:18:12');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('20', 'currency_symbol', 'Rp', '2018-04-27 00:00:00', '2018-11-19 07:26:01');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('21', 'new_product_duration', '20', '2018-04-27 00:00:00', '2020-09-14 06:18:12');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('22', 'notification_title', 'RUMAH SAYUR KITA', '2018-04-27 00:00:00', '2020-09-27 08:51:59');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('23', 'notification_text', 'Harga murah menanti anda!', '2018-04-27 00:00:00', '2020-09-27 08:51:59');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('24', 'lazzy_loading_effect', 'android', '2018-04-27 00:00:00', '2020-09-27 08:51:59');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('25', 'footer_button', '1', '2018-04-27 00:00:00', '2019-05-15 10:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('26', 'cart_button', '1', '2018-04-27 00:00:00', '2020-09-27 08:51:59');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('27', 'featured_category', '', '2018-04-27 00:00:00', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('28', 'notification_duration', 'day', '2018-04-27 00:00:00', '2020-09-27 08:51:59');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('29', 'home_style', '7', '2018-04-27 00:00:00', '2020-09-27 08:51:59');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('30', 'wish_list_page', '1', '2018-04-27 00:00:00', '2020-09-27 08:51:59');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('31', 'edit_profile_page', '0', '2018-04-27 00:00:00', '2020-09-27 08:51:59');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('32', 'shipping_address_page', '1', '2018-04-27 00:00:00', '2020-09-27 08:51:59');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('33', 'my_orders_page', '1', '2018-04-27 00:00:00', '2020-09-27 08:51:59');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('34', 'contact_us_page', '1', '2018-04-27 00:00:00', '2020-09-27 08:51:59');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('35', 'about_us_page', '1', '2018-04-27 00:00:00', '2020-09-27 08:51:59');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('36', 'news_page', '1', '2018-04-27 00:00:00', '2020-09-27 08:51:59');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('37', 'intro_page', '0', '2018-04-27 00:00:00', '2020-09-27 08:51:59');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('38', 'setting_page', '1', '2018-04-27 00:00:00', '2020-09-27 08:51:59');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('39', 'share_app', '0', '2018-04-27 00:00:00', '2020-09-27 08:51:59');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('40', 'rate_app', '0', '2018-04-27 00:00:00', '2020-09-27 08:51:59');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('41', 'site_url', 'URL', '2018-04-27 00:00:00', '2018-11-19 07:26:01');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('42', 'admob', '0', '2018-04-27 00:00:00', '2019-05-15 10:58:05');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('43', 'admob_id', 'ID', '2018-04-27 00:00:00', '2019-05-15 10:58:05');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('44', 'ad_unit_id_banner', 'Unit ID', '2018-04-27 00:00:00', '2019-05-15 10:58:05');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('45', 'ad_unit_id_interstitial', 'Indestrial', '2018-04-27 00:00:00', '2019-05-15 10:58:05');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('46', 'category_style', '1', '2018-04-27 00:00:00', '2020-09-27 08:51:59');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('47', 'package_name', 'package name', '2018-04-27 00:00:00', '2019-05-15 10:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('48', 'google_analytic_id', 'test', '2018-04-27 00:00:00', '2020-09-27 08:51:59');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('49', 'themes', 'themeone', '2018-04-27 00:00:00', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('50', 'company_name', '#', '2018-04-27 00:00:00', '2019-10-07 09:52:24');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('51', 'facebook_url', '#', '2018-04-27 00:00:00', '2020-07-20 05:01:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('52', 'google_url', '#', '2018-04-27 00:00:00', '2020-07-20 05:01:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('53', 'twitter_url', '#', '2018-04-27 00:00:00', '2020-07-20 05:01:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('54', 'linked_in', '#', '2018-04-27 00:00:00', '2020-07-20 05:01:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('55', 'default_notification', 'onesignal', '2018-04-27 00:00:00', '2020-08-27 12:41:21');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('56', 'onesignal_app_id', '0aaaf0ef-cd08-45d2-a1a8-f584825ab0e9', '2018-04-27 00:00:00', '2020-08-27 12:41:21');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('57', 'onesignal_sender_id', '661676719441', '2018-04-27 00:00:00', '2020-08-27 12:41:21');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('58', 'ios_admob', '0', '2018-04-27 00:00:00', '2019-05-15 10:58:05');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('59', 'ios_admob_id', 'AdMob ID', '2018-04-27 00:00:00', '2019-05-15 10:58:05');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('60', 'ios_ad_unit_id_banner', 'Unit ID Banner', '2018-04-27 00:00:00', '2019-05-15 10:58:05');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('61', 'ios_ad_unit_id_interstitial', 'ID Interstitial', '2018-04-27 00:00:00', '2019-05-15 10:58:05');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('62', 'google_login', '0', '', '2019-11-01 06:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('63', 'google_app_id', '', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('64', 'google_secret_id', '', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('65', 'google_callback_url', '', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('66', 'facebook_callback_url', '', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('67', 'is_app_purchased', '1', '', '2018-05-04 03:24:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('68', 'is_web_purchased', '1', '', '2018-05-04 03:24:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('69', 'consumer_key', '35cc6e021600286912b3c33717', '', '2020-09-16 08:08:32');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('70', 'consumer_secret', '4be302541600286912512aca2e', '', '2020-09-16 08:08:32');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('71', 'order_email', 'orders@rumahsayurkita.com', '', '2020-09-14 06:18:12');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('72', 'website_themes', '1', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('73', 'seo_title', '', '', '2018-11-19 07:21:57');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('74', 'seo_metatag', '', '', '2018-11-19 07:21:57');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('75', 'seo_keyword', '', '', '2018-11-19 07:21:57');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('76', 'seo_description', '', '', '2018-11-19 07:21:57');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('77', 'before_head_tag', '', '', '2018-11-19 07:22:15');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('78', 'end_body_tag', 'name', '', '2019-10-11 11:57:29');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('79', 'sitename_logo', 'logo', '', '2020-07-20 05:01:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('80', 'website_name', '<strong>RUMAH</strong>SAYUR KITA', '', '2020-07-20 05:01:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('81', 'web_home_pages_style', 'two', '', '2018-11-19 07:22:25');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('82', 'web_color_style', 'app.theme.19', '', '2020-09-14 09:19:33');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('83', 'free_shipping_limit', '400', '', '2020-09-14 06:18:12');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('84', 'app_icon_image', 'icon', '', '2019-02-05 10:12:59');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('85', 'twilio_status', '0', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('86', 'twilio_authy_api_id', '', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('87', 'favicon', 'images/media/2020/07/VRPoJ20105.png', '', '2020-07-20 05:01:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('88', 'Thumbnail_height', '150', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('89', 'Thumbnail_width', '150', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('90', 'Medium_height', '400', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('91', 'Medium_width', '400', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('92', 'Large_height', '900', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('93', 'Large_width', '900', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('94', 'environmentt', 'production', '', '2020-09-14 06:18:12');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('95', 'maintenance_text', 'https://example.com', '', '2020-09-14 06:18:12');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('96', 'package_charge_taxt', '0', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('97', 'order_commission', '0', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('98', 'all_items_price_included_tax', 'yes', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('99', 'all_items_price_included_tax_value', '0', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('100', 'driver_accept_multiple_order', '1', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('101', 'min_order_price', '20', '', '2020-09-14 06:18:12');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('102', 'youtube_link', '0', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('103', 'external_website_link', 'http://www.rumahsayurkita.com/', '', '2020-09-14 06:18:12');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('104', 'google_map_api', '', '', '2019-10-21 07:36:53');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('105', 'is_pos_purchased', '0', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('106', 'admin_version', '1.4', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('107', 'app_version', '1.3', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('108', 'web_version', '1.3', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('109', 'pos_version', '0', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('110', 'android_app_link', '#', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('111', 'iphone_app_link', '#', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('112', 'about_content', 'Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum', '', '2020-07-20 05:01:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('113', 'contact_content', 'Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum', '', '2020-07-20 05:01:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('114', 'is_deliverboy_purchased', '1', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('115', 'fb_redirect_url', 'http://YOUR_DOMAIN_NAME/login/facebook/callback', '', '2019-11-01 06:58:53');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('116', 'google_client_id', 'GOOGLE_CLIENT_ID', '', '2019-11-01 06:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('117', 'google_client_secret', 'GOOGLE_SECRET_KEY', '', '2019-11-01 06:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('118', 'google_redirect_url', 'http://YOUR_DOMAIN_NAME/login/google/callback', '', '2019-11-01 06:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('119', 'newsletter', '1', '', '2020-07-20 05:07:01');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('120', 'allow_cookies', '0', '', '2020-07-20 05:01:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('121', 'card_style', '2', '', '2020-09-27 08:51:59');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('122', 'banner_style', '2', '', '2020-09-27 08:51:59');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('123', 'mail_chimp_api', '', '', '2020-07-20 05:07:01');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('124', 'mail_chimp_list_id', '', '', '2020-07-20 05:07:01');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('125', 'newsletter_image', 'images/media/2020/07/RhCsh20105.png', '', '2020-07-20 05:07:01');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('126', 'instauserid', 'rumahsayurkita_', '', '2020-09-09 10:37:19');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('127', 'is_enable_location', '0', '', '2019-11-01 06:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('128', 'default_latitude', '', '', '2019-11-01 06:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('129', 'default_longitude', '', '', '2019-11-01 06:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('130', 'web_card_style', '1', '', '2019-11-01 06:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('131', 'auth_domain', '1', '', '2019-11-01 06:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('132', 'database_URL', '', '', '2019-11-01 06:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('133', 'projectId', '', '', '2019-11-01 06:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('134', 'storage_bucket', '', '', '2019-11-01 06:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('135', 'messaging_senderid', '', '', '2019-11-01 06:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('136', 'firebase_apikey', '', '', '2019-11-01 06:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('137', 'home_categories_img_icn', 'Icon', '', '2019-11-01 06:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('138', 'home_categories_records', '6', '', '2019-11-01 06:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('139', 'home_category', '', '', '2019-11-01 06:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('140', 'firebase_appid', '', '', '2019-11-01 06:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('141', 'maptype', 'external', '', '2019-11-01 06:58:36');


TRUNCATE shipping_description; INSERT INTO shipping_description (`id`, `name`, `language_id`, `table_name`, `sub_labels`); VALUES ('1', 'Free Shipping', '1', 'free_shipping', '');


INSERT INTO shipping_description (`id`, `name`, `language_id`, `table_name`, `sub_labels`); VALUES ('4', 'Local Pickup', '1', 'local_pickup', '');


INSERT INTO shipping_description (`id`, `name`, `language_id`, `table_name`, `sub_labels`); VALUES ('7', 'Flat Rate', '1', 'flate_rate', '');


INSERT INTO shipping_description (`id`, `name`, `language_id`, `table_name`, `sub_labels`); VALUES ('13', 'Shipping Price', '1', 'shipping_by_weight', '');


TRUNCATE shipping_methods; INSERT INTO shipping_methods (`shipping_methods_id`, `methods_type_link`, `isDefault`, `status`, `table_name`); VALUES ('2', 'freeShipping', '0', '0', 'free_shipping');


INSERT INTO shipping_methods (`shipping_methods_id`, `methods_type_link`, `isDefault`, `status`, `table_name`); VALUES ('3', 'localPickup', '0', '0', 'local_pickup');


INSERT INTO shipping_methods (`shipping_methods_id`, `methods_type_link`, `isDefault`, `status`, `table_name`); VALUES ('4', 'flateRate', '1', '1', 'flate_rate');


INSERT INTO shipping_methods (`shipping_methods_id`, `methods_type_link`, `isDefault`, `status`, `table_name`); VALUES ('5', 'shippingByWeight', '0', '0', 'shipping_by_weight');


TRUNCATE sliders_images; INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('29', 'Full Screen Slider (1600x420)', 'bawang-putih-banci-500gr', '1', '335', '', '', '2021-05-07 00:00:00', '2020-08-27 11:07:02', '1', 'product', '', '1');


TRUNCATE specials; TRUNCATE tax_class; TRUNCATE tax_rates; TRUNCATE top_offers; INSERT INTO top_offers (`top_offers_id`, `top_offers_text`, `language_id`, `created_at`, `updated_at`); VALUES ('1', '<marquee>Silahkan<strong> DOWNLOAD </strong>Aplikasi
 <a href=\\\"http://download.rumahsayurkita.com\\\">
<font color=\\\"f7ad26\\\">DISINI</font>
 </a></marquee>', '1', '2020-02-04 05:14:16', '2020-09-14 09:29:31');


INSERT INTO top_offers (`top_offers_id`, `top_offers_text`, `language_id`, `created_at`, `updated_at`); VALUES ('2', '<marquee>Silahkan<strong> DOWNLOAD </strong>Aplikasi
 <a href=\\\"http://download.rumahsayurkita.com\\\">
<font color=\\\"f7ad26\\\">DISINI</font>
 </a></marquee>', '1', '2020-02-04 05:14:16', '2020-09-14 09:29:31');


TRUNCATE units; INSERT INTO units (`unit_id`, `is_active`, `date_added`, `last_modified`, `created_at`, `updated_at`); VALUES ('1', '1', '', '', '', '');


INSERT INTO units (`unit_id`, `is_active`, `date_added`, `last_modified`, `created_at`, `updated_at`); VALUES ('2', '1', '', '', '', '');


INSERT INTO units (`unit_id`, `is_active`, `date_added`, `last_modified`, `created_at`, `updated_at`); VALUES ('3', '1', '', '', '', '');


INSERT INTO units (`unit_id`, `is_active`, `date_added`, `last_modified`, `created_at`, `updated_at`); VALUES ('4', '1', '', '', '', '');


INSERT INTO units (`unit_id`, `is_active`, `date_added`, `last_modified`, `created_at`, `updated_at`); VALUES ('5', '1', '', '', '', '');


INSERT INTO units (`unit_id`, `is_active`, `date_added`, `last_modified`, `created_at`, `updated_at`); VALUES ('6', '1', '', '', '', '');


INSERT INTO units (`unit_id`, `is_active`, `date_added`, `last_modified`, `created_at`, `updated_at`); VALUES ('7', '1', '', '', '', '');


INSERT INTO units (`unit_id`, `is_active`, `date_added`, `last_modified`, `created_at`, `updated_at`); VALUES ('8', '1', '', '', '', '');


INSERT INTO units (`unit_id`, `is_active`, `date_added`, `last_modified`, `created_at`, `updated_at`); VALUES ('9', '1', '', '', '', '');


INSERT INTO units (`unit_id`, `is_active`, `date_added`, `last_modified`, `created_at`, `updated_at`); VALUES ('10', '1', '', '', '', '');


TRUNCATE units_descriptions; INSERT INTO units_descriptions (`units_description_id`, `units_name`, `languages_id`, `unit_id`, `created_at`, `updated_at`); VALUES ('1', 'Gram', '1', '1', '', '');


INSERT INTO units_descriptions (`units_description_id`, `units_name`, `languages_id`, `unit_id`, `created_at`, `updated_at`); VALUES ('2', 'Kilogram', '1', '2', '', '');


INSERT INTO units_descriptions (`units_description_id`, `units_name`, `languages_id`, `unit_id`, `created_at`, `updated_at`); VALUES ('3', 'Pcs', '1', '3', '', '');


INSERT INTO units_descriptions (`units_description_id`, `units_name`, `languages_id`, `unit_id`, `created_at`, `updated_at`); VALUES ('4', 'Karton', '1', '4', '', '');


INSERT INTO units_descriptions (`units_description_id`, `units_name`, `languages_id`, `unit_id`, `created_at`, `updated_at`); VALUES ('5', 'Karung', '1', '5', '', '');


INSERT INTO units_descriptions (`units_description_id`, `units_name`, `languages_id`, `unit_id`, `created_at`, `updated_at`); VALUES ('6', 'Renceng', '1', '6', '', '');


INSERT INTO units_descriptions (`units_description_id`, `units_name`, `languages_id`, `unit_id`, `created_at`, `updated_at`); VALUES ('7', 'Pak', '1', '7', '', '');


INSERT INTO units_descriptions (`units_description_id`, `units_name`, `languages_id`, `unit_id`, `created_at`, `updated_at`); VALUES ('8', 'Renceng', '1', '8', '', '');


INSERT INTO units_descriptions (`units_description_id`, `units_name`, `languages_id`, `unit_id`, `created_at`, `updated_at`); VALUES ('9', 'Ikat', '1', '9', '', '');


INSERT INTO units_descriptions (`units_description_id`, `units_name`, `languages_id`, `unit_id`, `created_at`, `updated_at`); VALUES ('10', 'Bungkus', '1', '10', '', '');


TRUNCATE ups_shipping; TRUNCATE user_to_address; TRUNCATE user_types; INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('1', 'Super Admin', '1534774230', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('2', 'Customers', '1534777027', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('3', 'Vendors', '1538390209', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('4', 'Delivery Guy', '1542965906', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('5', 'Test 1', '1542965906', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('6', 'Test 2', '1542965906', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('7', 'Test 3', '1542965906', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('8', 'Test 4', '1542965906', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('9', 'Test 5', '1542965906', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('10', 'Test 6', '1542965906', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('11', 'Admin', '1542965906', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('12', 'Manager', '1542965906', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('13', 'Data Entry', '1542965906', '', '1');


TRUNCATE users; INSERT INTO users (`id`, `role_id`, `user_name`, `first_name`, `last_name`, `gender`, `default_address_id`, `country_code`, `phone`, `email`, `password`, `avatar`, `status`, `is_seen`, `phone_verified`, `remember_token`, `auth_id_tiwilo`, `dob`, `created_at`, `updated_at`); VALUES ('1', '1', 'fiojuliansyah', 'Fio', 'juliansyah', '', '0', '', '', 'admin@rumahsayurkita.com', '$2y$10$SfuD53J/HAI.bu/0X6Qc7.FykQgyXcHngAsZm6he5z94bP53dZDI6', '', '1', '0', '', '', '', '', '2020-07-20 16:03:08', '2020-07-20 16:03:08');


INSERT INTO users (`id`, `role_id`, `user_name`, `first_name`, `last_name`, `gender`, `default_address_id`, `country_code`, `phone`, `email`, `password`, `avatar`, `status`, `is_seen`, `phone_verified`, `remember_token`, `auth_id_tiwilo`, `dob`, `created_at`, `updated_at`); VALUES ('3', '2', '', 'Hengki', 'Triprasetyo', '0', '0', '', '', 'hengky3lk@gmail.com', '$2y$10$ez0KVmMI0x15rbqAjs8OXOuIUNRi.8HMJlyatusCa1uhPPTKGFi3W', '', '1', '0', '', '', '', '', '2020-08-31 04:20:41', '2020-08-31 04:20:41');


INSERT INTO users (`id`, `role_id`, `user_name`, `first_name`, `last_name`, `gender`, `default_address_id`, `country_code`, `phone`, `email`, `password`, `avatar`, `status`, `is_seen`, `phone_verified`, `remember_token`, `auth_id_tiwilo`, `dob`, `created_at`, `updated_at`); VALUES ('5', '2', '', 'bariq', 'dharmawan', '0', '0', '', '087771406656', 'sanchez77rodriguez@gmail.com', '$2y$10$2IcqQUPSmu4FLsJoCS3Tv.O3DKV17UFst2CPpZzMG9DaEfxtGiL8W', '', '1', '1', '', '', '', '16/03/2001', '2020-09-09 10:04:50', '2020-09-09 10:05:28');


TRUNCATE users_balance; TRUNCATE whos_online; INSERT INTO whos_online (`customer_id`, `full_name`, `session_id`, `ip_address`, `time_entry`, `time_last_click`, `last_page_url`); VALUES ('4', 'Fio Juliansyah', '', '', '2020-09-15 05:', '', '');


TRUNCATE zones; INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('1', '223', 'AL', 'Alabama');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('2', '223', 'AK', 'Alaska');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('3', '223', 'AS', 'American Samoa');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('4', '223', 'AZ', 'Arizona');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('5', '223', 'AR', 'Arkansas');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('6', '223', 'AF', 'Armed Forces Africa');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('7', '223', 'AA', 'Armed Forces Americas');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('8', '223', 'AC', 'Armed Forces Canada');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('9', '223', 'AE', 'Armed Forces Europe');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('10', '223', 'AM', 'Armed Forces Middle East');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('11', '223', 'AP', 'Armed Forces Pacific');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('12', '223', 'CA', 'California');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('13', '223', 'CO', 'Colorado');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('14', '223', 'CT', 'Connecticut');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('15', '223', 'DE', 'Delaware');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('16', '223', 'DC', 'District of Columbia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('17', '223', 'FM', 'Federated States Of Micronesia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('18', '223', 'FL', 'Florida');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('19', '223', 'GA', 'Georgia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('20', '223', 'GU', 'Guam');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('21', '223', 'HI', 'Hawaii');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('22', '223', 'ID', 'Idaho');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('23', '223', 'IL', 'Illinois');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('24', '223', 'IN', 'Indiana');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('25', '223', 'IA', 'Iowa');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('26', '223', 'KS', 'Kansas');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('27', '223', 'KY', 'Kentucky');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('28', '223', 'LA', 'Louisiana');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('29', '223', 'ME', 'Maine');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('30', '223', 'MH', 'Marshall Islands');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('31', '223', 'MD', 'Maryland');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('32', '223', 'MA', 'Massachusetts');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('33', '223', 'MI', 'Michigan');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('34', '223', 'MN', 'Minnesota');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('35', '223', 'MS', 'Mississippi');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('36', '223', 'MO', 'Missouri');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('37', '223', 'MT', 'Montana');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('38', '223', 'NE', 'Nebraska');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('39', '223', 'NV', 'Nevada');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('40', '223', 'NH', 'New Hampshire');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('41', '223', 'NJ', 'New Jersey');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('42', '223', 'NM', 'New Mexico');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('43', '223', 'NY', 'New York');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('44', '223', 'NC', 'North Carolina');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('45', '223', 'ND', 'North Dakota');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('46', '223', 'MP', 'Northern Mariana Islands');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('47', '223', 'OH', 'Ohio');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('48', '223', 'OK', 'Oklahoma');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('49', '223', 'OR', 'Oregon');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('50', '223', 'PW', 'Palau');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('51', '223', 'PA', 'Pennsylvania');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('52', '223', 'PR', 'Puerto Rico');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('53', '223', 'RI', 'Rhode Island');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('54', '223', 'SC', 'South Carolina');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('55', '223', 'SD', 'South Dakota');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('56', '223', 'TN', 'Tennessee');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('57', '223', 'TX', 'Texas');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('58', '223', 'UT', 'Utah');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('59', '223', 'VT', 'Vermont');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('60', '223', 'VI', 'Virgin Islands');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('61', '223', 'VA', 'Virginia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('62', '223', 'WA', 'Washington');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('63', '223', 'WV', 'West Virginia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('64', '223', 'WI', 'Wisconsin');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('65', '223', 'WY', 'Wyoming');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('66', '38', 'AB', 'Alberta');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('67', '38', 'BC', 'British Columbia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('68', '38', 'MB', 'Manitoba');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('69', '38', 'NF', 'Newfoundland');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('70', '38', 'NB', 'New Brunswick');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('71', '38', 'NS', 'Nova Scotia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('72', '38', 'NT', 'Northwest Territories');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('73', '38', 'NU', 'Nunavut');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('74', '38', 'ON', 'Ontario');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('75', '38', 'PE', 'Prince Edward Island');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('76', '38', 'QC', 'Quebec');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('77', '38', 'SK', 'Saskatchewan');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('78', '38', 'YT', 'Yukon Territory');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('79', '81', 'NDS', 'Niedersachsen');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('80', '81', 'BAW', 'Baden-Württemberg');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('81', '81', 'BAY', 'Bayern');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('82', '81', 'BER', 'Berlin');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('83', '81', 'BRG', 'Brandenburg');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('84', '81', 'BRE', 'Bremen');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('85', '81', 'HAM', 'Hamburg');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('86', '81', 'HES', 'Hessen');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('87', '81', 'MEC', 'Mecklenburg-Vorpommern');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('88', '81', 'NRW', 'Nordrhein-Westfalen');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('89', '81', 'RHE', 'Rheinland-Pfalz');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('90', '81', 'SAR', 'Saarland');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('91', '81', 'SAS', 'Sachsen');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('92', '81', 'SAC', 'Sachsen-Anhalt');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('93', '81', 'SCN', 'Schleswig-Holstein');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('94', '81', 'THE', 'Thüringen');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('95', '14', 'WI', 'Wien');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('96', '14', 'NO', 'Niederösterreich');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('97', '14', 'OO', 'Oberösterreich');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('98', '14', 'SB', 'Salzburg');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('99', '14', 'KN', 'Kärnten');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('100', '14', 'ST', 'Steiermark');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('101', '14', 'TI', 'Tirol');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('102', '14', 'BL', 'Burgenland');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('103', '14', 'VB', 'Voralberg');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('104', '204', 'AG', 'Aargau');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('105', '204', 'AI', 'Appenzell Innerrhoden');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('106', '204', 'AR', 'Appenzell Ausserrhoden');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('107', '204', 'BE', 'Bern');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('108', '204', 'BL', 'Basel-Landschaft');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('109', '204', 'BS', 'Basel-Stadt');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('110', '204', 'FR', 'Freiburg');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('111', '204', 'GE', 'Genf');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('112', '204', 'GL', 'Glarus');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('113', '204', 'JU', 'Graubünden');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('114', '204', 'JU', 'Jura');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('115', '204', 'LU', 'Luzern');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('116', '204', 'NE', 'Neuenburg');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('117', '204', 'NW', 'Nidwalden');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('118', '204', 'OW', 'Obwalden');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('119', '204', 'SG', 'St. Gallen');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('120', '204', 'SH', 'Schaffhausen');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('121', '204', 'SO', 'Solothurn');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('122', '204', 'SZ', 'Schwyz');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('123', '204', 'TG', 'Thurgau');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('124', '204', 'TI', 'Tessin');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('125', '204', 'UR', 'Uri');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('126', '204', 'VD', 'Waadt');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('127', '204', 'VS', 'Wallis');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('128', '204', 'ZG', 'Zug');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('129', '204', 'ZH', 'Zürich');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('130', '195', 'A Coruña', 'A Coruña');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('131', '195', 'Alava', 'Alava');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('132', '195', 'Albacete', 'Albacete');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('133', '195', 'Alicante', 'Alicante');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('134', '195', 'Almeria', 'Almeria');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('135', '195', 'Asturias', 'Asturias');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('136', '195', 'Avila', 'Avila');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('137', '195', 'Badajoz', 'Badajoz');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('138', '195', 'Baleares', 'Baleares');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('139', '195', 'Barcelona', 'Barcelona');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('140', '195', 'Burgos', 'Burgos');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('141', '195', 'Caceres', 'Caceres');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('142', '195', 'Cadiz', 'Cadiz');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('143', '195', 'Cantabria', 'Cantabria');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('144', '195', 'Castellon', 'Castellon');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('145', '195', 'Ceuta', 'Ceuta');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('146', '195', 'Ciudad Real', 'Ciudad Real');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('147', '195', 'Cordoba', 'Cordoba');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('148', '195', 'Cuenca', 'Cuenca');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('149', '195', 'Girona', 'Girona');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('150', '195', 'Granada', 'Granada');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('151', '195', 'Guadalajara', 'Guadalajara');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('152', '195', 'Guipuzcoa', 'Guipuzcoa');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('153', '195', 'Huelva', 'Huelva');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('154', '195', 'Huesca', 'Huesca');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('155', '195', 'Jaen', 'Jaen');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('156', '195', 'La Rioja', 'La Rioja');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('157', '195', 'Las Palmas', 'Las Palmas');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('158', '195', 'Leon', 'Leon');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('159', '195', 'Lleida', 'Lleida');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('160', '195', 'Lugo', 'Lugo');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('161', '195', 'Madrid', 'Madrid');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('162', '195', 'Malaga', 'Malaga');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('163', '195', 'Melilla', 'Melilla');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('164', '195', 'Murcia', 'Murcia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('165', '195', 'Navarra', 'Navarra');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('166', '195', 'Ourense', 'Ourense');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('167', '195', 'Palencia', 'Palencia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('168', '195', 'Pontevedra', 'Pontevedra');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('169', '195', 'Salamanca', 'Salamanca');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('170', '195', 'Santa Cruz de Tenerife', 'Santa Cruz de Tenerife');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('171', '195', 'Segovia', 'Segovia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('172', '195', 'Sevilla', 'Sevilla');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('173', '195', 'Soria', 'Soria');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('174', '195', 'Tarragona', 'Tarragona');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('175', '195', 'Teruel', 'Teruel');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('176', '195', 'Toledo', 'Toledo');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('177', '195', 'Valencia', 'Valencia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('178', '195', 'Valladolid', 'Valladolid');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('179', '195', 'Vizcaya', 'Vizcaya');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('180', '195', 'Zamora', 'Zamora');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('181', '195', 'Zaragoza', 'Zaragoza');


TRUNCATE zones_to_geo_zones; 